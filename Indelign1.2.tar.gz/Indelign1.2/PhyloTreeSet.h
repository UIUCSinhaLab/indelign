// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef PHYLOTREE_H
#define PHYLOTREE_H

#include <iostream>
#include <vector>
#include <map>
#include <math.h>
#include "PhyloTreeNode.h"
#include "Util.h"
#include "TInterAnchor.h"
#include "NodeScoreMatrix.h"
#include "TotalBranch.h"
#include "SearchBest.h"
#include "Param.h"


using namespace std;

class SearchBest;

class PhyloTreeSet{
public:
    const static int PREFER_INS = 1;
    const static int PREFER_DEL = 2;

private:
  int rootIndex;
  map<int, vector<int> >* treeMap;
  int nSeq;
  vector<PhyloTreeNode*> rootNodeSet;
  vector<string>* seqVec;
  vector<int> baseVec;

  TInterAnchor* tInterAnchor;
  int iaIndex;
  TotalBranch* totalBranch;
  int numBranch;
  double totalScore;
  SearchBest* searchBest;

  int indelPrefer;
  bool bDelEvent;

public:
  PhyloTreeSet(); // default constructor
  PhyloTreeSet(int index, map<int, vector<int> >* treeMap, int nSeq, vector<string>* seqVec,
      TInterAnchor* tInterAnchor, int iaIndex); // constructor
  PhyloTreeSet(int index, map<int, vector<int> >* treeMap, int nSeq, vector<string>* seqVec,
      TInterAnchor* tInterAnchor, SearchBest* searchBest, int ip); // constructor
  PhyloTreeSet(int index, map<int, vector<int> >* treeMap, int nSeq, vector<string>* seqVec,
      TInterAnchor* tInterAnchor); // constructor
  ~PhyloTreeSet(); // default destructor
  void makePhyloTree();
  void annotatePhyloTree(PhyloTreeNode* pTree, int* bIndex);
  void annotatePhyloTreeEx(PhyloTreeNode* pTree, int* bIndex);
  void makeNodeAnnotation(PhyloTreeNode* rNode);
  void makeSubAnnotation(PhyloTreeNode* rNode, char optimalBase);
  void makeBranchAnnotation(PhyloTreeNode* rNode);

  void summaryInterAnchor(int colIndex, PhyloTreeNode* pTree, bool bLast);
  void aux_summaryInterAnchor(int colIndex, PhyloTreeNode* pTree, int* branchIndex, bool bLast);
  void summaryInterAnchorEx(PhyloTreeNode* pTree, bool bLast);
  void aux_summaryInterAnchorEx(PhyloTreeNode* pTree, int* branchIndex, bool bLast);

  double getScore();
  int getNumTree();
  PhyloTreeNode* getRootNodeAt(int index);    
  TotalBranch* getTotalBranch();
  void freeNodeMemory();

  void dump();

private:
  void dumpTree(PhyloTreeNode* pNode);
  void makePhyloTreeForSites(PhyloTreeNode* phyloTree, int rootIndex,int cIndex, PhyloTreeNode* pNode, map<int, PhyloTreeNode*>* leafMap, int* bIndex);
  void freeMemory(PhyloTreeNode* pNode);
};

#endif

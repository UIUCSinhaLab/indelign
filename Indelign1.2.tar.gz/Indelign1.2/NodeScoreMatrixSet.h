// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef NODESCOREMATRIXSET_H
#define NODESCOREMATRIXSET_H

#include <iostream>
#include <vector>
#include <assert.h>
#include "NodeScoreMatrix.h"

using namespace std;

class NodeScoreMatrixSet
{
private:
	vector<NodeScoreMatrix*> m_nsMatVec;

public:
	NodeScoreMatrixSet();	// Default constructor
	~NodeScoreMatrixSet();	// Default destructor
    NodeScoreMatrixSet(const NodeScoreMatrixSet& nsSet); // copy constructor

	void addNodeScoreMatrix(NodeScoreMatrix* nsMat);
	NodeScoreMatrix* getNodeScoreMatrixAt(int index);
    int getSize();
};

#endif


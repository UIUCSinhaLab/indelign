// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef BOUNDARYITEM_H
#define BOUNDARYITEM_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class BoundaryItem {

private:
  int startIndex;
  int endIndex;
  int seqId;
  bool isGap;
  bool continuedGap;

public:
  BoundaryItem(); // default constructor
  BoundaryItem(int start, int end, int seq, bool ig, bool continued);
  BoundaryItem(const BoundaryItem& bItem); // copy constructor
  ~BoundaryItem(); // default destructor
  int getStart();
  int getEnd();
  int getSeqId();   
  bool getIsGap();
  bool isContinued();
  void dump();
};

#endif

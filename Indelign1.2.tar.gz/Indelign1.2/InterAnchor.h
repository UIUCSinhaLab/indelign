// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef INTERANCHOR_H
#define INTERANCHOR_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class InterAnchor {

private:
  int nSeq;	
  vector<string> dnaSeq;
  int colNum;
  vector<string> ancVec;    // mark anchor site for each sequence
                                // '-' not anchor, 'A' anchor

public:
  InterAnchor(); // default constructor
  InterAnchor(int num);
  ~InterAnchor(); // default destructor
  void setSequence(vector<string> seqVec);
  vector<string>* getSequenceP();
  int getSize();
  int getColumnNumber();
  void dump();

  void setAnchorAt(int seqNum, int index);
  bool isAnchorAt(int seqNum, int index);
  string getSequenceAt(int seqNum);
  int getTempSize();
};

#endif

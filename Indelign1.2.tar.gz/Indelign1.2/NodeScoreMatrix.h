// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef NODESCOREMATRIX_H
#define NODESCOREMATRIX_H

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <assert.h>

using namespace std;

class SelectedChildBase{
public:
	char leftBase;
	char rightBase;

public:
    SelectedChildBase();    // default constructor
    SelectedChildBase(const SelectedChildBase& scBase); // copy constructor
    ~SelectedChildBase();
};

class  NodeScoreMatrixPrev {

private: 
   map<char, double> scoreMatrix;
   //char leftChildBase;
   //char rightChildBase;
   
   map<char, SelectedChildBase*> childBaseMap;
   bool finishScoring;

public:
    const static int MAX_EVENT = 10000;
    const static double MIN_SCORE = -1000000000000.0;

   NodeScoreMatrixPrev();
   NodeScoreMatrixPrev(const NodeScoreMatrixPrev& nsMat);   // copy constructor
   ~NodeScoreMatrixPrev();
   double getScore(char base);
   void setScore(char base, double score);
   double getProb(char base);
   void setProb(char base, double score);
   
   bool getFinishScoring();
   void setFinishScoring();
   
   char getSelectedLeftBase(char left);
   void setSelectedLeftBase(char parent, char left);
   char getSelectedRightBase(char right);
   void setSelectedRightBase(char parent, char right);
    
    char getBestLabel();
    
};

class  NodeScoreMatrix {

private: 
   map<char, double> scoreMatrix;

public:
   const static int MAX_EVENT = 10000;

   NodeScoreMatrix();
   NodeScoreMatrix(const NodeScoreMatrix& nsMat);   // copy constructor
   ~NodeScoreMatrix();
   double getScore(char base);
   void setScore(char base, double score);
   double getProb(char base);
   void setProb(char base, double score);
  
    char getBestLabel();
   
};

#endif



// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "PhyloTreeSet.h"


using namespace std;

PhyloTreeSet::PhyloTreeSet()
{
	rootIndex=0;
    treeMap = NULL;
    seqVec = NULL;
	nSeq=0;
    tInterAnchor= NULL;
    totalBranch = NULL;
    numBranch = 0;
    totalScore = 0;

    baseVec.push_back('A');
    baseVec.push_back('C');
    baseVec.push_back('G');
    baseVec.push_back('T');
    baseVec.push_back('-');
}

// Constructor for TInterAnchor class
PhyloTreeSet::PhyloTreeSet(int index, map<int, vector<int> >* treeTopology, int numSeq, vector<string>* seqVector
                            , TInterAnchor* tInt, int ind)
{
	rootIndex = index;
	treeMap = treeTopology;
	nSeq=numSeq;
    seqVec = seqVector; 
    tInterAnchor = tInt;
    iaIndex = ind;
    totalBranch = NULL;
    searchBest = NULL;
    numBranch = tInterAnchor->getNumBranch();
    totalScore = 0;
    indelPrefer = PREFER_INS;
    bDelEvent = false;

    baseVec.push_back('A');
    baseVec.push_back('C');
    baseVec.push_back('G');
    baseVec.push_back('T');
    baseVec.push_back('-');

    makePhyloTree();
    
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {	
	    PhyloTreeNode* pNode = rootNodeSet.at(i);

        int branchIndex = 1 ;
        annotatePhyloTree(pNode, &branchIndex);
		makeNodeAnnotation(pNode);
		makeBranchAnnotation(pNode);
    }
    
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {	
        bool bLast= false;
        PhyloTreeNode* pNode = rootNodeSet.at(i);
        if(i == (rootNodeSet.size()-1)) bLast = true;
        summaryInterAnchor(i, pNode, bLast);
    }


}

// Constructor for SearchBest class
PhyloTreeSet::PhyloTreeSet(int index, map<int, vector<int> >* treeTopology, int numSeq, vector<string>* seqVector
                            , TInterAnchor* tInt, SearchBest* sBest, int ip)
{
	rootIndex = index;
	treeMap = treeTopology;
	nSeq=numSeq;
    seqVec = seqVector; 
    tInterAnchor = tInt;
    iaIndex = -1;
    numBranch = tInterAnchor->getNumBranch();
    totalBranch = new TotalBranch(numBranch);
    searchBest = sBest;
    totalScore = 0;
    indelPrefer = PREFER_INS;
    bDelEvent = false;

    baseVec.push_back('A');
    baseVec.push_back('C');
    baseVec.push_back('G');
    baseVec.push_back('T');
    baseVec.push_back('-');

    makePhyloTree();
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {	
	    PhyloTreeNode* pNode = rootNodeSet.at(i);

        if (ip == PREFER_DEL && bDelEvent == true)
        {
            int numSiteNonGap = 0;
            int numSiteGap = 0;
            for(int j=0;j<nSeq;j++)
            {
		        if(seqVec->at(j).at(i) == '-')
                    numSiteGap++;
                else
                    numSiteNonGap++;
	        } // end of for
            
            if (numSiteGap > numSiteNonGap)
                indelPrefer = PREFER_DEL;
            else 
            {
                indelPrefer = PREFER_INS;
                bDelEvent = false;
            } // end of else
        } // end of if

        int branchIndex = 1 ;
        annotatePhyloTreeEx(pNode, &branchIndex);
		makeNodeAnnotation(pNode);
		makeBranchAnnotation(pNode);
    }
    
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {	
        bool bLast= false;
        PhyloTreeNode* pNode = rootNodeSet.at(i);
        if(i == (rootNodeSet.size()-1)) bLast = true;
        summaryInterAnchorEx(pNode, bLast);
    }
}

PhyloTreeSet::PhyloTreeSet(int index, map<int, vector<int> >* treeTopology, int numSeq, vector<string>* seqVector
                            , TInterAnchor* tInt)
{
	rootIndex = index;
	treeMap = treeTopology;
	nSeq=numSeq;
    seqVec = seqVector; 
    tInterAnchor = tInt;
    iaIndex = -1;
    numBranch = tInterAnchor->getNumBranch();
    totalBranch = new TotalBranch(numBranch);
    searchBest = NULL;
    totalScore = 0;
    indelPrefer = PREFER_INS;
    bDelEvent = false;
    //bitMap = bmap;

    baseVec.push_back('A');
    baseVec.push_back('C');
    baseVec.push_back('G');
    baseVec.push_back('T');
    baseVec.push_back('-');

    makePhyloTree();
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {	
	    PhyloTreeNode* pNode = rootNodeSet.at(i);

        int branchIndex = 1 ;
        annotatePhyloTreeEx(pNode, &branchIndex);
		makeNodeAnnotation(pNode);
		makeBranchAnnotation(pNode);
    }
    
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {	
        bool bLast= false;
        PhyloTreeNode* pNode = rootNodeSet.at(i);
        if(i == (rootNodeSet.size()-1)) bLast = true;
        summaryInterAnchorEx(pNode, bLast);
    }
}

PhyloTreeSet::~PhyloTreeSet()
{
    // free momery for tree
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {
        // create the score matrix  
        PhyloTreeNode* pNode = rootNodeSet.at(i);
    	// recursive free memory
        freeMemory(pNode);
    } // end of for

    // free memory for totalbrahcn
    if (totalBranch != NULL) delete totalBranch;
}

void PhyloTreeSet::makePhyloTree()
{
	int rIndex = rootIndex;
	int lenInterAnchor = (int)seqVec->at(0).length();

	for(int j=0; j < lenInterAnchor; j++)
	{
        map<int, PhyloTreeNode*>* leafMap = new map<int, PhyloTreeNode*>();
		PhyloTreeNode* root = new PhyloTreeNode();

        int bIndex = 1;
		makePhyloTreeForSites(root, rIndex, j, NULL, leafMap, &bIndex);
        
        rootNodeSet.push_back(root);
        delete leafMap;
	}
}

void PhyloTreeSet::makePhyloTreeForSites(PhyloTreeNode* phyloTree, int rootIndex, int cIndex, PhyloTreeNode* pNode, map<int, PhyloTreeNode*>* leafMap, int* bIndex)
{
    int currentIndex = cIndex;
	if (rootIndex > nSeq)
	{
		vector<int> childIndex = treeMap->operator[](rootIndex);
		int leftCIndex = childIndex.at(0);
		int rightCIndex = childIndex.at(1);
        
        int leftBIndex = *bIndex;

		// if left child is leaf node
        PhyloTreeNode* leftTree = new PhyloTreeNode();
        PhyloTreeNode* rightTree = new PhyloTreeNode();
        phyloTree->setLeftChild(leftTree);
        phyloTree->setRightChild(rightTree);
        phyloTree->setParent(pNode);

        tInterAnchor->setBranchNumForSeq(leftCIndex, leftBIndex);
		if(leftCIndex <= nSeq) 
		{	
			leftTree->setParent(phyloTree);
			leftTree->setBase((seqVec->at(leftCIndex-1)).at(currentIndex));
        } // end of if 
        else 
		{
			//recursive call
            (*bIndex) += 1;
			makePhyloTreeForSites(leftTree, leftCIndex, currentIndex, phyloTree, leafMap, bIndex);		
		} // end of else

        (*bIndex) += 1;
        int rightBIndex = *bIndex;
        tInterAnchor->setBranchNumForSeq(rightCIndex, rightBIndex);
		if (rightCIndex <= nSeq)
		{
			rightTree->setParent(phyloTree);
			rightTree->setBase((seqVec->at(rightCIndex-1)).at(currentIndex));
        } // end of if
		else 
		{
			//recursive call
            (*bIndex) += 1;
			makePhyloTreeForSites(rightTree, rightCIndex, currentIndex, phyloTree, leafMap, bIndex);	
		} // end of else
	} // end of if 
    else
    {
	    phyloTree->setParent(pNode);
        phyloTree->setBase((seqVec->at(rootIndex-1)).at(currentIndex));
        leafMap->operator[](rootIndex) = phyloTree;
    } // end of else
}

void PhyloTreeSet::dump()
{
    cerr << "Total number of trees:" << (int)rootNodeSet.size() << endl;
    for (int i = 0; i < (int)rootNodeSet.size(); i++)
    {
        cerr << endl;
        cerr << "New root node---" << endl;
        PhyloTreeNode* pNode= rootNodeSet.at(i);
	    if (pNode->getParent() == NULL)
		    cerr << "Ok... parent of root node is NULL" << endl;
        dumpTree(pNode);
        cerr << endl;
    } // end of for
}

void PhyloTreeSet::dumpTree(PhyloTreeNode* pNode)
{
    cerr << "    Base:" << pNode->getBase() << endl;
    
    PhyloTreeNode* pLeft = pNode->getLeftChild();
    if (pLeft != NULL)
    {
        cerr << "base of left:" << pLeft->getBase() << endl;
	    cerr << "branch of left:" << pNode->getLeftBranchAnnotation() << endl;
        PhyloTreeNode* parentNode = pLeft->getParent();
    } // end of if

    PhyloTreeNode* pRight = pNode->getRightChild();
    if (pRight != NULL)
    {
        cerr << "base of right:" << pRight->getBase() << endl;
	    cerr << "branch of right:" << pNode->getRightBranchAnnotation() << endl;
        PhyloTreeNode* parentNode = pRight->getParent();
    } // end of if

    cerr << "    Left child: " << endl;
    if (pLeft != NULL) dumpTree(pLeft);
    cerr << "    Right child: " << endl;
    if (pRight != NULL) dumpTree(pRight);
}

void PhyloTreeSet::freeMemory(PhyloTreeNode* pNode)
{
    if (pNode == NULL) return;

    PhyloTreeNode* leftChild = pNode->getLeftChild();
    PhyloTreeNode* rightChild = pNode->getRightChild();

    if (leftChild != NULL) freeMemory(leftChild);
    if (rightChild != NULL) freeMemory(rightChild);

    pNode->setLeftChild(NULL);
    pNode->setRightChild(NULL);

    delete pNode;
    pNode = NULL;
}

void PhyloTreeSet::annotatePhyloTree(PhyloTreeNode* pTree, int* bIndex)
{
    PhyloTreeNode* leftNode = pTree->getLeftChild();
    PhyloTreeNode* rightNode = pTree->getRightChild();
    int leftBIndex = *bIndex;

    if(leftNode->getLeftChild() != NULL)
    {       
        (*bIndex) += 1;
        annotatePhyloTree(leftNode, bIndex);
    } // end of if

    (*bIndex) += 1;
    int rightBIndex = (*bIndex);
     if(rightNode->getLeftChild() != NULL)
    {       
        (*bIndex) += 1;
        annotatePhyloTree(rightNode, bIndex);
    } // end of if

    double lbLength = tInterAnchor->getBranchLenAt(leftBIndex);
    double rbLength = tInterAnchor->getBranchLenAt(rightBIndex);
    
    // annotate current node
    double bestScore = (double)NodeScoreMatrixPrev::MAX_EVENT;
    for(int i=0; i< (int)baseVec.size(); i++)
	{
        char nodeCh = baseVec.at(i);
        
        // check left child
        double leftBestScore = (double)NodeScoreMatrixPrev::MAX_EVENT;
        char leftBestChar = 'A';
        for (int chIndex = 0; chIndex < (int)baseVec.size(); chIndex++)
        {
            double score = 0.0;
            char leftCh = baseVec.at(chIndex);  

            if (leftCh != nodeCh) score += (1.0 / (double)lbLength);
            score += leftNode->getScore(leftCh);

            if (score < leftBestScore)
            {
                leftBestScore = score;
                leftBestChar = leftCh;
            } // end of if
        } //end of for

        // check right child
        double rightBestScore = (double)NodeScoreMatrixPrev::MAX_EVENT;
        char rightBestChar = 'A';
        for (int chIndex = 0; chIndex < (int)baseVec.size(); chIndex++)
        {
            double score = 0;
            char rightCh = baseVec.at(chIndex);  

            if (rightCh != nodeCh) score += (1.0 / (double)rbLength);
            score += rightNode->getScore(rightCh);

            if (score < rightBestScore)
            {
                rightBestScore = score;
                rightBestChar = rightCh;
            } // end of if
        } //end of for
        pTree->setSelectedLeftBase(nodeCh, leftBestChar);
        pTree->setSelectedRightBase(nodeCh, rightBestChar);
        pTree->setScore(nodeCh, leftBestScore + rightBestScore);
    } // end of for
    
}

void PhyloTreeSet::annotatePhyloTreeEx(PhyloTreeNode* pTree, int* bIndex)
{
    PhyloTreeNode* leftNode = pTree->getLeftChild();
    PhyloTreeNode* rightNode = pTree->getRightChild();
    int leftBIndex = *bIndex;

    if(leftNode->getLeftChild() != NULL)
    {       
        (*bIndex) += 1;
        annotatePhyloTreeEx(leftNode, bIndex);
    } // end of if

    (*bIndex) += 1;
    int rightBIndex = *bIndex;

     if(rightNode->getLeftChild() != NULL)
    {       
        (*bIndex) += 1;
        annotatePhyloTreeEx(rightNode, bIndex);
    } // end of if

    double lbLength = tInterAnchor->getBranchLenAt(leftBIndex);
    double rbLength = tInterAnchor->getBranchLenAt(rightBIndex);

    // annotate current node
    double bestScore = (double)NodeScoreMatrixPrev::MAX_EVENT;
    for(int i=0; i< (int)baseVec.size(); i++)
	{
        char nodeCh = baseVec.at(i);
        
        // check left child
        double leftBestScore = (double)NodeScoreMatrixPrev::MAX_EVENT;
        char leftBestChar = 'A';
        for (int chIndex = 0; chIndex < (int)baseVec.size(); chIndex++)
        {
            double score = 0.0;
            char leftCh = baseVec.at(chIndex);  

            if (leftCh != nodeCh) score += (1.0 / (double)lbLength);
            score += leftNode->getScore(leftCh);

            if (indelPrefer == PREFER_INS)  // default
            {
                if (score < leftBestScore)
                {
                    leftBestScore = score;
                    leftBestChar = leftCh;
                } // end of if
            } // end of if
            else    // indelPrefer == PREFER_DEL
            {
                if (score < leftBestScore && leftCh != '-')
                {
                    leftBestScore = score;
                    leftBestChar = leftCh;
                } // end of if
            } // end of else
        } //end of for

        // check right child
        double rightBestScore = (double)NodeScoreMatrixPrev::MAX_EVENT;
        char rightBestChar = 'A';
        for (int chIndex = 0; chIndex < (int)baseVec.size(); chIndex++)
        {
            double score = 0;
            char rightCh = baseVec.at(chIndex);  

            if (rightCh != nodeCh) score += (1.0 / (double)rbLength);
            score += rightNode->getScore(rightCh);

            if (indelPrefer == PREFER_INS)  // default
            {
                if (score < rightBestScore)
                {
                    rightBestScore = score;
                    rightBestChar = rightCh;
                } // end of if
            } // end of if
            else    // indelPrefer == PREFER_DEL
            {
                if (score < rightBestScore && rightCh != '-')
                {
                    rightBestScore = score;
                    rightBestChar = rightCh;
                } // end of if
            } // end of else
        } //end of for
        pTree->setSelectedLeftBase(nodeCh, leftBestChar);
        pTree->setSelectedRightBase(nodeCh, rightBestChar);
        pTree->setScore(nodeCh, leftBestScore + rightBestScore);
    } // end of for
}

void PhyloTreeSet::makeNodeAnnotation(PhyloTreeNode* rNode)
{
	char optimalRootBase;
	double optimalScore=(double)NodeScoreMatrixPrev::MAX_EVENT;

    for(int i=0; i<(int)baseVec.size(); i++)
	{
		char candiBase = baseVec.at(i);
		double score= rNode->getScore(candiBase);

		if(score < optimalScore)
		{
			optimalScore = score;
			optimalRootBase = candiBase;
		} // end of if
	} // end of for
	
	rNode->setBase(optimalRootBase);
	makeSubAnnotation(rNode, optimalRootBase);
}

void PhyloTreeSet::makeSubAnnotation(PhyloTreeNode* rNode, char optimalBase)
{
	
	char optimalLeftBase = rNode->getSelectedLeftBase(optimalBase);
	char optimalRightBase = rNode->getSelectedRightBase(optimalBase);
	
	PhyloTreeNode* leftNode = rNode->getLeftChild();
	PhyloTreeNode* rightNode = rNode->getRightChild();
	
	if(leftNode->getLeftChild() != NULL)
	{
		leftNode->setBase(optimalLeftBase);
		makeSubAnnotation(leftNode, optimalLeftBase);
	}

	if(rightNode->getRightChild() != NULL)
	{
		rightNode->setBase(optimalRightBase);
		makeSubAnnotation(rightNode, optimalRightBase);
	}
	
}

void PhyloTreeSet::makeBranchAnnotation(PhyloTreeNode* rNode)
{
    PhyloTreeNode* leftNode;
    PhyloTreeNode* rightNode;

    leftNode = rNode->getLeftChild();
	rightNode = rNode->getRightChild();

	char parentBase = rNode->getBase();
	char leftBase = leftNode->getBase();
	char rightBase = rightNode->getBase();

	// parentBase is not a gap
	if(parentBase != '-') 
	{
        if(leftBase == parentBase) rNode->setLeftBranchAnnotation(PhyloTreeNode::MATCH);
		else if(leftBase == '-')
        {
            rNode->setLeftBranchAnnotation(PhyloTreeNode::DELETION);
            if (leftNode->getLeftChild() == NULL) bDelEvent = true;
        } // end of else
        else if(leftBase == 'N') rNode->setLeftBranchAnnotation(PhyloTreeNode::NOEVENT);
        else rNode->setLeftBranchAnnotation(PhyloTreeNode::MISMATCH);

        if(rightBase == parentBase) rNode->setRightBranchAnnotation(PhyloTreeNode::MATCH);
		else if(rightBase == '-')
        {
			rNode->setRightBranchAnnotation(PhyloTreeNode::DELETION);
            if (rightNode->getRightChild() == NULL) bDelEvent = true;
        } // end of else
        else if(rightBase == 'N') rNode->setRightBranchAnnotation(PhyloTreeNode::NOEVENT);
        else rNode->setRightBranchAnnotation(PhyloTreeNode::MISMATCH);

		if(leftNode->getLeftChild() != NULL) makeBranchAnnotation(leftNode);
		if(rightNode->getRightChild() != NULL) makeBranchAnnotation(rightNode);
	} // end of if
	else // parentBase has gap
	{
		if(leftBase == parentBase)
        {
            rNode->setLeftBranchAnnotation(PhyloTreeNode::NOEVENT);
        } // end of if
		else 
			rNode->setLeftBranchAnnotation(PhyloTreeNode::INSERTION);

        if(rightBase == parentBase)
        {
            rNode->setRightBranchAnnotation(PhyloTreeNode::NOEVENT);
        } // end of if
        else
        rNode->setRightBranchAnnotation(PhyloTreeNode::INSERTION);

		if(leftNode->getLeftChild() != NULL) makeBranchAnnotation(leftNode);
		if(rightNode->getRightChild() != NULL) makeBranchAnnotation(rightNode);
	}
}

void PhyloTreeSet::summaryInterAnchor(int colIndex, PhyloTreeNode* pTree, bool bLast)
{
    int branchIndex =1;
    aux_summaryInterAnchor(colIndex, pTree, &branchIndex, bLast);
}

// calling if node is not left node
void PhyloTreeSet::aux_summaryInterAnchor(int colIndex, PhyloTreeNode* pTree, int* branchIndex, bool bLast)
{
    PhyloTreeNode* leftNode = pTree->getLeftChild();
    PhyloTreeNode* rightNode = pTree->getRightChild();

    int leftBIndex = *branchIndex;

    int leftBranch = pTree->getLeftBranchAnnotation();
    int rightBranch = pTree->getRightBranchAnnotation();
    
    tInterAnchor->addBranchSummary(iaIndex, colIndex, leftBIndex, leftBranch, 1, bLast);
    
    if(leftNode->getLeftChild() != NULL)
    {       
        (*branchIndex) += 1;
        aux_summaryInterAnchor(colIndex, leftNode, branchIndex, bLast);
    } // end of if

    (*branchIndex) += 1;
    int rightBIndex = *branchIndex;
    tInterAnchor->addBranchSummary(iaIndex, colIndex, rightBIndex, rightBranch, 1, bLast);

    if(rightNode->getRightChild() != NULL)
    {   
        (*branchIndex) += 1;
        aux_summaryInterAnchor(colIndex, rightNode, branchIndex, bLast);
    } // end of if
}

void PhyloTreeSet::summaryInterAnchorEx(PhyloTreeNode* pTree, bool bLast)
{
    int branchIndex =1;
    aux_summaryInterAnchorEx(pTree, &branchIndex, bLast);
}

// calling if node is not left node
void PhyloTreeSet::aux_summaryInterAnchorEx(PhyloTreeNode* pTree, int* branchIndex, bool bLast)
{
    PhyloTreeNode* leftNode = pTree->getLeftChild();
    PhyloTreeNode* rightNode = pTree->getRightChild();

    int leftBIndex = *branchIndex;

    int leftBranch = pTree->getLeftBranchAnnotation();
    totalBranch->addBranchInfo(leftBIndex, leftBranch, 1, bLast);
    
    if(leftNode->getLeftChild() != NULL)
    {       
        (*branchIndex) += 1;
        aux_summaryInterAnchorEx(leftNode, branchIndex, bLast);
    } // end of if

    (*branchIndex) += 1;
    int rightBIndex = *branchIndex;
    int rightBranch = pTree->getRightBranchAnnotation();
    totalBranch->addBranchInfo(rightBIndex, rightBranch, 1, bLast);

    if(rightNode->getRightChild() != NULL)
    {   
        (*branchIndex) += 1;
        aux_summaryInterAnchorEx(rightNode, branchIndex, bLast);
    } // end of if
}

double PhyloTreeSet::getScore()
{
    if (totalScore != 0) return totalScore;

    double constMut = searchBest->getConstMut();
    double constIns = searchBest->getConstIns();
    double constDel = searchBest->getConstDel();
    int lenDist = searchBest->getLenDist();
    double insLenAvg = searchBest->getInsLenAvg();
    double delLenAvg = searchBest->getDelLenAvg();
    double insLambda = searchBest->getInsLambda();
    double delLambda = searchBest->getDelLambda();
    double insrzeta = searchBest->getInsRZeta();
    double delrzeta = searchBest->getDelRZeta();
    double insProbSuccess = searchBest->getInsProbSuccess();
    double delProbSuccess = searchBest->getDelProbSuccess();
    double totalScore = 0.0;

//dump();
#ifdef DEBUG_OUTPUT
cerr << endl;
cerr << "<-- Scoring of the inter-anchor" << endl;
#endif
	for (int bIndex = 1; bIndex <= numBranch; bIndex++)
	{
#ifdef DEBUG_OUTPUT
        cerr << "<Branch:" << bIndex << ">" << endl;
#endif
        double bLength = (double)tInterAnchor->getBranchLenAt(bIndex);
		vector<double> numVec;
        int numMat = 0;
		int numMut = 0;
		int numIns = 0;
        int numNonIns = 0;
		int numDel = 0;
        int numNonDel = 0;
        double prInsLen=0.0;
        double prDelLen=0.0;

        vector<int> insLenVec;
        vector<int> delLenVec;

		BranchInfo* bInfo = totalBranch->getBranchInfoAt(bIndex);
	    numMat += bInfo->getNumOfMatch();
		numMut += bInfo->getNumOfMisMatch();
		numIns += bInfo->getNumOfInsertion();
		numDel += bInfo->getNumOfDeletion();
        numNonIns += bInfo->getNumOfNonInsertion();
		numNonDel += bInfo->getNumOfNonDeletion();

        vector<int>* pVec = bInfo->getInsLenVec();
        for (int vi = 0; vi < (int)pVec->size(); vi++)
            insLenVec.push_back(pVec->at(vi));  

        pVec = bInfo->getDelLenVec();
        for (int vi = 0; vi < (int)pVec->size(); vi++)
            delLenVec.push_back(pVec->at(vi));  
 
        double prMut = constMut * bLength;
	    double prIns = constIns * bLength;
	    double prDel =constDel * bLength;

#ifdef DEBUG_OUTPUT
cerr << "constMut:" << constMut << ", bLength:" << bLength << ", Mutation Probability : " << prMut << endl;
cerr << "constIns:" << constIns << ", bLength:" << bLength << ",Insertion Probability: " << prIns << endl;
cerr << "constDel:" << constDel << ", bLength:" << bLength << ",Deletion Probability : " << prDel << endl;
#endif

        if (prMut != 0.0) totalScore += (log(prMut) * numMut);
#ifdef DEBUG_OUTPUT
        cerr << "numMut:" << numMut << ", score:" << (log(prMut) * numMut) << endl;
#endif
		if ((1 - prMut) != 0.0) totalScore += (log(1 - prMut) * numMat);
#ifdef DEBUG_OUTPUT
        cerr << "numMat:" << numMat << ", score:" << (log(1 - prMut) * numMat) << endl;
#endif

        if (prIns != 0.0) totalScore += (log(prIns) * numIns);
#ifdef DEBUG_OUTPUT
        cerr << "numIns:" << numIns << ", score:" << (log(prIns) * numIns) << endl;
#endif
		if ((1 - prIns) != 0.0) totalScore += (log(1 - prIns) * numNonIns);  
#ifdef DEBUG_OUTPUT
        cerr << "numNonIns:" << numNonIns << ", score:" << (log(1 - prIns) * numNonIns) << endl;
#endif
   
        prInsLen = 0;
        for(int i=0; i<(int)insLenVec.size(); i++)
        {
            int len = insLenVec.at(i);
            if (lenDist == Param::LDIST_PS) 
            {
                prInsLen = prInsLen + log(Util::getLenProb(lenDist, len, insLenAvg, 0.0, 0.0));
#ifdef DEBUG_OUTPUT
                cerr << "Insertion Length:" << len << ", score:" << log(Util::getLenProb(lenDist, len, insLenAvg, 0.0, 0.0)) << endl;
#endif
            }
            else if (lenDist == Param::LDIST_PL)
            {
                prInsLen = prInsLen + log(Util::getLenProb(lenDist, len, insLambda, insrzeta, 0.0));
#ifdef DEBUG_OUTPUT
                cerr << "Insertion Length:" << len << ", score:" << log(Util::getLenProb(lenDist, len, insLambda, insrzeta, 0.0)) << endl;
#endif
            }
            else if (lenDist == Param::LDIST_GM)
            {
                prInsLen = prInsLen + log(Util::getLenProb(lenDist, len, 0.0, 0.0, insProbSuccess));
            }
        }
#ifdef DEBUG_OUTPUT
        cerr << "total score of insertion len:" << prInsLen << endl;
#endif
        totalScore += prInsLen; 
        
        if (prDel != 0.0) totalScore += (log(prDel) * numDel);
#ifdef DEBUG_OUTPUT
        cerr << "numDel:" << numDel << ", score:" << (log(prDel) * numDel) << endl;
#endif
		if ((1 - prDel) != 0.0) totalScore += (log(1 - prDel) * numNonDel); 
#ifdef DEBUG_OUTPUT
        cerr << "numNonDel:" << numNonDel << ", score:" << (log(1 - prDel) * numNonDel) << endl;
#endif
        
        prDelLen = 0;
        for(int i=0; i<(int)delLenVec.size(); i++)
        {
            int len = delLenVec.at(i);
            if (lenDist == Param::LDIST_PS) 
            {
                prDelLen += log(Util::getLenProb(lenDist, len, delLenAvg, 0.0, 0.0));
#ifdef DEBUG_OUTPUT
                cerr << "Deletion Length:" << len << ", score:" << log(Util::getLenProb(lenDist, len, delLenAvg, 0.0, 0.0)) << endl;
#endif
            }
            else if (lenDist == Param::LDIST_PL)
            {
                prDelLen += log(Util::getLenProb(lenDist, len, delLambda, delrzeta, 0.0));
#ifdef DEBUG_OUTPUT
                cerr << "Deletion Length:" << len << ", score:" << log(Util::getLenProb(lenDist, len, delLambda, delrzeta, 0.0)) << endl;
#endif
            }
            else if (lenDist == Param::LDIST_GM)
            {
                prDelLen += log(Util::getLenProb(lenDist, len, 0.0, 0.0, delProbSuccess));
            }
        }
#ifdef DEBUG_OUTPUT
        cerr << "total score of deletion len:" << prDelLen << endl;
#endif
        totalScore += prDelLen;
        
	} // end of for bIndex

#ifdef DEBUG_OUTPUT
cerr << "End of scoring of the inter-anchor -->" << endl;
#endif
    return totalScore;
}

int PhyloTreeSet::getNumTree()
{
    return (int)rootNodeSet.size();
}

PhyloTreeNode* PhyloTreeSet::getRootNodeAt(int index)
{
    return rootNodeSet.at(index);
}

TotalBranch* PhyloTreeSet::getTotalBranch()
{
    return totalBranch;
}

void PhyloTreeSet::freeNodeMemory()
{
    for (int i = 0; i < rootNodeSet.size(); i++) //vector<PhyloTreeNode*> rootNodeSet;
    {
        PhyloTreeNode* pNode = rootNodeSet.at(i);
        freeMemory(pNode);
    } // end of for

    rootNodeSet.clear();
}

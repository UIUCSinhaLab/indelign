// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include "Util.h"

using namespace std;

string trim(string str)
{
    int windex = 0;
    // Remove whitespaces at the front of the string
    while (windex < str.length())
    {
        if (str.at(windex) != ' ' && str.at(windex) != '\t' && str.at(windex) != '\n') break;
        windex++;
    } // end of while
    str = str.substr(windex);

    // Remove wihtespaces at the end of the string
    windex = str.length();
    windex--;
    while (windex >= 0)
    {
        if (str.at(windex) != ' ' && str.at(windex) != '\t' && str.at(windex) != '\n') break;
        windex--;
    } // end of while
    str = str.substr(0, windex + 1);

    return str;
}

void aux_findSubAnchors(vector<string>* pVec, int seqNum1, string seq1, int seqNum2, string seq2, map<int, int>* anchorStat)
{
    int numMisMatch = 0;
    int startIndex = 0;
    int numCol = 0;
    int seqColNum = seq1.length();
    for (int i = 0; i < seqColNum; i++)
    {
        char ch1 = seq1.at(i);
        char ch2 = seq2.at(i);

        if (ch1 == '-' || ch2 == '-')
        {
            // stop recording sub-anchor information
            if (numCol >= 10 && numMisMatch <= anchorStat->operator [](numCol))
            {

                // Find sub-anchor
                for (int j = startIndex; j <= i; j++)
                {
                    (pVec->operator [](seqNum1 - 1)).at(j) = 'A';
                    (pVec->operator [](seqNum2 - 1)).at(j) = 'A';
                } // end of for
            } // end of if

            // reset variables
            numMisMatch = 0;
            numCol = 0;
            startIndex = i + 1;
        } // end of if
        else if (ch1 == ch2 && ch1 != 'N')
        {
            // match case
            numCol++;

            // stop recording sub-anchor information
            if (numCol >= 10 && numMisMatch <= anchorStat->operator [](numCol))
            {

                // Find sub-anchor
                for (int j = startIndex; j <= i; j++)
                {
                    (pVec->operator [](seqNum1 - 1)).at(j) = 'A';
                    (pVec->operator [](seqNum2 - 1)).at(j) = 'A';
                } // end of for

                // reset variables
                numMisMatch = 0;
                numCol = 0;
                startIndex = i + 1;
            } // end of if
            
        } // end of else if
        else
        {
            // mismatch case
            numCol++;
            numMisMatch++;

            // stop recording sub-anchor information
            if (numCol >= 10 && numMisMatch <= anchorStat->operator [](numCol))
            {

                // Find sub-anchor
                for (int j = startIndex; j <= i; j++)
                {
                    (pVec->operator [](seqNum1 - 1)).at(j) = 'A';
                    (pVec->operator [](seqNum2 - 1)).at(j) = 'A';
                } // end of for

                // reset variables
                numMisMatch = 0;
                numCol = 0;
                startIndex = i + 1;
            } // end of if
        } // end of else

        if (numCol > 50)
        {
            // reset variables
            numMisMatch = 0;
            numCol = 0;
            startIndex = i + 1;
        } // end of if
    } // end of for
}

int main(int argc, char* argv[])
{
    //int nSeq = 3;

    if (argc != 3)
    {
        cout << endl;
        cout << "Usage: FindAnchor filename num_of_seq" << endl;
        return 1;
    } // end of if

    char * buffer;
    buffer = getenv ("INDELIGN_DIR");
    if (buffer==NULL)
    {
        cerr << "No definition of the environment variable: INDELIGN_DIR" << endl;
        cerr << "Please define the INDELIGN_DIR environment variables." << endl;
        return 1;
    } // end of if
    cout << "INDELIGN_DIR:" << buffer << endl;
    string str1(buffer);
    str1 += "/AnchorStat.txt";

    ifstream infile(str1.c_str());
	string line;
	
    map<int, int> anchorStat;
	if(infile.is_open())
	{
      bool bReady = false;
	  while(!infile.eof())
	  {
	    	getline(infile,line);
            line = trim(line);
		    if(line.length() != 0)
            {
			    int sIndex = line.find('\t');
                string strLen = line.substr(0, sIndex);
                string strMut = line.substr(sIndex + 1);

                int len = atoi(strLen.c_str());
                int mut = atoi(strMut.c_str());
                anchorStat[len] = mut;
		    } // end of if		
	  }
	    infile.close();
	}
    else
    {
        cout << "AnchorStat.txt file open error!" << endl;
        exit(1);
    } // end of else

    string str2(buffer);
    str2 += "/AnchorStat3way.txt";
    ifstream infile2(str2.c_str());
	line = "";
	
    map<int, int> anchorStat3;
	if(infile2.is_open())
	{
      bool bReady = false;
	  while(!infile2.eof())
	  {
	    	getline(infile2,line);
            line = trim(line);
		    if(line.length() != 0)
            {
			    int sIndex = line.find('\t');
                string strLen = line.substr(0, sIndex);
                string strMut = line.substr(sIndex + 1);

                int len = atoi(strLen.c_str());
                int mut = atoi(strMut.c_str());
                anchorStat3[len] = mut;
		    } // end of if		
	  }
	    infile2.close();
	}
    else
    {
        cout << "AnchorStat3way.txt file open error!" << endl;
        exit(1);
    } // end of else

    string fileName = argv[1];
    int nSeq = atoi(argv[2]);
    string outFileStr1 = fileName;
    string outFileStr2 = fileName;
    //fileName.append(".fa");
    outFileStr1.append("-anchor1");
    outFileStr2.append("-anchor2");
    // file open
    ifstream seqFile(fileName.c_str());
    if (!seqFile)
    {
        cerr << "Error opening aligned file: " << argv[1] << endl;
        seqFile.close();
        return 1;
    } // end of if

    vector<string> seqVec;
    if(seqFile.is_open())
	{
        string str = "";
	  while(!seqFile.eof())
	  {
	    	getline(seqFile,line);
            if(line.length() == 0) continue;

		if(line.at(0) == '>'){
            if (str.length() > 0)
            {
                seqVec.push_back(str);
                str = "";
            }
		}		
		// whenever reading the 1 interanchor, add the wholeInAnchor
		else{
            // Make upper case string!
            line = Util::toUpper(line);
            str.append(trim(line));
		}
	  }
      seqVec.push_back(str);
	seqFile.close();
	}

    // find anchors and sub-anchors
    vector<string> ancVec;
    int colNum = seqVec.at(0).length();

    for (int i = 0; i < nSeq; i++)
    {
        string str = "";
        str.append(colNum, '-');
        ancVec.push_back(str);
    } // end of for

    // use seqVec
    // 2. for each two sequences
    for (int i = 0; i < seqVec.size() - 1; i++)
    {
        for (int j = i + 1; j < seqVec.size(); j++)
        {
            string seq1 = seqVec.at(i);
            string seq2 = seqVec.at(j);
            aux_findSubAnchors(&ancVec, i + 1, seq1, j + 1, seq2, &anchorStat);
            
        } // end of for
    } // end of for
    
    ofstream outFile1(outFileStr1.c_str());
    if (!outFile1)
    {
        cout << "Error opening output file: " << outFileStr1 << "." << endl;
        outFile1.close();
        return 1;
    } // end of if

    ofstream outFile2(outFileStr2.c_str());
    if (!outFile2)
    {
        cout << "Error opening output file: " << outFileStr2 << "." << endl;
        outFile2.close();
        return 1;
    } // end of if

    int anchorStart = 0;
    int anchorEnd = 0;
    bool bAnchorStart = false;
    vector<vector<int> > posVec;
    int agreedColCnt = 0;
    for (int i = 0; i < colNum; i++)
    {
        bool bAllMarked = true;
        for (int j = 0; j < ancVec.size(); j++)
        {
            if (ancVec.at(j).at(i) != 'A')
            {
                bAllMarked = false;
                break;
            } // end of if
        } // 

        if (bAllMarked == true)
        {
            if (bAnchorStart == false)
            {
                anchorStart = i;
                bAnchorStart = true;
            } // end of if
        } // end of if
        else
        {
            if (bAnchorStart == true && i - (anchorStart + 1) + 1 >= 10)
            {
                bAnchorStart = false;

                // Write the result
                if (anchorStart > 0)
                {
                    for (int j = 0; j < nSeq; j++)
                        outFile2 << seqVec.at(j).substr(anchorEnd, anchorStart - anchorEnd) << endl;
                    outFile2 << endl;
                } // end of if
                
                vector<int> tmpVec;
                tmpVec.push_back(anchorStart + 1);
                tmpVec.push_back(i);
                posVec.push_back(tmpVec);
                anchorEnd = i;
            } // end of if
            else
            {
                anchorStart = i + 1;
            } // end of else
        } // end of else
    } // end of for

    // last chunk check
    if (bAnchorStart == true && colNum - (anchorStart + 1) + 1 >= 10)
    {
        // Write the result
        for (int j = 0; j < nSeq; j++)
            outFile2 << seqVec.at(j).substr(anchorEnd, anchorStart - anchorEnd) << endl;
        outFile2 << endl;
        
        vector<int> tmpVec;
        tmpVec.push_back(anchorStart + 1);
        tmpVec.push_back(colNum);
        posVec.push_back(tmpVec);
    } // end of if
    else
    {
        for (int j = 0; j < nSeq; j++)
            outFile2 << seqVec.at(j).substr(anchorEnd, colNum - anchorEnd) << endl;
        outFile2 << endl;
    } // end of else

    outFile1 << colNum << endl;
    outFile1 << posVec.size() << endl;
    for (int i = 0; i < posVec.size(); i++)
    {
        vector<int> tmpVec = posVec.at(i);
        outFile1 << tmpVec.at(0) << " " << tmpVec.at(1) << endl;
    } // end of for

    outFile1.close();
    outFile2.close();

    cout << "The process successfully completed." << endl;
    cout << "Output files are " << outFileStr1 << " and " << outFileStr2 << "." << endl;

    return 0;

}

// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "TotalBranch.h"
#include "PhyloTreeNode.h"

TotalBranch::TotalBranch()
{
    
}

TotalBranch::TotalBranch(int numB)
{
	for (int i = 0; i < numB; i++)
	{
		BranchInfo* bInfo = new BranchInfo();
		branchMap[i + 1] = bInfo;
        insMap[i + 1] = 0;
        delMap[i + 1] = 0;
		insSIndexMap[i + 1] = -1;
		delSIndexMap[i + 1] = -1;
	} // end of for
}

TotalBranch::~TotalBranch()
{
	map<int, BranchInfo*>::iterator theIter;
	for (theIter = branchMap.begin(); theIter != branchMap.end(); theIter++)
	{
		BranchInfo* bInfo = theIter->second;
		if (bInfo != NULL) delete bInfo;
	} // end of for
    branchMap.clear();
    map<int, BranchInfo*>().swap(branchMap);
}

// Parameter:
//		bNum: branch number
//		infoType: info type - PhyloTreeNode::MATCH, PhyloTreeNode::MISMATCH, PhyloTreeNode::INSERTION, PhyloTreeNode::DELETION
//		value: if match, number of match(usually 1), if insertion or deletion, the length
void TotalBranch::addBranchInfo(int bNum, int infoType, int value, bool bLast)
{
    BranchInfo* bInfo = branchMap[bNum];
	if (infoType == PhyloTreeNode::MATCH || infoType == PhyloTreeNode::MISMATCH)
    {
        if (infoType == PhyloTreeNode::MISMATCH) bInfo->addMisMatch(value);
        if (infoType == PhyloTreeNode::MATCH) bInfo->addMatch(value);

        // insert info for stored insertion and deletion
        int insNum = insMap[bNum];
        if (insNum > 0)
        {
            bInfo->addInsertion(insNum);
            insMap[bNum] = 0;
        } // end of if

        int delNum = delMap[bNum];
        if (delNum > 0)
        {
            bInfo->addDeletion(delNum);
            delMap[bNum] = 0;
        } // end of if
    } // end of if
    else if (infoType == PhyloTreeNode::INSERTION) 
    {
        int insNum = insMap[bNum];
        insNum++;
        insMap[bNum] = insNum;

        // check for deletion
        int delNum = delMap[bNum];
        if (delNum > 0)
        {
            bInfo->addDeletion(delNum);
            delMap[bNum] = 0;
        } // end of if

        // for handling the last column
        if (bLast == true)
        {
            insNum = insMap[bNum];
            if (insNum > 0)
            {
                bInfo->addInsertion(insNum);
                insMap[bNum] = 0;
            } // end of if
        } // end of ir
    } // end of else if
	else if (infoType == PhyloTreeNode::DELETION)
    {
        int delNum = delMap[bNum];
        delNum++;
        delMap[bNum] = delNum;
        
        // check for insertion
        int insNum = insMap[bNum];
        if (insNum > 0)
        {
            bInfo->addInsertion(insNum);
            insMap[bNum] = 0;
        } // end of if

        // for handling the last column
        if (bLast == true)
        {
            delNum = delMap[bNum];
            if (delNum > 0)
            {
                bInfo->addDeletion(delNum);
                delMap[bNum] = 0;
            } // end of if
        } // end of if
    } // end of else if
	else {
        // insert info for stored insertion and deletion
        int insNum = insMap[bNum];
        if (insNum > 0)
        {
            bInfo->addInsertion(insNum);
            insMap[bNum] = 0;
        } // end of if

        int delNum = delMap[bNum];
        if (delNum > 0)
        {
            bInfo->addDeletion(delNum);
            delMap[bNum] = 0;
        } // end of if
	} // end of else
}

// Parameter:
//		colIndex: index of a current tree or column
//		bNum: branch number
//		infoType: info type - PhyloTreeNode::MATCH, PhyloTreeNode::MISMATCH, PhyloTreeNode::INSERTION, PhyloTreeNode::DELETION
//		value: if match, number of match(usually 1), if insertion or deletion, the length
void TotalBranch::addBranchInfo(int colIndex, int bNum, int infoType, int value, bool bLast)
{
    BranchInfo* bInfo = branchMap[bNum];
	if (infoType == PhyloTreeNode::MATCH || infoType == PhyloTreeNode::MISMATCH)
    {
        if (infoType == PhyloTreeNode::MISMATCH) bInfo->addMisMatch(value);
        if (infoType == PhyloTreeNode::MATCH) bInfo->addMatch(value);

        // insert info for stored insertion and deletion
        int insNum = insMap[bNum];
        if (insNum > 0)
        {
            bInfo->addInsertion(insSIndexMap[bNum], insNum);
            insMap[bNum] = 0;
			insSIndexMap[bNum] = -1;
        } // end of if

        int delNum = delMap[bNum];
        if (delNum > 0)
        {
            bInfo->addDeletion(delSIndexMap[bNum], delNum);
            delMap[bNum] = 0;
			delSIndexMap[bNum] = -1;
        } // end of if
    } // end of if
    else if (infoType == PhyloTreeNode::INSERTION) 
    {
        int insNum = insMap[bNum];
		if (insNum == 0) insSIndexMap[bNum] = colIndex;
			
        insNum++;
        insMap[bNum] = insNum;

        // check for deletion
        int delNum = delMap[bNum];
        if (delNum > 0)
        {
            bInfo->addDeletion(delSIndexMap[bNum], delNum);
            delMap[bNum] = 0;
			delSIndexMap[bNum] = -1;
        } // end of if

        // for handling the last column
        if (bLast == true)
        {
            insNum = insMap[bNum];
            if (insNum > 0)
            {
                bInfo->addInsertion(insSIndexMap[bNum], insNum);
                insMap[bNum] = 0;
				insSIndexMap[bNum] = -1;
            } // end of if
        } // end of ir
    } // end of else if
	else if (infoType == PhyloTreeNode::DELETION)
    {
        int delNum = delMap[bNum];
		if (delNum == 0) delSIndexMap[bNum] = colIndex;
        delNum++;
        delMap[bNum] = delNum;
        
        // check for insertion
        int insNum = insMap[bNum];
        if (insNum > 0)
        {
            bInfo->addInsertion(insSIndexMap[bNum], insNum);
            insMap[bNum] = 0;
			insSIndexMap[bNum] = -1;
        } // end of if

        // for handling the last column
        if (bLast == true)
        {
            delNum = delMap[bNum];
            if (delNum > 0)
            {
                bInfo->addDeletion(delSIndexMap[bNum], delNum);
                delMap[bNum] = 0;
				delSIndexMap[bNum] = -1;
            } // end of if
        } // end of if
    } // end of else if
	else {
        // insert info for stored insertion and deletion
        int insNum = insMap[bNum];
        if (insNum > 0)
        {
            bInfo->addInsertion(insSIndexMap[bNum], insNum);
            insMap[bNum] = 0;
			insSIndexMap[bNum] = -1;
        } // end of if

        int delNum = delMap[bNum];
        if (delNum > 0)
        {
            bInfo->addDeletion(delSIndexMap[bNum], delNum);
            delMap[bNum] = 0;
			delSIndexMap[bNum] = -1;
        } // end of if
	} // end of else
}

BranchInfo* TotalBranch::getBranchInfoAt(int bNum)
{
	return branchMap[bNum];
}

TotalBranch::TotalBranch(TotalBranch* pTB)
{
    insMap = pTB->insMap;
    delMap = pTB->delMap;
    insSIndexMap = pTB->insSIndexMap;
    delSIndexMap = pTB->delSIndexMap;

    map<int, BranchInfo*>::iterator iter;    
    for (iter = pTB->branchMap.begin(); iter != pTB->branchMap.end(); iter++)
    {
        BranchInfo* bInfo = new BranchInfo(iter->second);
        branchMap[iter->first] = bInfo;
    } // end of for
}

// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef SEARCHBEST_H
#define SEARCHBEST_H

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <stdlib.h>
#include <assert.h>
#include <algorithm>
#include "NodeScoreMatrixSet.h"
#include "TInterAnchor.h"
#include "BoundaryChunk.h"
#include "PhyloTreeNodeEx.h" 
#include "SeqGen.h"
#include "rand.h"
#include "BranchInfoSet.h"
#include "AnnInfoSet.h"
#include "Param.h"

#define NUM_SUB_ITER 50
#define NUM_ITER 1

// Allowed maximum number of dependent blocks
#define MAX_DEPT_BLOCKS 10

using namespace std;

class SearchBest {

private:
  TInterAnchor* tInterAnchor;
  int nSeq;
  bool notRe;
  int numShift;
  int lenDist;
    bool includeAnchor;

  map<int,double> branchLength;

  double constMut;
  double constIns;
  double constDel;

  double sumOfLenSquare;

  double bestScore;
  double bestIAScore;
  map<int, vector<string> > possibleSeq;
  double interanchorScore;

  map<int, BoundaryChunk> subBChunkMap;   // subiteration 
  map<int, vector<BestAnnotation> > subBestScoreIAnchorMap;

  map<int, BoundaryChunk> bestBChunkMap; 
  map<int, vector<BestAnnotation> > bestBestScoreIAnchorMap;

  map<int, BoundaryChunk> initialChunkMap; 
  map<int, vector<BestAnnotation> > initialScoreIAnchorMap;

    BoundaryChunk m_bestBC;
    BoundaryChunk m_subBestBC;
    vector<BestAnnotation> m_bestAnnVec;
    vector<BestAnnotation> m_subBestAnnVec;

    BoundaryChunk m_currentBC;
    vector<BestAnnotation> m_currentAnnVec;

  // For using tree topology information
  map<int, vector<int> >* treeMap;  
  map<int, string>* nodeNameMap;

  int rootNodeIndex;
  vector<char> baseVec;
  map<int, vector<double> > branchSummary;
  map<int, vector<int> > insLengSummary;
  map<int, vector<int> > delLengSummary;
  map<int, int> parentSeqLenSummary;

  double insLenAvg;                   // indel length average for poisson distribution
  double delLenAvg;
  double insLambda;                    // exponent for power law distribution
  double delLambda;
  double insrzeta;                         // value of Riemann zeta function for power law distribution
  double delrzeta;
  double insProbSuccess;
  double delProbSuccess;
  bool diffLenDist;

  map<int, BoundaryChunk> bChunkMap;   // Store boundary chunk for each inter-anchor
  map<int, vector<BestAnnotation> >::iterator bsIter;
   map<int, vector<BestAnnotation> > bestScoreIAnchorMap;
   vector<BestAnnotation> bestScoreVec;
   TotalBranch* anchorBranchInfo;
  double m_freqA;
  double m_freqC;
  double m_freqG;
  double m_freqT;

  double m_paramU;
  vector<string> m_anchorVec;

  int m_numConv;
  double m_subBestScore;
  bool m_bSavedBothLocation;
  bool m_bChangedScore;

  int m_numIter;
  double m_scoreOfAnchors;

  bool m_bAbnormalAlignment;

  map<string, NodeMapValue>* commonAncMap;
  
    // Added for the ancestral sequence reconstruction
    vector<string> m_ancSeqVec;
    vector<string> m_leafSeqVec;
  
    map<int, string> m_tmpSeqMap;

public:
  SearchBest(); // default constructor 
  SearchBest(int numSeq, TInterAnchor* tInt, map<int,double> bLenMap, 
        map<int, vector<int> >* treeMap, int rootNodeIndex, bool nre, int nshift,
        int ldist, bool iAnchor, int numIter, Param param, map<int, string>* nameMap); 
  
  ~SearchBest(); // default destructor
  double getInitialAlign(string sFile, string aFile, string oFile1, string oFile2, string oFile3);
  double getBestAlign(string sFile, string aFile, string oFile1, string oFile2, string oFile3);
  void outputResults(string sFile, string aFile, string oFile, string outFile, string ooutFile);
  void dumpAlign();

  double getConstMut();
  double getConstIns();
  double getConstDel();
  int getLenDist();
  double getInsLenAvg();
  double getDelLenAvg();
  double getInsLambda();
  double getDelLambda();
  double getInsRZeta();
  double getDelRZeta();
  double getInsProbSuccess();
  double getDelProbSuccess();
  bool getDiffLenDist();

  void setAnchorBranchInfo(TotalBranch* tBranch);
  double getNucFreq(char ch);
  void checkAbnormalAlignment(string sFile, string aFile);
  void runSystemCmd(string cmd, bool bout);
  
  double annotateAlign(string sFile, string aFile, string oFile1, string oFile2, string oFile3);

    // Added for the reconstruction component
    int getNumOfSeq();
    map<int, vector<int> >* getTreeMap();
    int getRootNodeNum();
    vector<string> getLeafSeqVec();
    vector<string> getAncSeqVec();
    double getParamU();

private:
  void locationChangeV2(vector<string>* seqVec, int sd, int nc, int iaIndex);
  void reestimateParam(); 
  void copyInterAnchor();
  bool sanityCheck(vector<string>* seqVec);

  void checkAlignment(BoundaryChunk* bc, int numCol, int startIndex);
  vector<BestAnnotation> findBestAnnotation(BoundaryChunk* bc, int numCol, int startIndex);
  vector<BestAnnotation> findBestAnnotationV2(BoundaryChunk* bc, int numCol, int startIndex);
  vector<BestAnnotation> findBestAnnotationHybrid(BoundaryChunk* bc, int numCol, int startIndex);
  BestAnnotation aux_findBestAnnotation(BoundaryChunk* bc, map<int, vector<int> >* seqMap, int startIndex);
  PhyloTreeNodeEx* makeTree(BoundaryChunk* bc, map<int, vector<int> >* seqMap);
  void aux_makeTree(BoundaryChunk* bc, PhyloTreeNodeEx* cNode, PhyloTreeNodeEx* pNode, 
                        int nodeIndex, map<int, vector<int> >* seqMap);
  void freeMemory(PhyloTreeNodeEx* pNode);
  void enumCandidateAnnotation(PhyloTreeNodeEx* pNode, int* bIndex, BoundaryChunk* bc, int startIndex);
  double getFinalScore();    // return ths score of selected best tree
  double getFinalScoreEx(map<int, vector<BestAnnotation> >* bAnnMap);    // return ths score of selected best tree

  void summaryBranchInfo(map<int, BoundaryChunk>* bcMap, map<int, vector<BestAnnotation> >* bestAnnMap);
  void dumpBC(BoundaryChunk* pbc);
  void dumpAnnVec(BoundaryChunk* pbc, vector<BestAnnotation>* pAnnVec);
  void dumpBranchInfo(vector<BestAnnotation>* pAnnVec);
  void dumpSeqVec(vector<string>* strVec);

  void nodeBestAnnotation(PhyloTreeNodeEx* root);
  void calculateAnchorScore();

  vector<int> getIndelCnt(map<int, vector<BestAnnotation> >* pAnnVecMap);
  vector<int> getSeparateIndelCnt(map<int, vector<BestAnnotation> >* pAnnVecMap);
  void calculateIndelScore(map<int, vector<BestAnnotation> >* pAnnVecMap);

  vector<int> getOverlapBA(vector<BestAnnotation>* baVec, int sIndex, int eIndex, double* score);
  
  // Compute substition score for each block in the given tree before generating candidiate annotations
  void computeSubstScoreStep1(PhyloTreeNodeEx* pNode, int* bIndex, BoundaryChunk* bc);
  void computeSubstScoreStep2(PhyloTreeNodeEx* pNode, vector<double>* scrVec);
  
  double getIndelScore(BoundaryChunk* bc, int bIndex, int startIndex, IndelEntry* pEntry, IndelEntry* cEntry);
  BranchInfo summaryIndelAnnotation(BoundaryChunk* bc, int bIndex, int startIndex, IndelEntry* pEntry, IndelEntry* cEntry);
  BestAnnotation findBestCandidate(PhyloTreeNodeEx* pNode, BoundaryChunk* bc, int startIndex);
  void aux_findBestCandidate(BoundaryChunk* bc, PhyloTreeNodeEx* root, int bestLeftIndex, int bestRightIndex, int* bIndex, BranchInfoSet* bInfoSet, int startIndex);
    void outputParameters();
};

class OutputDS
{
	private:
		int startIndex;
		int endIndex;
        int length;
		string annotation;
		
	public:
		OutputDS();
		OutputDS(int s, int e, string anno, int length);
		~OutputDS();
		int getStartIndex();
		int getEndIndex();
        int getLength();
		string getAnnotation();
};

#endif

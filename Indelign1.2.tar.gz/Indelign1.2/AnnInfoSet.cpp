// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "AnnInfoSet.h"

AnnInfo::AnnInfo()
{
    m_startIndex = m_endIndex = m_ann = -1;
    m_length = 0;
}

AnnInfo::AnnInfo(int sIndex, int eIndex, int ann, int length)
{
    m_startIndex = sIndex;
    m_endIndex = eIndex;
    m_ann = ann;
    m_length = length;
}

AnnInfo::AnnInfo(const AnnInfo &aInfo)
{
    m_startIndex = aInfo.m_startIndex;
    m_endIndex = aInfo.m_endIndex;
    m_ann = aInfo.m_ann;
    m_length = aInfo.m_length;
}

AnnInfo::~AnnInfo()
{

}

int AnnInfo::getStartIndex()
{
    return m_startIndex;
}

int AnnInfo::getEndIndex()
{
    return m_endIndex;
}

int AnnInfo::getAnn()
{
    return m_ann;
}

int AnnInfo::getLength()
{
    return m_length;
}

void AnnInfo::setStartIndex(int sIndex)
{
    m_startIndex = sIndex;
}

void AnnInfo::setEndIndex(int eIndex)
{
    m_endIndex = eIndex;
}

void AnnInfo::setLength(int length)
{
    m_length = length;
}

void AnnInfo::addOffset(int offset)
{
    m_startIndex += offset;
    m_endIndex += offset;
}

AnnInfoSet::AnnInfoSet()
{

}

AnnInfoSet::AnnInfoSet(const AnnInfoSet &aInfo)
{
    m_annMap = aInfo.m_annMap;
}

AnnInfoSet::~AnnInfoSet()
{

}

void AnnInfoSet::addAnnInfo(int bNum, vector<AnnInfo> infoVec)
{
    m_annMap[bNum] = infoVec;
}

void AnnInfoSet::appendAnnInfo(int bNum, vector<AnnInfo>* infoVec)
{
    map<int, vector<AnnInfo> >::iterator iter;
    iter = m_annMap.find(bNum);
    if (iter == m_annMap.end())
    {
        m_annMap[bNum] = *infoVec;
    } // end of if
    else
    {
        for (int i = 0; i < infoVec->size(); i++)
            m_annMap[bNum].push_back(infoVec->at(i));
    } // end of else
}

vector<AnnInfo>* AnnInfoSet::getAnnInfoAt(int bNum)
{
    map<int, vector<AnnInfo> >::iterator iter;
    iter = m_annMap.find(bNum);
    if (iter == m_annMap.end()) return NULL;
    return &(m_annMap[bNum]);
}



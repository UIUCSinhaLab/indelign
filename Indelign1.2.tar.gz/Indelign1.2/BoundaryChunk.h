// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef BOUNDARYCHUNK_H
#define BOUNDARYCHUNK_H

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "BoundaryItem.h"

using namespace std;

class BoundaryChunk {

private:
  vector<BoundaryItem> wholeBoundaryItems;
  vector<string> seqVec;
  int nSeq;
  int numColumn;   
  
public:
  BoundaryChunk(); // default constructor 
  BoundaryChunk(int numSeq, vector<string> seqVector);
  BoundaryChunk(int numSeq, vector<string>* seqVector);
  BoundaryChunk(const BoundaryChunk& bChunk); // copy constructor
  ~BoundaryChunk(); // default destructor
  int getNumOfBoundaryItem();
  BoundaryItem* getBoundaryItem(int index);
  int getIndexOfBoundaryStartAt(int start);
  void dump();

  string getChunkSeq(int colid, int seqNum);
  string getChunkSeq(int colid);
  vector<string>* getSeqVec() { return &seqVec; }

private:
  void makeBoundaryItem();
};

#endif

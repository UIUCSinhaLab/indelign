// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef TINTERANCHOR_H
#define TINTERANCHOR_H

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include "InterAnchor.h"
#include "TotalBranch.h"
#include "Util.h"
#include "Param.h"
#include "AnnInfoSet.h"

using namespace std;

class NodeMapValue
{
private:
    int commonAncestor;
    double totalTime;

public:
    NodeMapValue();
    NodeMapValue(int num, double len);
    ~NodeMapValue();

    int getCommonAncestorNum();
    double getTotalTime();
};

class TInterAnchor {

private:
  vector<InterAnchor> wholeInAnchor;
  string fileName;
  int nSeq;
  int numColumn;    // total number of column

  int numBranch;    // total number of branch

  // store summary of branches for each inter-anchor
  vector<TotalBranch*> branchSummary; 
  
  map<int, double> branchLength;
  double sumOfLenSquare;	// store sum of square of length of each branch
  map<int, vector<double> > tbMap;	// store total branch summary
									// vector<double> first element: total number of match
                                    //                second element: total number of mismatch
									//                third element: total number of insertion
                                    //                fourth element: total number of non-insertion
									//                fifth element: total number of deletion
                                    //                sixth element: total number of non-deletion

  // member variables for score parameters
  double constMut;
  double constIns;
  double constDel;
  map<int, vector<double> > prMap;	// store probability of each branch of mutation, insertion and deletion
  map<int, vector<int> > bInsLenMap;	// store length of each insertion
  map<int, vector<int> > bDelLenMap;    // store length of each deletion
  double totalScore;

  double insLenAvg;                   // indel length average for poisson distribution
  double insLambda;                    // exponent for power law distribution
  double insrzeta;                         // value of Riemann zeta function for power law distribution
  double insProbSuccess;              // parameter of geometric distribution
  double delLenAvg;                   // indel length average for poisson distribution
  double delLambda;                    // exponent for power law distribution
  double delrzeta;                         // value of Riemann zeta function for power law distribution
  double delProbSuccess;              // parameter of geometric distribution
  bool diffLenDist;
    
  int lenDist;          // indel length distribution
  bool includeAnchor;

  TotalBranch* anchorBranchInfo;  

  map<int, int> anchorStat; // statistic information for finding anchors between two sequences
  map<int, vector<int> > trueIndelCnt;   // key: seq num(from 1), value: vecter of num of ins, del
  map<int, int> branchForLeafSeq;       // branch for leaf sequences
                                        // key: seq num(from 1)

  // new parameters for the new scoring function
  int m_numA;
  int m_numC;
  int m_numG;
  int m_numT;
  double m_freqA;
  double m_freqC;
  double m_freqG;
  double m_freqT;

  double m_paramU;

  vector<string> m_anchorVec;
  int** m_subNumArrayAnchor;

  vector<int> ingroupSeqNumVec;
  string ingroupSeqNumList;
  string ingroupSeqNameList;

  // Whether or not to use the true indel information
  bool m_useTrueIndel;
  
  map<string, NodeMapValue> commonAncMap;
  map<int, int> parentNodeMap;
  map<int, vector<int> >* treeMap;  
  map<int, string>* nodeNameMap;
  int rootNodeIndex;

  string anchorFile;

public:
  TInterAnchor(); // default constructor 
  TInterAnchor(string name, int num, int numB, map<int, double> bLenMap, int ldist, bool dlen, bool iAnchor, bool useTrueIndel, map<int, vector<int> >* tMap, int rIndex, string aFile, map<int, string>* nameMap);
  ~TInterAnchor(); // default destructor
  int getNumOfInterAnchor();
  InterAnchor* getInterAnchorAt(int index);
  void dump();

  double getScore();
  
  void dumpBranchLength();
  void sumBranchLength();

  void addBranchSummary(int iaIndex, int colIndex, int bIndex, int bType, int value, bool bLast); 

  double getConstMut();
  double getConstIns();
  double getConstDel();
  double getSumOfLenSquare();
  double returnCurrentScore(); 

  double getBranchLenAt(int bIndex);

  int getNumBranch();
  int getLenDist();
  int getNumColumn();

  double getInsLenAvg();
  double getDelLenAvg();  
  double getInsLambda();
  double getDelLambda();
  double getInsRzeta();
  double getDelRzeta();
  double getInsProbSuccess();
  double getDelProbSuccess();
  bool getDiffLenDist();
  void estimateParameters();
  vector<string> makeAnchor(string seqFile, string anchorFile);
  void setAnchorBranchInfo(TotalBranch* tBranch);

  void setBranchNumForSeq(int seqnum, int bnum);
  int getBranchNumForSeq(int seqnum);
  int getSeqNumForBranch(int bnum);
  void dumpBranchSeq();
  vector<int> getTrueIndelVec(int seqnum);
  
  double getFreqA();
  double getFreqC();
  double getFreqG();
  double getFreqT();
  double getParamU();
  vector<string> getAnchorString();
  int getAnchorSeqLen();
  
  int getBranchForLeafSeq(int seqnum);
  int** getSubNumArrayAnchor();

  void setIngroupSeqNumVec(vector<int> numVec);
  vector<int>* getIngroupSeqNumVec();
  bool isSubAnchor(int iaNum, int seqNum, int colIndex);    // seqNum start from 1
  
  void writeAnnotationResult(string anchorFile, string outFile);
  
  NodeMapValue* getNodeMapValue(string key);
  void runSystemCmd(string cmd, bool bout);
  string getIngroupSeqNumList();
  string getIngroupSeqNameList();

private:
  void makeInterAnchor();
  void findSubAnchors();
  void readAnchorStat();
  void readTrueIndexCnt();
  void aux_findSubAnchors(InterAnchor* iAnchor, int seqNum1, string seq1, int seqNum2, string seq2);

  int getCommonAncestorNum(int seqNum1, int seqNum2, double* tTime);
  void makeParentNodeMap();
};

#endif

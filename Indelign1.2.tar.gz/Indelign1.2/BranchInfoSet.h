// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef BRANCHINFOSET_H
#define BRANCHINFOSET_H

#include <iostream>
#include <map>
#include "BranchInfo.h"

using namespace std;

class BranchInfoSet
{
private:
	// Key: branch number, Value: BranchInfo
	map<int, BranchInfo> branchMap;

    // Store the length of parent sequence(ignoring gaps)
    // Key: branch number, Value: parent sequence length
    map<int, int> parentSeqLenMap;

public:
	BranchInfoSet();	// Default constructor
	~BranchInfoSet();	// Default destructor

	void addBranchInfo(int bNum, BranchInfo bInfo, int len);
        void addBranchInfo(int bNum, BranchInfo bInfo);
	BranchInfo* getBranchInfoAt(int bNum);
    int getParentSeqLenAt(int bNum);
        void addParentSeqLenMap(map<int, int>* lenMap);
        map<int, int>* getParentSeqLenMap();
};

#endif


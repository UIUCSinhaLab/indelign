// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "IndelEntry.h"

IndelEntry::IndelEntry()
{
    m_score = 0.0;
    m_leftChildEntryIndex = -1;
    m_rightChildEntryIndex = -1;
}

IndelEntry::IndelEntry(IndelEntry* ie)
{
    m_score = ie->m_score;
    m_leftChildEntryIndex = ie->m_leftChildEntryIndex;
    m_rightChildEntryIndex = ie->m_rightChildEntryIndex;
    m_vecChunkId = ie->m_vecChunkId;
}

IndelEntry::~IndelEntry()
{

}

double IndelEntry::getScore()
{
    return m_score;
}

int IndelEntry::getLeftChildEntryIndex()
{
    return m_leftChildEntryIndex;
}

int IndelEntry::getRightChildEntryIndex()
{
    return m_rightChildEntryIndex;
}

vector<int>* IndelEntry::getChunkIdVec()
{
    return &m_vecChunkId;
}

int IndelEntry::getChunkIdAt(int index)
{
    assert (index < m_vecChunkId.size());
    return m_vecChunkId.at(index);
}

void IndelEntry::setScore(double scr)
{
    m_score = scr;
}

void IndelEntry::setLeftChildEntryIndex(int index)
{
    m_leftChildEntryIndex = index;
}

void IndelEntry::setRightChildEntryIndex(int index)
{
    m_rightChildEntryIndex = index;
}

void IndelEntry::addChunkId(int ckId)
{
    m_vecChunkId.push_back(ckId);
}

void IndelEntry::dump()
{
    cerr << "\t";
    for (int i = 0; i < m_vecChunkId.size(); i++)
    {
        if (m_vecChunkId.at(i) < 0) cerr << "-";
        else cerr << "*";    
    } // end of for
    cerr << " " << m_score;
    cerr << " Lt cIndex:" << m_leftChildEntryIndex;
    cerr << " Rt cIndex:" << m_rightChildEntryIndex << endl;
}

int IndelEntry::getChunkIdVecSize()
{
    return m_vecChunkId.size();
}


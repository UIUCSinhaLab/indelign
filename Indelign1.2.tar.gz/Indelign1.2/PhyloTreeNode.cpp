// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "PhyloTreeNode.h"

// Default constructor
PhyloTreeNode::PhyloTreeNode()
{
    base = '-';
    leftChild = rightChild = parent = NULL;
    leftBranchAnn = rightBranchAnn = NOEVENT;
}

// Copy constructor
PhyloTreeNode::PhyloTreeNode(const PhyloTreeNode& node)
{
    base = node.base;
    leftBranchAnn = node.leftBranchAnn;
    rightBranchAnn = node.rightBranchAnn;

    parent = NULL;
    if (node.parent != NULL)
        parent = new PhyloTreeNode(*node.parent);
    
    leftChild = NULL;
    if (node.leftChild != NULL)
        leftChild = new PhyloTreeNode(*node.leftChild);

    rightChild = NULL;
    if (node.rightChild != NULL)
        rightChild = new PhyloTreeNode(*node.rightChild);
}

// Destructor
PhyloTreeNode::~PhyloTreeNode()
{
    ; // do nothing
}

void PhyloTreeNode::setLeftChild(PhyloTreeNode* pNode)
{
    leftChild = pNode;
}

void PhyloTreeNode::setRightChild(PhyloTreeNode* pNode)
{
    rightChild = pNode;
}

void PhyloTreeNode::setParent(PhyloTreeNode* pNode)
{
    parent = pNode;
}

PhyloTreeNode* PhyloTreeNode::getLeftChild()
{
    return leftChild;
}

PhyloTreeNode* PhyloTreeNode::getRightChild()
{
    return rightChild;
}

PhyloTreeNode* PhyloTreeNode::getParent()
{
    return parent;
}

void PhyloTreeNode::setBase(char ch)
{
    base = ch;
}

char PhyloTreeNode::getBase()
{
    return base;
}

int PhyloTreeNode::getLeftBranchAnnotation()
{
    return leftBranchAnn;
}

int PhyloTreeNode::getRightBranchAnnotation()
{
    return rightBranchAnn;
}

// Parameter anno is one of PhyloTreeNode::MATCH
//                          PhyloTreeNode::MISMATCH 
//                          PhyloTreeNode::INSERTION
//                          PhyloTreeNode::DELETION 
void PhyloTreeNode::setLeftBranchAnnotation(int anno)
{
    leftBranchAnn = anno;
}

// Parameter anno is one of PhyloTreeNode::MATCH
//                          PhyloTreeNode::MISMATCH 
//                          PhyloTreeNode::INSERTION
//                          PhyloTreeNode::DELETION 
void PhyloTreeNode::setRightBranchAnnotation(int anno)
{
    rightBranchAnn = anno;
}

double PhyloTreeNode::getScore(char chBase)
{
    double score = 0.0;
    if (leftChild == NULL && rightChild == NULL)
    {
        if (chBase == base) score = 0.0;
        else score = (double)NodeScoreMatrixPrev::MAX_EVENT;
    } // end of if
    else
        score = scoreMat.getScore(chBase);

    return score;
}

void PhyloTreeNode::setScore(char base, double score)
{
    scoreMat.setScore(base, score);
}

char PhyloTreeNode::getSelectedLeftBase(char left)
{
    return scoreMat.getSelectedLeftBase(left);
}

void PhyloTreeNode::setSelectedLeftBase(char parent, char left)
{
    scoreMat.setSelectedLeftBase(parent, left);
}

char PhyloTreeNode::getSelectedRightBase(char right)
{
    return scoreMat.getSelectedRightBase(right);
}

void PhyloTreeNode::setSelectedRightBase(char parent, char right)
{
    scoreMat.setSelectedRightBase(parent, right);
}

void PhyloTreeNode::setFinishScoring()
{
    scoreMat.setFinishScoring();
}

bool PhyloTreeNode::getFinishScoring()
{
    return scoreMat.getFinishScoring();
}

void PhyloTreeNode::dump()
{
    cerr << "    Base:" << base << endl;
    
    if (leftChild != NULL)
    {
        cerr << "base of left:" << leftChild->getBase() << endl;
	cerr << "branch of left:" << leftBranchAnn << endl;
    } // end of if

    if (rightChild != NULL)
    {
        cerr << "base of right:" << rightChild->getBase() << endl;
	cerr << "branch of right:" << rightBranchAnn << endl;
    } // end of if

    cerr << "    Left child: " << endl;
    if (leftChild != NULL) leftChild->dump();
    cerr << "    Right child: " << endl;
    if (rightChild != NULL) rightChild->dump();
}

// For reconstruction
double PhyloTreeNode::getScoreRecon(char chBase)
{
    double score = 0.0;
    if ((leftChild == NULL && rightChild == NULL) || base == '-')
    {
        if (chBase == base) score = 0.0;
        else score = NodeScoreMatrixPrev::MIN_SCORE;
    } // end of if
    else
        score = scoreMat.getScore(chBase);

    return score;
}

double PhyloTreeNode::getScoreReconMLDP(char base)
{
    return scoreMat.getScore(base);
}


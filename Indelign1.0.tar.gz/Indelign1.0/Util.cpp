// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "Util.h"
#include <stdlib.h>
#include <fstream>

NWTreeNode::NWTreeNode()
{
    m_leftChild = NULL;
    m_rightChild = NULL;
    m_parent = NULL;
    m_nodeNum = 0;
    m_bLength = 0.0;
}

NWTreeNode::~NWTreeNode()
{

}

void NWTreeNode::setLeftChild(NWTreeNode* node)
{
    m_leftChild = node;
}

void NWTreeNode::setRightChild(NWTreeNode* node)
{
    m_rightChild = node;
}

void NWTreeNode::setParent(NWTreeNode* node)
{
    m_parent = node;
}

NWTreeNode* NWTreeNode::getLeftChild()
{
    return m_leftChild;
}

NWTreeNode* NWTreeNode::getRightChild()
{
    return m_rightChild;
}

NWTreeNode* NWTreeNode::getParent()
{
    return m_parent;
}

int NWTreeNode::getNodeNum()
{
    return m_nodeNum;
}

string NWTreeNode::getNodeName()
{
    return m_nodeName;
}

double NWTreeNode::getBLength()
{
    return m_bLength;
}

void NWTreeNode::setBLength(double len)
{
    m_bLength = len;
}

void NWTreeNode::setNodeNum(int num)
{
    m_nodeNum = num;
}

void NWTreeNode::setNodeName(string name)
{
    m_nodeName = name;
}

void NWTreeNode::dump()
{
    cerr << "Node Number:" << m_nodeNum << endl;
    cerr << "Node Name:" << m_nodeName << endl;
    cerr << "Branch length:" << m_bLength << endl;
    if (m_leftChild != NULL) m_leftChild->dump();
    if (m_rightChild != NULL) m_rightChild->dump();
}

queue<int> Util::seqQ;
map<int, queue<int> > Util::gapQMap;

// strTree: string to be parsed
// treeMap: store parse result
// n: the number of current internal node
Param Util::parseTreeEx(string parFile, string* strTree, map<int, vector<int> >* treeMap, map<int, double>* bLenMap, int* n, map<int, string>* nodeNameMap)
{
    // read parameter input file
    ifstream infile(parFile.c_str());
    if (!infile)
    {
        cerr << "Error opening parameter file: " << parFile << endl;
        exit(1);
    } // end of if

    int numSeq = 0;
    bool notRe = false;
    int numShift = 0;
    int lenDist = 0;
    string out1 = "";
    string out2 = "";
    string out3 = "";
    bool includeAnchor = true;
    int numIter = 0;

    double constIns = 0.0;
    double constDel = 0.0;
    double constMut = 0.0;
    double F81param = 0.0;
    double insLenAvg = 0.0;
    double delLenAvg = 0.0;
    double insLambda = 0.0;
    double delLambda = 0.0;
    double insrzeta = 0.0;
    double delrzeta = 0.0;
    double insProbSuccess = 0.0;
    double delProbSuccess = 0.0;

    bool useTrueIndel = false;
    bool diffLenDist = false;

    string line;
    while (!infile.eof())
    {
        getline(infile, line);
        if (line.length() == 0 || line.at(0) == '#') continue;

        int eqindex = (int)line.find("=");
        string strName = Util::trim(line.substr(0, eqindex));
        if (strName.length() == 0) continue;

        if (strName.compare("NumSeq") == 0)
        {
            string strNum = Util::trim(line.substr(eqindex + 1));
            numSeq = atoi(strNum.c_str());
            if (numSeq == 0)
            {
                cerr << "Invalid parameter:Number of sequence" << endl;
                exit(1);
            } // end of if 

            *n = numSeq + 1;
        } // end of if
        else if (strName.compare("Tree") == 0)
        {
            string treePar = Util::trim(line.substr(eqindex + 1));
           int offset = 0; 
            int leafNum = 1;
            NWTreeNode* rootNode = new NWTreeNode();
            *strTree = aux_parseTreeEx(rootNode, treePar, &offset, treeMap, n, &leafNum);

            // extract tree information
            int bNum = 1;
            extractTreeInfo(rootNode, &bNum, treeMap, bLenMap, nodeNameMap); 
            freeMemory(rootNode);
        } // end of else if
        else if (strName.compare("NotRE") == 0)
        {
            string notReStr = Util::trim(line.substr(eqindex + 1));
            if (notReStr.compare("true") == 0) notRe = true;
            else if (notReStr.compare("false") == 0) notRe = false;
            else
            {
                cerr << "Invalid parameter:Not RE" << endl;
                exit(1);
            } // end of if
        } // end of else if
        else if (strName.compare("NumShift") == 0)
        {
            string str = Util::trim(line.substr(eqindex + 1));
            numShift = atoi(str.c_str());
            if (numShift <= 0)
            {
                cerr << "Invalid parameter:Number of shift" << endl;
                exit(1);
            } // end of if 
        } // end of else if
        else if (strName.compare("Out1") == 0)
        {
            out1 = Util::trim(line.substr(eqindex + 1));
        } // end of else if
        else if (strName.compare("Out2") == 0)
        {
            out2 = Util::trim(line.substr(eqindex + 1));
        } // end of else if
        else if (strName.compare("Out3") == 0)
        {
            out3 = Util::trim(line.substr(eqindex + 1));
        } // end of else if
        else if (strName.compare("LenDist") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.compare("PS") == 0) lenDist = Param::LDIST_PS;
            else if (strDist.compare("PL") == 0) lenDist = Param::LDIST_PL;
            else if (strDist.compare("GM") == 0) lenDist = Param::LDIST_GM;
            else
            {
                cerr << "Invalid parameter:Indel length distribution" << endl;
                exit(1);
            }
        } // end of else if
        else if (strName.compare("DiffLenDist") == 0)
        {
            string strDLD = Util::trim(line.substr(eqindex + 1));
            if (strDLD.compare("true") == 0) diffLenDist = true;
            else diffLenDist = false;
        } // end of else if
        else if (strName.compare("IncludeAnchor") == 0)
        {
            string strIA = Util::trim(line.substr(eqindex + 1));
            if (strIA.compare("true") == 0) includeAnchor = true;
            else includeAnchor = false;
        } // end of else if
        else if (strName.compare("NumIter") == 0)
        {
            string str = Util::trim(line.substr(eqindex + 1));
            numIter = atoi(str.c_str());
            if (numIter <= 0)
            {
                cerr << "Invalid parameter:Number of iteration" << endl;
                exit(1);
            } // end of if 
        } // end of else if
        else if (strName.compare("ConstIns") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) constIns = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("ConstDel") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) constDel = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("F81param") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) F81param = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("InsLenAvg") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) insLenAvg = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("DelLenAvg") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) delLenAvg = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("InsLambda") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) insLambda = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("DelLambda") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) delLambda = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("Insrzeta") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) insrzeta = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("Delrzeta") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) delrzeta = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("InsProbSuccess") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) insProbSuccess = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("DelProbSuccess") == 0)
        {
            string strDist = Util::trim(line.substr(eqindex + 1));
            if (strDist.length() > 0) delProbSuccess = (double)atof(strDist.c_str());
        } // end of else if
        else if (strName.compare("UseTrueIndel") == 0)
        {
            string useTrueIndelStr = Util::trim(line.substr(eqindex + 1));
            if (useTrueIndelStr.compare("true") == 0) useTrueIndel = true;
            else if (useTrueIndelStr.compare("false") == 0) useTrueIndel = false;
            else
            {
                cerr << "Invalid parameter:UseTrueIndel" << endl;
                exit(1);
            } // end of if
        } // end of else if
        else
        {

        }
    } // end of while
    infile.close();

    if (numShift == 0) numShift = 2000;
    if (includeAnchor == false) includeAnchor = true;

    Param param(numSeq, notRe, numShift, lenDist, out1, out2, out3, includeAnchor, numIter);
    param.setConstIns(constIns);
    param.setConstDel(constDel);
    param.setConstMut(constMut);
    param.setF81param(F81param);
    param.setInsLenAvg(insLenAvg);
    param.setDelLenAvg(delLenAvg);
    param.setInsLambda(insLambda);
    param.setDelLambda(delLambda);
    param.setInsRzeta(insrzeta);
    param.setDelRzeta(delrzeta);
    param.setInsProbSuccess(insProbSuccess);
    param.setDelProbSuccess(delProbSuccess);
    param.setUseTrueIndel(useTrueIndel);
    param.setDiffLenDist(diffLenDist);
    return param;
}

// strTree: string to be parsed
// treeMap: store parse result
// n: the number of current internal node
string Util::aux_parseTree(string strTree, map<int, vector<int> >* treeMap, int* n)
{
    int firstloc = (int)strTree.find("(");
    int lastloc = (int)strTree.find_last_of(")");

    string strRes;
    /////////////////////////////////////////////////////////////////
    // For left subtree
    if (strTree.at(0) == '(')   // case: starts with (...)
    {
        firstloc = 0; //strTree.find("(");
        int parCnt = 1;
        int i = firstloc + 1;

        while (i != string::npos)
        {
            if (strTree.at(i) == '(') parCnt++;    
            else if (strTree.at(i) == ')')
            {
                parCnt--;
                if (parCnt == 0) break;
            }
            else ; // do nothing
            i++;
        } // end of while
        lastloc = i;
        string strTmp = strTree.substr(firstloc + 1, lastloc - firstloc - 1);
        
        // call function
        strRes = aux_parseTree(strTmp, treeMap, n);

        // erase original string and insert result string
        strTree = strTree.erase(firstloc, lastloc - firstloc + 1);
        strTree.insert(firstloc, strRes);
        if (strTree.at(firstloc + strRes.size()) != ' ')
            strTree.insert(firstloc + strRes.size(), " ");
    } // end of if
    /////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////
    // For right subtree
    int newStart = firstloc;
    if (strRes.size() > 0) newStart = (int)strRes.size() + 1;

    if (firstloc != string::npos)
    {
        while (strTree.at(newStart) == ' ') newStart++;
    } // end of if

    if (firstloc != string::npos && strTree.at(newStart) == '(')    // case: starts with (...)
    {
        firstloc = newStart; //strTree.find("(", newStart);
        int parCnt = 1;
        int i = firstloc + 1;

        while (i != string::npos)
        {
            if (strTree.at(i) == '(') parCnt++;    
            else if (strTree.at(i) == ')')
            {
                parCnt--;
                if (parCnt == 0) break;
            }
            else ; // do nothing
            i++;
        } // end of while
        lastloc = i;
        string strTmp = strTree.substr(firstloc + 1, lastloc - firstloc - 1);
        
        // call function
        string strRes = aux_parseTree(strTmp, treeMap, n);
        
        // erase original string and insert result string
        strTree = strTree.erase(firstloc, lastloc - firstloc + 1);
        strTree.insert(firstloc, strRes);
    } // end of if
    /////////////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////////////////
    // terminate case
    // parse two node number
    firstloc = (int)strTree.find("(");
    if (firstloc == string::npos)   // only consists of two node number
    {
        int i = 0;
        while (strTree.at(i) == ' ') i++;   // skip whitespace
        int j = i;
        while (strTree.at(j) != ' ') j++;   // find next whitespace
        string firstStr = strTree.substr(i, j - i);
        int firstNodeNum = atoi(firstStr.c_str());

        i = j;
        while (strTree.at(i) == ' ') i++;
        j = i;
        while (strTree.at(j) != ' ')
        {
            j++;
            if (j == strTree.size()) break;    
        } // end of while
        string secondStr = strTree.substr(i, j - i);
        int secondNodeNum = atoi(secondStr.c_str());

        // push two node numbers to map with number of parent node
        vector<int> numVec;
        numVec.push_back(firstNodeNum);
        numVec.push_back(secondNodeNum);
        int nodeNum = *n;
        treeMap->operator[](nodeNum) = numVec;
        (*n)++;

        char buff[1024];
        sprintf(buff, "%d", nodeNum);
        string newStr(buff);

        return newStr;
    } // end of if

    return "";
}

// strTree: string to be parsed
// treeMap: store parse result
// n: the number of current internal node
string Util::aux_parseTreeEx(NWTreeNode* pNode, string strTree, int* offset, map<int, vector<int> >* treeMap, int* n, int* leafNum)
{
    while ((*offset) < strTree.length())
    {
        while (strTree.at(*offset) == ' ' || strTree.at(*offset) == '\t' || strTree.at(*offset) == '\n' || strTree.at(*offset) == '\r') (*offset)++;
        char ch = strTree.at(*offset);
        if (ch == '(')
        {
            NWTreeNode* cNode = new NWTreeNode();
            cNode->setParent(pNode);
            pNode->setLeftChild(cNode);
            (*offset)++;
            aux_parseTreeEx(cNode, strTree, offset, treeMap, n, leafNum);
        } // end of if
        else if (ch == ')')
        {
            (*offset)++;
            while (strTree.at(*offset) == ' ' || strTree.at(*offset) == '\t' || strTree.at(*offset) == '\n' || strTree.at(*offset) == '\r') (*offset)++;
            char tmpch = strTree.at(*offset);
            double blen = 0.0;
            if (tmpch == ':')
            {
                (*offset)++;
                while (strTree.at(*offset) == ' ' || strTree.at(*offset) == '\t' || strTree.at(*offset) == '\n' || strTree.at(*offset) == '\r') (*offset)++;
                int start = *offset;
                while (isalnum(strTree.at(*offset)) || strTree.at(*offset) == '.') (*offset)++;
                double blen = atof(strTree.substr(start, *offset - start).c_str());
                pNode->setBLength(blen);
                pNode->setNodeNum(*n);

                NWTreeNode* leftNode = pNode->getLeftChild();
                NWTreeNode* rightNode = pNode->getRightChild();
                string nodeName = leftNode->getNodeName();
                if (leftNode->getLeftChild() == NULL && leftNode->getRightChild() == NULL) nodeName += "+";
                nodeName += rightNode->getNodeName();
                if (rightNode->getLeftChild() == NULL && rightNode->getRightChild() == NULL) nodeName += "+";
                pNode->setNodeName(nodeName);
                (*n)++;
            } // end of if
            else if (tmpch == ';')
            {
                pNode->setNodeNum(*n);

                NWTreeNode* leftNode = pNode->getLeftChild();
                NWTreeNode* rightNode = pNode->getRightChild();
                string nodeName = leftNode->getNodeName();
                if (leftNode->getLeftChild() == NULL && leftNode->getRightChild() == NULL) nodeName += "+";
                nodeName += rightNode->getNodeName();
                if (rightNode->getLeftChild() == NULL && rightNode->getRightChild() == NULL) nodeName += "+";
                pNode->setNodeName(nodeName);

                (*n)++;
                (*offset)++;
            } // end of else if
            else
            {
                while (strTree.at(*offset) == ' ' || strTree.at(*offset) == '\t' || strTree.at(*offset) == '\n' || strTree.at(*offset) == '\r') (*offset)++;
                int start = *offset;
                while (isalnum(strTree.at(*offset)) || strTree.at(*offset) == ':' || strTree.at(*offset) == '.') (*offset)++;
                string tmpstr = strTree.substr(start, *offset - start);
                int colonIndex = tmpstr.find(":");
                string nodeName = tmpstr.substr(0, colonIndex);
                double blen = atof(tmpstr.substr(colonIndex + 1).c_str());
                pNode->setBLength(blen);
                pNode->setNodeNum(*leafNum);
                (*leafNum)++;

                pNode->setNodeName(nodeName);
            } // end of else
            break;
        } // end of else if
        else if (ch == ',')
        {
            NWTreeNode* cNode = new NWTreeNode();
            cNode->setParent(pNode);
            pNode->setRightChild(cNode);
            (*offset)++;
            aux_parseTreeEx(cNode, strTree, offset, treeMap, n, leafNum);
        } // end of else if
        else if (isalnum(ch))
        {
            int start = *offset;
            while (isalnum(strTree.at(*offset)) || strTree.at(*offset) == ':' || strTree.at(*offset) == '.') (*offset)++;
            string tmpstr = strTree.substr(start, *offset - start);
            int colonIndex = tmpstr.find(":");
            string nodeName = tmpstr.substr(0, colonIndex);
            double blen = atof(tmpstr.substr(colonIndex + 1).c_str());
            pNode->setBLength(blen);
            pNode->setNodeNum(*leafNum);
            (*leafNum)++;

            pNode->setNodeName(nodeName);
            break;
        } // end of else if
        else
        {
            cerr << "Tree format error #2 !!(offset:" << *offset << ", " << strTree.at(*offset) << ")" << endl;
            exit(1);
        } // end of else
    } // end of while

    return "";
}

int Util::getSubstScore(char b1, char b2)
{
    int score = 0;

    if (b1 == 'A' && b2 == 'A') score = 91;
    else if (b1 == 'A' && b2 == 'C') score = -114;
    else if (b1 == 'A' && b2 == 'G') score = -31;
    else if (b1 == 'A' && b2 == 'T') score = -123;
    else if (b1 == 'C' && b2 == 'A') score = -114;
    else if (b1 == 'C' && b2 == 'C') score = 100;
    else if (b1 == 'C' && b2 == 'G') score = -125;
    else if (b1 == 'C' && b2 == 'T') score = -31;
    else if (b1 == 'G' && b2 == 'A') score = -31;
    else if (b1 == 'G' && b2 == 'C') score = -125;
    else if (b1 == 'G' && b2 == 'G') score = 100;
    else if (b1 == 'G' && b2 == 'T') score = -114;
    else if (b1 == 'T' && b2 == 'A') score = -123;
    else if (b1 == 'T' && b2 == 'C') score = -31;
    else if (b1 == 'T' && b2 == 'G') score = -114;
    else if (b1 == 'T' && b2 == 'T') score = 91;
    else if (b1 == '-' || b2 == '-') score = -43;
    else score = 0;

    return score;
}

double Util::poissonDist(int value, double mean)
{
    if (mean == 0.0) return 1.0;

    double pr = 1.0;
    pr *= exp(-mean);
   
    for (int i = value; i >= 1; i--)
    {
        double dt = mean / i;
        pr *= dt;
    } // end of for

    return pr; 
}

double Util::geometricDist(int value, double p)
{
    double pr = p;
    for (int i = 1; i <= value - 1; i++)
    {
        pr *= (1 - p);
    } // end of for

    return pr; 
}

string Util::trim(string str)
{
    int windex = 0;
    // Remove whitespaces at the front of the string
    while (windex < str.length())
    {
        if (str.at(windex) != ' ' && str.at(windex) != '\t' && str.at(windex) != '\n') break;
        windex++;
    } // end of while
    str = str.substr(windex);

    // Remove wihtespaces at the end of the string
    windex = str.length();
    windex--;
    while (windex >= 0)
    {
        if (str.at(windex) != ' ' && str.at(windex) != '\t' && str.at(windex) != '\n') break;
        windex--;
    } // end of while
    str = str.substr(0, windex + 1);

    return str;
}

void Util::seqQueueInit(int nSeq)
{
    // init sequence queue and gap queue map
    while(!Util::seqQ.empty()) Util::seqQ.pop();
    Util::gapQMap.clear();
    map<int, queue<int> >().swap(Util::gapQMap);

    for (int i = 0; i < nSeq; i++)
    {
        Util::seqQ.push(i);
        queue<int> gapQ;
        Util::gapQMap[i] = gapQ;
    } // end of for
}

int Util::getRoundRobinSeqNum()
{
    int num = Util::seqQ.front();
    Util::seqQ.pop();
    Util::seqQ.push(num);
    return num;
}

int Util::getRoundRobinGapNum(int sindex, int nGap)
{
    int num = 0;
    queue<int> gapQ = Util::gapQMap[sindex];
    if (gapQ.empty())
    {
        for (int i = 0; i < nGap; i++)
            gapQ.push(i);
    } // end of if
    else
    {
        if (gapQ.size() < nGap)
        {
            for (int i = gapQ.size(); i < nGap; i++)
                gapQ.push(i);
        } // end of if
    } // end of else

    do {
        num = gapQ.front();
        gapQ.pop();
        gapQ.push(num);
    } while (num >= nGap);

    Util::gapQMap[sindex] = gapQ;
    
    return num;
}

double Util::getLenProb(int type, int value, double lamda, double rzeta, double p)
{
    double result = 0.0;
    if (type == Param::LDIST_PS)
        result = poissonDist(value, lamda);
    else if (type == Param::LDIST_PL)
        result = powerlawDist(value, lamda, rzeta);
    else if (type == Param::LDIST_GM)
        result = geometricDist(value, p);

    return result;
}

double Util::powerlawDist(int value, double lamda, double rzeta)
{
    if (rzeta == 0.0) return 0.0;

    double pl = 0.0;
    pl = pow(value, -lamda);
    pl /= rzeta;
    return pl;
}

double Util::substProb(char fromCh, char toCh, double t, double u, double pi)
{
    double prob = 0.0;

    if (fromCh == toCh)
    {
        prob = exp(-u*t) + (1 - exp(-u*t)) * pi;
    } // end of if
    else
    {
        prob = (1 - exp(-u*t)) * pi;
    } // end of else

    return prob;
}

double Util::getIndelAgreement(int numInsTrue, int numIns, int numDelTrue, int numDel)
{
    double value = pow((double)(numInsTrue - numIns), 2) + pow((double)(numDelTrue - numDel), 2);
    value /= (pow((double)numInsTrue, 2) + pow ((double)numDelTrue, 2));
    value = sqrt(value);
    return value;
}

double Util::getIndelRatio(int numInsTrue, int numIns, int numDelTrue, int numDel)
{
    double value1 = numInsTrue * numDel;
    double value2 = numDelTrue * numIns;
    double value = value1 / value2;
    return value;
}

void Util::freeMemory(NWTreeNode* pNode)
{
    if (pNode == NULL) return;

    NWTreeNode* leftChild = pNode->getLeftChild();
    NWTreeNode* rightChild = pNode->getRightChild();

    if (leftChild != NULL) freeMemory(leftChild);
    if (rightChild != NULL) freeMemory(rightChild);

    pNode->setLeftChild(NULL);
    pNode->setRightChild(NULL);
    
    delete pNode;
    pNode = NULL;
}

void Util::extractTreeInfo(NWTreeNode* pNode, int* bNum, map<int, vector<int> >* treeMap, map<int, double>* bLenMap, map<int, string>* nodeNameMap)
{
    nodeNameMap->operator[](pNode->getNodeNum()) = pNode->getNodeName();

    NWTreeNode* leftChild = pNode->getLeftChild();
    NWTreeNode* rightChild = pNode->getRightChild();

    vector<int> nodeNumVec;
    nodeNumVec.push_back(leftChild->getNodeNum());
    nodeNumVec.push_back(rightChild->getNodeNum());
    treeMap->operator [](pNode->getNodeNum()) = nodeNumVec;

    int leftBNum = *bNum;
    bLenMap->operator [](leftBNum) = leftChild->getBLength();
    // recursive call
    if (leftChild->getLeftChild() != NULL)
    {
        (*bNum) += 1;
        extractTreeInfo(leftChild, bNum, treeMap, bLenMap, nodeNameMap);
    } // end of if
    else
    {
        nodeNameMap->operator[](leftChild->getNodeNum()) = leftChild->getNodeName();
    } // end of else

    (*bNum) += 1;
    int rightBNum = *bNum;
    bLenMap->operator [](rightBNum) = rightChild->getBLength();
    if (rightChild->getRightChild() != NULL)
    {
        (*bNum) += 1;
        extractTreeInfo(rightChild, bNum, treeMap, bLenMap, nodeNameMap);
    } // end of if
    else
    {
        nodeNameMap->operator[](rightChild->getNodeNum()) = rightChild->getNodeName();
    } // end of else
}

string Util::toUpper(string str)
{
    for (int i = 0; i < str.length(); i++)
        str.at(i) = toupper(str.at(i));
    return str;
}


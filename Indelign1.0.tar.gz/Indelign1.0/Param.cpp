// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "Param.h"

Param::Param()
{

}

Param::Param(int nseq, bool nre, int nshift, int ldist, string out1, string out2, string out3, bool iAnchor, int nIter)
{
    numSeq = nseq;
    notRe = nre;
    numShift = nshift;
    lenDist = ldist;
    outFile1 = out1;
    outFile2 = out2;
    outFile3 = out3;
    includeAnchor = iAnchor;
    numIter = nIter;

    constIns = 0.0;
    constDel = 0.0;
    constMut = 0.0;
    F81param = 0.0;
    insLenAvg = 0.0;
    delLenAvg = 0.0;
    insLambda = 0.0;
    delLambda = 0.0;
    insrzeta = 0.0;
    delrzeta = 0.0;
    insProbSuccess = delProbSuccess = 0.0;
    useTrueIndel = false;
    diffLenDist = false;
}

Param::~Param()
{

}

int Param::getNumSeq()
{
    return numSeq;
}

int Param::getNumShift()
{
    return numShift;
}

bool Param::getNotRe()
{
    return notRe;
}

string Param::getOutFile1()
{
    return outFile1;
}

string Param::getOutFile2()
{
    return outFile2;
}

string Param::getOutFile3()
{
    return outFile3;
}

int Param::getLenDist()
{
    return lenDist;
}

bool Param::getIncludeAnchor()
{
    return includeAnchor;
}

int Param::getNumIter()
{
    return numIter;
}

double Param::getConstIns()
{
    return constIns;
}

double Param::getConstDel()
{
    return constDel;
}

double Param::getConstMut()
{
    return constMut;
}

double Param::getF81param()
{
    return F81param;
}

double Param::getInsLenAvg()
{
    return insLenAvg;
}

double Param::getDelLenAvg()
{
    return delLenAvg;
}

double Param::getInsLambda()
{
    return insLambda;
}

double Param::getDelLambda()
{
    return delLambda;
}

double Param::getInsRzeta()
{
    return insrzeta;
}

double Param::getDelRzeta()
{
    return delrzeta;
}

double Param::getInsProbSuccess()
{
    return insProbSuccess;
}

double Param::getDelProbSuccess()
{
    return delProbSuccess;
}

void Param::setConstIns(double cins)
{
    constIns = cins;
}

void Param::setConstDel(double cdel)
{
    constDel = cdel;
}

void Param::setConstMut(double cmut)
{
    constMut = cmut;
}

void Param::setF81param(double f81param)
{
    F81param = f81param;
}

void Param::setInsLenAvg(double lenavg)
{
    insLenAvg = lenavg;
}

void Param::setDelLenAvg(double lenavg)
{
    delLenAvg = lenavg;
}

void Param::setInsLambda(double ilambda)
{
    insLambda = ilambda;
}

void Param::setDelLambda(double ilambda)
{
    delLambda = ilambda;
}

void Param::setInsRzeta(double zetavalue)
{
    insrzeta = zetavalue;
}

void Param::setDelRzeta(double zetavalue)
{
    delrzeta = zetavalue;
}

void Param::setInsProbSuccess(double prob)
{
    insProbSuccess = prob;
}

void Param::setDelProbSuccess(double prob)
{
    delProbSuccess = prob;
}

bool Param::getUseTrueIndel()
{
    return useTrueIndel;
}

bool Param::getDiffLenDist()
{
    return diffLenDist;
}

void Param::setUseTrueIndel(bool tIndel)
{
    useTrueIndel = tIndel;
}

void Param::setDiffLenDist(bool dlen)
{
    diffLenDist = dlen;
}

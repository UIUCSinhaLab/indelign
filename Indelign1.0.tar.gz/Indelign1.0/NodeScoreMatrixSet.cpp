// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "NodeScoreMatrixSet.h"

NodeScoreMatrixSet::NodeScoreMatrixSet()
{
    
}

NodeScoreMatrixSet::NodeScoreMatrixSet(const NodeScoreMatrixSet& nsSet)
{
    for (int i = 0; i < nsSet.m_nsMatVec.size(); i++)
    {
        NodeScoreMatrix* refMat = nsSet.m_nsMatVec.at(i);
        NodeScoreMatrix* nsMat = new NodeScoreMatrix(*refMat);
        m_nsMatVec.push_back(nsMat);
    } // end of for
}

NodeScoreMatrixSet::~NodeScoreMatrixSet()
{
    for (int i = 0; i < m_nsMatVec.size(); i++)
    {
        NodeScoreMatrix* ns = m_nsMatVec.at(i);
        delete ns;
    } // end of for
    m_nsMatVec.clear();
    vector<NodeScoreMatrix*>().swap(m_nsMatVec);
}

void NodeScoreMatrixSet::addNodeScoreMatrix(NodeScoreMatrix* nsMat)
{
	m_nsMatVec.push_back(nsMat);
}

NodeScoreMatrix* NodeScoreMatrixSet::getNodeScoreMatrixAt(int index)
{
    assert(m_nsMatVec.size() > index);
    return m_nsMatVec.at(index);
}

int NodeScoreMatrixSet::getSize()
{
    return m_nsMatVec.size();
}


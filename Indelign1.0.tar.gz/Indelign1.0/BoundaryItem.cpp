// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "BoundaryItem.h"

using namespace std;

BoundaryItem::BoundaryItem()
{
	startIndex = -1;
	endIndex = -1;
        seqId = -1;
        isGap = false;
	continuedGap = false;
}

BoundaryItem::BoundaryItem(const BoundaryItem& bItem)
{
    startIndex = bItem.startIndex;
    endIndex = bItem.endIndex;
    seqId = bItem.seqId;
    isGap = bItem.isGap;
    continuedGap = bItem.continuedGap;
}

BoundaryItem::BoundaryItem(int start, int end, int seq, bool ig, bool continued) 
{ 
	startIndex = start;
	endIndex = end;
        seqId = seq;
        isGap = ig;
	continuedGap = continued;
}

BoundaryItem::~BoundaryItem()
{

}
	
int BoundaryItem::getStart()
{
	return startIndex;
}

int BoundaryItem::getEnd()
{
	return endIndex;
}

int BoundaryItem::getSeqId()   
{
	return seqId;
}

bool BoundaryItem::getIsGap()
{
	return isGap;
}

bool BoundaryItem::isContinued()
{
	return continuedGap;
}

void BoundaryItem::dump()
{
	cerr << "Sequence ID:" << seqId << ", Start Index:" << startIndex << ", End Index:" << endIndex << ", Is Gap?" << isGap << ", Is Continued?" << continuedGap << endl;  	
}

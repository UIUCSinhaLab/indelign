// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef TOTALBRANCH_H
#define TOTALBRANCH_H

#include <iostream>
#include <map>
#include "BranchInfo.h"

using namespace std;

class TotalBranch
{
private:
	map<int, BranchInfo*> branchMap;
    map<int, int> insMap;
    map<int, int> delMap;
	map<int, int> insSIndexMap;
	map<int, int> delSIndexMap;

public:
	TotalBranch();	// Default constructor
	TotalBranch(int numB);	// Constructor
    TotalBranch(TotalBranch* pTB);
	~TotalBranch();	// Default destructor

	void addBranchInfo(int bNum, int infoType, int value, bool bLast);
	void addBranchInfo(int colIndex, int bNum, int infoType, int value, bool bLast);
	BranchInfo* getBranchInfoAt(int bNum);
};

#endif

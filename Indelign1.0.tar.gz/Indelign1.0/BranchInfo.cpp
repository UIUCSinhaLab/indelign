// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "BranchInfo.h"

BranchInfo::BranchInfo()
{
    numOfMisMatch = 0;
    numOfMatch = 0;
}

BranchInfo::~BranchInfo()
{

}

int BranchInfo::getNumOfMisMatch()
{
    return numOfMisMatch;
}

int BranchInfo::getNumOfMatch()
{
    return numOfMatch;
}

int BranchInfo::getNumOfInsertion()
{
    return (int)insVec.size();
}

int BranchInfo::getNumOfDeletion()
{
    return (int)delVec.size();
}

int BranchInfo::getNumOfNonInsertion()
{
    int num = 0;
    num = numOfMatch + numOfMisMatch + getNumOfDeletion() + 1 - getNumOfInsertion();
    return num;
}

int BranchInfo::getNumOfNonDeletion()
{
    int num = 0;
    num = numOfMatch + numOfMisMatch;
    return num;
}

void BranchInfo::addMisMatch(int nMat)
{
    numOfMisMatch += nMat;
}

void BranchInfo::addMatch(int nMat)
{
    numOfMatch += nMat;
}

// Parameter: len - the length of insertion to be pushed 
void BranchInfo::addInsertion(int len)
{
    insVec.push_back(len);
}

// Parameter: len - the length of deletion to be pushed 
void BranchInfo::addDeletion(int len)
{
    delVec.push_back(len);
}

// Parameter: len - the length of insertion to be pushed 
void BranchInfo::addInsertion(int sIndex, int len)
{
    insVec.push_back(len);
    AnnInfo aInfo(sIndex + 1, sIndex + len, PhyloTreeNode::INSERTION, len);
    annInfoVec.push_back(aInfo);
}

// Parameter: len - the length of deletion to be pushed 
void BranchInfo::addDeletion(int sIndex, int len)
{
    delVec.push_back(len);
    AnnInfo aInfo(sIndex + 1, sIndex + len, PhyloTreeNode::DELETION, len);
    annInfoVec.push_back(aInfo);
}

int BranchInfo::getTotalLenOfIns()
{
    int total = 0;
    for (int i = 0; i < (int)insVec.size(); i++)
    {
        total += insVec.at(i);
    } // end of for

    return total;
}

int BranchInfo::getTotalLenOfDel()
{
    int total = 0;
    for (int i = 0; i < (int)delVec.size(); i++)
    {
        total += delVec.at(i);
    } // end of for

    return total;
}

void BranchInfo::clear()
{
    numOfMisMatch = 0;
    numOfMatch = 0;
    insVec.clear();
    vector<int>().swap(insVec);
    delVec.clear();
    vector<int>().swap(delVec);
}

vector<int>* BranchInfo::getInsLenVec()
{
    return &(insVec);
}

vector<int>* BranchInfo::getDelLenVec()
{
    return &(delVec);
}

vector<int> BranchInfo::getInsLenVecValue()
{
    return insVec;
}

vector<int> BranchInfo::getDelLenVecValue()
{
    return delVec;
}

vector<AnnInfo>* BranchInfo::getAnnInfoVec()
{
    return &annInfoVec;    
}

BranchInfo::BranchInfo(BranchInfo* bInfo)
{
    numOfMisMatch = bInfo->numOfMisMatch;
    numOfMatch = bInfo->numOfMatch;
    insVec = bInfo->insVec;
    delVec = bInfo->delVec;
    for (int i = 0; i < bInfo->annInfoVec.size(); i++)
    {
        AnnInfo aInfo(bInfo->annInfoVec.at(i));
        annInfoVec.push_back(aInfo);
    } // end of for
}

void BranchInfo::addAnnInfo(AnnInfo aInfo)
{
    annInfoVec.push_back(aInfo);
}


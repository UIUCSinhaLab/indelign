// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "SeqGen.h"
#include <stdlib.h>
#include <time.h>

SeqInfo::SeqInfo()
{

}

SeqInfo::SeqInfo(string str, int sIndex, int eIndex)
{
    m_seq = str;
    m_startIndexOfChange = sIndex;
    m_endIndexOfChange = eIndex;
}

SeqInfo::SeqInfo(const SeqInfo& sInfo)
{
    m_seq = sInfo.m_seq;
    m_startIndexOfChange = sInfo.m_startIndexOfChange;
    m_endIndexOfChange = sInfo.m_endIndexOfChange;
}

SeqInfo::~SeqInfo()
{

}

string SeqInfo::getSeq()
{
    return m_seq;
}

int SeqInfo::getStartIndexOfChange()
{
    return m_startIndexOfChange;
}

int SeqInfo::getEndIndexOfChange()
{
    return m_endIndexOfChange;
}

SeqGen::SeqGen()
{

}

SeqGen::SeqGen(string seq)
{
	orgSeq = seq;
	
	residueCnt = 0;
	gapCnt = 0;
	
	int colNum = (int)orgSeq.size();
	for(int i=0;i<colNum;i++)
	{
		if(orgSeq.at(i) == '-'){
			int start = i;
			while((i<colNum) && (orgSeq.at(i) == '-')){
				i++;
			}
			i--;
			int end = i;
			int length = end - start + 1;
			gapLength.push_back(length);				
			gapStartIndex.push_back(start);
			gapCnt++;			
		}else{
			char res = orgSeq.at(i);
			residue.push_back(res);
			residueCnt++;
		}
	}
}

SeqGen::SeqGen(string bmap,string seq, int sIndex)
{
	orgSeq = seq;
	seqIndex = sIndex;

	residueCnt = 0;
	gapCnt = 0;
	
	int colNum = (int)orgSeq.size();
	int start=-1;
	int end=-1;
	int length=0;
	for(int i=0;i<colNum;i++)
	{
        if (orgSeq.at(i) == '-')
        {
            start = i;
            i++;
            vector<int> delVec;
            while (i < colNum && orgSeq.at(i) == '-')
            {
                if (bmap.at(i) == 'G') delVec.push_back(i);
                i++;
            } // end of while
            end = i - 1;

            length = end - start + 1;
            gapLength.push_back(length);				
			gapStartIndex.push_back(start);
			gapCnt++;	

            if (delVec.size() > 0)
            {
                for (int vi = 0; vi < delVec.size(); vi++)
                {
                    int delIndex = delVec.at(vi);

                    length = delIndex - start;
                    gapLength.push_back(length);				
				    gapStartIndex.push_back(start);
                    gapCnt++;

                    length = end - delIndex + 1;
                    gapLength.push_back(length);				
				    gapStartIndex.push_back(delIndex);
                    gapCnt++;
                } // end of for
            } // end of else
        } // end of if
	}
}

SeqGen::~SeqGen()
{
	strVec.clear();
    vector<string>().swap(strVec);
}

vector<string> SeqGen::combGen()
{
	string temp; // assign the empty string
	seqGen(0,0,temp);
	
	return strVec;
}

void SeqGen::seqGen(int residuePtr,int gapPtr,string currentString)
{
	if(gapPtr == gapCnt){
		currentString.append(residue,residuePtr,residueCnt - residuePtr);
		strVec.push_back(currentString);	
	}else{
		if(residuePtr == residueCnt){
			for(int i=gapPtr;i<gapCnt;i++){
				currentString.append(gapLength.at(i),'-');
			}
			strVec.push_back(currentString);
		}else{
			//Case1:
			string temp1 = currentString;			
			temp1.append(gapLength.at(gapPtr),'-');
			seqGen(residuePtr,gapPtr+1,temp1);
			
			//Case2:
			string temp2 = currentString;
			temp2.append(residue,residuePtr,1);
			seqGen(residuePtr+1,gapPtr,temp2); 
		}
	}
}

//
// Make candidates using one sequence
// numShift = 1
vector<string> SeqGen::approxCombGen()
{
	int colNum = (int)orgSeq.size();


	strVec.push_back(orgSeq);

	if(gapCnt != 0){

   	    srand( time(NULL) );
	    int eventIndex = rand() % gapCnt;
        	
	    int eventLength = gapLength.at(eventIndex);

	    if(eventLength != colNum){
	        int eventStart = gapStartIndex.at(eventIndex);
        	
	        string before;
	        string beforeChar;
	        string afterChar;
	        string after;

	        if(eventStart > 1){before = orgSeq.substr(0,eventStart-1);}
	        if(eventStart > 0){beforeChar = orgSeq.substr(eventStart-1,1);}
	        if(eventStart + eventLength - 1 <= colNum - 2){afterChar = orgSeq.substr(eventStart+eventLength,1);}
	        if(eventStart + eventLength - 1 <= colNum - 3){after = orgSeq.substr(eventStart+eventLength+1);}

	        string leftTemp; 
	        leftTemp = before;
	        string rightTemp;
	        rightTemp = before;

	        leftTemp.append(eventLength,'-');
	        leftTemp.append(beforeChar);
	        leftTemp.append(afterChar);
	        leftTemp.append(after);
        	
	        rightTemp.append(beforeChar);
	        rightTemp.append(afterChar);
	        rightTemp.append(eventLength,'-');
	        rightTemp.append(after);
        	
	        if(orgSeq.compare(leftTemp) != 0){
		        strVec.push_back(leftTemp);
	        }
        	
	        if(orgSeq.compare(rightTemp) != 0){
		        strVec.push_back(rightTemp);
	        }

	    }
	}
	
	return strVec;
}

vector<SeqInfo> SeqGen::approxCombGen(int numShift, TInterAnchor* tAnchor, int iaNum)
{
	int colNum = (int)orgSeq.size();

    vector<SeqInfo> sInfoVec;

	if(gapCnt != 0)
    {
	int eventIndex = rand_ulong(gapCnt - 1);
	    int eventLength = gapLength.at(eventIndex);

	    if(eventLength != colNum)
        {
	        int eventStart = gapStartIndex.at(eventIndex);
        	
            // Get left and right boundary index
            int leftLimit = 0;
            int rightLimit = 0;

            if (eventIndex == 0)
                leftLimit = 0;
            else
            {
                int pIndex = gapStartIndex.at(eventIndex - 1);
                int pLen = gapLength.at(eventIndex - 1);
                leftLimit = pIndex + pLen;
            } // end of else
            
            if (gapStartIndex.size() > eventIndex + 1)
                rightLimit = gapStartIndex.at(eventIndex + 1);
            else
                rightLimit = colNum;
            
            string leftOfGap = orgSeq.substr(0, eventStart);
            string rightOfGap = orgSeq.substr(eventStart + eventLength);

            for (int i = 1; i <= numShift; i++)
            {
                // To left direction
                if (eventStart - i >= leftLimit)
                {
                    string tmpLeft = orgSeq.substr(0, eventStart - i);
                    string tmpMiddle = orgSeq.substr(eventStart - i, i);
                    string resStr = tmpLeft;
                    resStr.append(eventLength, '-');
                    resStr.append(tmpMiddle);
                    resStr.append(rightOfGap);
                    if(orgSeq.compare(resStr) != 0)
                    {
                        SeqInfo sInfo(resStr, eventStart - i, eventStart + eventLength - 1);
                        sInfoVec.push_back(sInfo);
                    } // end of if
                } // end of if
            } // end of for

            for (int i = 1; i <= numShift; i++)
            {
                // To right direction
                int eventBack = eventStart + eventLength;
                                
                if (eventBack + i <= rightLimit)
                {
                    string tmpRight = orgSeq.substr(eventBack + i);
                    string tmpMiddle = orgSeq.substr(eventBack, i);
                    string resStr = leftOfGap;
                    resStr.append(tmpMiddle);
                    resStr.append(eventLength, '-');
                    resStr.append(tmpRight);
                    if(orgSeq.compare(resStr) != 0)
                    {
                        SeqInfo sInfo(resStr, eventStart, eventBack + i - 1);
                        sInfoVec.push_back(sInfo);
                    } // end of if
                } // end of if
            } // end of for
	    }
	}
    return sInfoVec;
}

int SeqGen::getGapCnt()
{
    return gapCnt;
}

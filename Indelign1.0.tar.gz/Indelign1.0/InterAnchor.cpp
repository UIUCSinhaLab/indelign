// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "InterAnchor.h"

using namespace std;

InterAnchor::InterAnchor()
{
	nSeq =0;
}

InterAnchor::InterAnchor(int num) 
{ 
	nSeq = num; 
}

InterAnchor::~InterAnchor()
{

}
	
void InterAnchor::setSequence(vector<string> seqVec)
{
	dnaSeq = seqVec;
	string str1 = dnaSeq.at(0);
	colNum = (int)str1.size();

    for (int i = 0; i < nSeq; i++)
    {
        string str = "";
        str.append(colNum, '-');
        ancVec.push_back(str);
    } // end of for
}

vector<string>* InterAnchor::getSequenceP()
{
    return &dnaSeq;
}

void InterAnchor::dump()
{
	for (int i = 0; i < (int)dnaSeq.size(); i++)
	{
		string seq = dnaSeq.at(i);
        cerr << seq << endl;
	}

    cerr << "anchorVec size:" << ancVec.size() << endl;
    for (int i = 0; i < (int)ancVec.size(); i++)
    {
        string anc = ancVec.at(i);
        cerr << anc << endl;
    } // end of for
    cerr << endl;
}

int InterAnchor::getSize()
{
	return (int)dnaSeq.size();
}

int InterAnchor::getColumnNumber()
{
	return colNum;
}

void InterAnchor::setAnchorAt(int seqNum, int index)
{
    ancVec.at(seqNum - 1).at(index) = 'A';
}

bool InterAnchor::isAnchorAt(int seqNum, int index)
{
    bool bRes = false;
    if (ancVec.at(seqNum - 1).at(index) == 'A') bRes = true;
    else bRes = false;
    return bRes;
}

string InterAnchor::getSequenceAt(int seqNum)
{
    return dnaSeq.at(seqNum - 1);
}

int InterAnchor::getTempSize()
{
    return (int)ancVec.size();
}

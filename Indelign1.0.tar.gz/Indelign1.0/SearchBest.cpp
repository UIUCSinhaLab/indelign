// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "SearchBest.h"
#include <math.h>
#include <fstream>
#include <algorithm>

OutputDS::OutputDS()
{
	startIndex = -1;
	endIndex = -1;
	annotation = "Not created";	
    length = 0;
}

OutputDS::OutputDS(int s, int e, string ann, int len)
{
	startIndex = s;
	endIndex = e;
	annotation = ann;
    length = len;
}

OutputDS::~OutputDS()
{

}

int OutputDS::getStartIndex()
{
	return startIndex;
}

int OutputDS::getEndIndex()
{	
	return endIndex;
}

string OutputDS::getAnnotation()
{
	return annotation;
}

int OutputDS::getLength()
{
    return length;
}

SearchBest::SearchBest()
{
	constMut = constIns = constDel = 0.0;
	sumOfLenSquare = 0.0;
	bestScore = -100000000.0;
    insLenAvg = delLenAvg = 0.0;
    insLambda = delLambda = 0.0;
    insrzeta = delrzeta = 0.0; 
    insProbSuccess = delProbSuccess = 0.0;

}

SearchBest::~SearchBest()
{
    //delete anchorBranchInfo;
}

void SearchBest::outputResults(string seqFile, string anchorFile, string outFile1, string outFile2, string outFile3)
{
#ifdef DEBUG_OUTPUT
	cerr << endl;
   	cerr << "Output results into 2 output files" << endl;
#endif

	vector<string> fullSeq;
	vector<string> seqName;
	
	map<int, int> anchorStart;
	map<int, int> anchorLength;
	map<int, int> ianchorStart;
	int anchorNum;
	int totalColNum=0;
	
	vector<string> updatedSeq;
	
	// Preprocess seqFile
	ifstream infile(seqFile.c_str());
	string line;
	string sequence;
	if(infile.is_open())
	{
		bool bReady = false;
		while(!infile.eof())
	  	{
	    	getline(infile,line);

			if(line.length() != 0){
				int loc = (int)line.find('>',0);
				if(loc == string::npos){
					sequence.append(line);
				}else{
					if(bReady){//A sring was formed
						fullSeq.push_back(sequence);
					}
					seqName.push_back(line);
					bReady = true;
					sequence.clear();
				}
			}		
	  	}
		infile.close();
		if(bReady){
			fullSeq.push_back(sequence);
		}
	}

	int fi;
	ifstream fp_in(anchorFile.c_str());
	if(fp_in.is_open()){
		fp_in >> totalColNum;
		fp_in >> anchorNum;
		fi=1;
		while(fi <= anchorNum)
		{
			int start, end;
			fp_in >> start;
			fp_in >> end;
			anchorStart[fi] = start;
			anchorLength[fi] = end - start + 1;
			fi++;
	  	}
		fp_in.close();
	}

    int origColNum = totalColNum;
	string temp_seq;
	for(int s=0;s<nSeq;s++){
		temp_seq.clear();
		int anchorPtr=1;
		int interanchorPtr=1;
        totalColNum = origColNum; // added this line
        int cntCol = 1;
		for(int currentPtr=1;currentPtr<=totalColNum;)
		{
			if(anchorStart.size() > 0 && anchorStart[anchorPtr] == currentPtr){
				int start = anchorStart[anchorPtr];
				int length = anchorLength[anchorPtr];
				string anchor = fullSeq.at(s).substr(start-1,length);
				temp_seq.append(anchor);
				anchorPtr++;
				currentPtr += length;	
                                cntCol += length;
			}else{
                                if (interanchorPtr > bestBChunkMap.size()) break;

				BoundaryChunk bc = bestBChunkMap[interanchorPtr];	
				string ianchor = (bc.getSeqVec())->at(s);
                                int length = 0;
                                if (anchorStart.size() > 0)
                                {
                                        if (anchorPtr == 1)
                                            length = anchorStart[anchorPtr] - 1;
                                        else if (anchorPtr > anchorNum)
                                            length = totalColNum - (anchorStart[anchorPtr - 1] + anchorLength[anchorPtr - 1]);                
                                        else 
                                            length = anchorStart[anchorPtr] - (anchorStart[anchorPtr - 1] + anchorLength[anchorPtr - 1]);
                                } // end of if
                                else
                                {
                                        length = totalColNum;
                                }

				temp_seq.append(ianchor);

                                int newlen = (int)ianchor.length();
                ianchorStart[interanchorPtr] = cntCol;

				interanchorPtr++;
				currentPtr += length;
                                cntCol += newlen;
			}	
		}
		updatedSeq.push_back(temp_seq);	
	}
	m_leafSeqVec = updatedSeq;

	ofstream fout(outFile1.c_str());
	ofstream fout3(outFile3.c_str());
	for(int i=0;i<nSeq;i++){
		fout << seqName.at(i) << endl;
		fout3 << seqName.at(i) << endl;
		fout3 << updatedSeq.at(i) << endl;

		string longseq = updatedSeq.at(i);
		int long_length = (int)longseq.length();
		for(int s_id = 0;s_id < long_length;){
			string shortseq = longseq.substr(s_id,60);
			fout << shortseq << endl;
			s_id+=60;
		}

	}
	fout.close();	
	fout3.close();	

	map<int, vector<OutputDS> > finalResultOut;
    map<int, vector<OutputDS> > finalResultOutAnc;

#ifdef DEBUG_OUTPUT
	cerr << "After output1...." << endl;
#endif

        // key: Inter-anchor number, value: ancestor sequence template
        map<int, vector<string> > ancSeqMap;

	for (int i = 1; i <= tInterAnchor->getNumOfInterAnchor(); i++)
    {
                vector<string> tmpAncSeqVec;
    		int startPos = ianchorStart[i];

	        BoundaryChunk bc = bestBChunkMap[i];
        	vector<BestAnnotation> annVec = bestBestScoreIAnchorMap[i];
        	
            for (int j = 0; j < (int)annVec.size(); j++)
            {
                BestAnnotation bAnn = annVec.at(j);
                BranchInfoSet* bInfoSet = bAnn.getBranchInfoSet();
                int baStartIndex = bAnn.getStartColIndex();
                vector<string> tmpVec;

                for (int s = 1; s <= nSeq; s++)
                {
                    int bIndex = tInterAnchor->getBranchForLeafSeq(s);
                    BranchInfo* bInfo = bInfoSet->getBranchInfoAt(bIndex);
                    vector<AnnInfo>* aInfoVec = bInfo->getAnnInfoVec();

                    for (int afIndex = 0; afIndex < aInfoVec->size(); afIndex++)
                    {
                        AnnInfo aInfo = aInfoVec->at(afIndex);
                        int start = aInfo.getStartIndex() + baStartIndex + startPos - 1;
			            int end = aInfo.getEndIndex() + baStartIndex + startPos - 1;
			            int anno = aInfo.getAnn();	
            			
			            string anno_str;
                        if(anno == PhyloTreeNode::INSERTION){anno_str = "Insertion";}
			            else{
                            if(anno == PhyloTreeNode::DELETION){anno_str = "Deletion";}
				            else{anno_str = "anno_error";}
			            }
            			
			            OutputDS currentItem(start,end,anno_str, aInfo.getLength());
			            finalResultOut[s].push_back(currentItem);
                    } // end of for
                } // end of for

                // internal nodes
                for (int s = nSeq + 1; s < rootNodeIndex; s++)
                {
                    int bIndex = tInterAnchor->getBranchForLeafSeq(s);
                    BranchInfo* bInfo = bInfoSet->getBranchInfoAt(bIndex);
                    vector<AnnInfo>* aInfoVec = bInfo->getAnnInfoVec();

                    for (int afIndex = 0; afIndex < aInfoVec->size(); afIndex++)
                    {
                        AnnInfo aInfo = aInfoVec->at(afIndex);
                        int start = aInfo.getStartIndex() + baStartIndex + startPos - 1;
			            int end = aInfo.getEndIndex() + baStartIndex + startPos - 1;
			            int anno = aInfo.getAnn();	
            			
			            string anno_str;
                        if(anno == PhyloTreeNode::INSERTION){anno_str = "Insertion";}
			            else{
                            if(anno == PhyloTreeNode::DELETION){anno_str = "Deletion";}
				            else{anno_str = "anno_error";}
			            }
            			
			            OutputDS currentItem(start,end,anno_str, aInfo.getLength());
			            finalResultOutAnc[s].push_back(currentItem);
                    } // end of for
                } // end of for

                // Generate ancestral sequence templates
                for (int s = nSeq + 1; s <= rootNodeIndex; s++)
                {
                    // get numbers of children.
                    vector<int> chVec = treeMap->operator[](s);
                    int bLeftIndex = tInterAnchor->getBranchNumForSeq(chVec.at(0));
                    int bRightIndex = tInterAnchor->getBranchNumForSeq(chVec.at(1));
                    BranchInfo* bLeftInfo = bInfoSet->getBranchInfoAt(bLeftIndex);
                    BranchInfo* bRightInfo = bInfoSet->getBranchInfoAt(bRightIndex);
                    vector<AnnInfo>* aLeftInfoVec = bLeftInfo->getAnnInfoVec();
                    vector<AnnInfo>* aRightInfoVec = bRightInfo->getAnnInfoVec();

                    int baStartIndex = bAnn.getStartColIndex();
                    int baEndIndex = bAnn.getEndColIndex();
                    string tmpSeq1 = "";
                    string tmpSeq2 = "";
                    if (chVec.at(0) <= nSeq) {
                        // get child sequence from leaf node
                        tmpSeq1 = (bc.getSeqVec())->at(chVec.at(0) - 1);
                        tmpSeq1 = tmpSeq1.substr(baStartIndex, baEndIndex - baStartIndex + 1);
                    } else {
                        // get child sequence from internal node
                        tmpSeq1 = tmpVec.at(chVec.at(0) - nSeq - 1);
                    } // end of else if
                    if (chVec.at(1) <= nSeq) {
                        // get child sequence from leaf node
                        tmpSeq2 = (bc.getSeqVec())->at(chVec.at(1) - 1);
                        tmpSeq2 = tmpSeq2.substr(baStartIndex, baEndIndex - baStartIndex + 1);
                    } else {
                        // get child sequence from internal node
                        tmpSeq2 = tmpVec.at(chVec.at(1) - nSeq - 1);
                    } // end of else if

                    // compare two children sequences and construct parent template
                    string tmpSeq = "";
                    for (int ci = 0; ci < tmpSeq1.length(); ci++)
                    {
                        if (tmpSeq1.at(ci) == '-' && tmpSeq2.at(ci) == '-') tmpSeq.push_back('-');
                        else tmpSeq.push_back('N');
                    } // end of for (int ci)

                    for (int afIndex = 0; afIndex < aLeftInfoVec->size(); afIndex++)
                    {
                        AnnInfo aInfo = aLeftInfoVec->at(afIndex);
                        int start = aInfo.getStartIndex();
                        int end = aInfo.getEndIndex();
                        int anno = aInfo.getAnn();	
                        
                        string anno_str;
                        if(anno == PhyloTreeNode::INSERTION){ 
                            tmpSeq.replace(start, end - start + 1, end - start + 1, '-');
                        } // end of if
                        else{
                        }
                    } // end of for
                    
                    for (int afIndex = 0; afIndex < aRightInfoVec->size(); afIndex++)
                    {
                        AnnInfo aInfo = aRightInfoVec->at(afIndex);
                        int start = aInfo.getStartIndex();
                        int end = aInfo.getEndIndex();
                        int anno = aInfo.getAnn();	
                        
                        string anno_str;
                        if(anno == PhyloTreeNode::INSERTION){ 
                            tmpSeq.replace(start, end - start + 1, end - start + 1, '-');
                        } // end of if
                        else{
                        }

                    } // end of for

                    // store generated string template
                    tmpVec.push_back(tmpSeq);
                } // end of for

                // store generated string template
                if (j == 0) {
                    tmpAncSeqVec = tmpVec;
                } else {
                    for (int si = 0; si < tmpVec.size(); si++) tmpAncSeqVec.at(si).append(tmpVec.at(si));
                } // end of if else
            } // end of for

            ancSeqMap[i] = tmpAncSeqVec;
    } // end of for
    
#ifdef DEBUG_OUTPUT
	cerr << "Check point1...." << endl;
#endif	

    // Concatenate generated ancestral IA sequences
    temp_seq = "";
    for(int s = nSeq + 1; s <= rootNodeIndex ;s++)
    {
        temp_seq.clear();
        int anchorPtr=1;
        int interanchorPtr=1;
        totalColNum = origColNum; // added this line
        int cntCol = 1;

        for(int currentPtr=1;currentPtr<=totalColNum;)
        {
            if(anchorStart.size() > 0 && anchorStart[anchorPtr] == currentPtr)
            {
                int start = anchorStart[anchorPtr];
                int length = anchorLength[anchorPtr];
                string anchor(length, 'N');

                temp_seq.append(anchor);
                anchorPtr++;
                currentPtr += length;	
                cntCol += length;
            } // end of if
            else
            {
                if (interanchorPtr > bestBChunkMap.size()) break;

                vector<string> tmpVec = ancSeqMap[interanchorPtr];	
                string ianchor = tmpVec.at(s - nSeq - 1);
                int length = 0;
                
                if (anchorStart.size() > 0)
                {
                    if (anchorPtr == 1) 
                        length = anchorStart[anchorPtr] - 1;
                    else if (anchorPtr > anchorNum)
                        length = totalColNum - (anchorStart[anchorPtr - 1] + anchorLength[anchorPtr - 1]);                
                    else 
                        length = anchorStart[anchorPtr] - (anchorStart[anchorPtr - 1] + anchorLength[anchorPtr - 1]);
                }
                else
                {
                    length = totalColNum;
                }
                temp_seq.append(ianchor);

                int newlen = (int)ianchor.length();
                ianchorStart[interanchorPtr] = cntCol;

                interanchorPtr++;
                currentPtr += length;
                cntCol += newlen;
            } // end of else	
        } // end of for
        
        m_ancSeqVec.push_back(temp_seq);	
    } // end of for
    ///////////////////////////////////////////////// end of new codes
#ifdef DEBUG_OUTPUT
	cerr << "Check point2...." << endl;
#endif	

	ofstream fout2(outFile2.c_str());
    ofstream foutIndel("IndelLengthDist.txt");
    foutIndel << "Species\tType\tLength\tCount" << endl;

    ofstream foutIndel2("IndelCount.txt");
    foutIndel2 << "Species\tInsertion\tDeletion\tTotal" << endl;

	for(int s=1;s<=nSeq;s++){
        // Merge continuous indels
        vector<OutputDS> newResult;    

        for(int j=0;j<(int)finalResultOut[s].size();j++)
        {
		    int start = finalResultOut[s].at(j).getStartIndex();
		    int end = finalResultOut[s].at(j).getEndIndex();
		    string anno = finalResultOut[s].at(j).getAnnotation();
  	        
            if (j == 0)
                newResult.push_back(finalResultOut[s].at(j));
            else
            {
                int pend = newResult.at(newResult.size() - 1).getEndIndex();
                string panno = newResult.at(newResult.size() - 1).getAnnotation();
                if (anno != panno)
                {
                    newResult.push_back(finalResultOut[s].at(j));
                } // end of if
                else
                {
                    if ((pend + 1) == start)
                    {
                        int pstart = newResult.at(newResult.size() - 1).getStartIndex();
                        OutputDS currentItem(pstart,end,anno,finalResultOut[s].at(j).getLength() + newResult.at(newResult.size() - 1).getLength());
                        newResult.pop_back();
                        newResult.push_back(currentItem);
                    } // end of if
                    else
                    {
                        newResult.push_back(finalResultOut[s].at(j));
                    } // end of else
                } // end of else
            } // end of else
	    }

#ifdef DEBUG_OUTPUT
        cerr << "Sequence " << s << ": ";
#endif

		fout2 << "Sequence " << nodeNameMap->operator [](s) << endl;	

        int numIns = 0;
        int numDel = 0;
        map<int, int> tmpInsMap;
        map<int, int> tmpDelMap;
        map<int, int>::iterator iiIter;
		for(int j=0;j<(int)newResult.size();j++){
			int start = newResult.at(j).getStartIndex();
			int end = newResult.at(j).getEndIndex();
            int len = newResult.at(j).getLength();
			string anno = newResult.at(j).getAnnotation();
            if (anno.compare("Insertion") == 0)
            {
                numIns++;
                iiIter = tmpInsMap.find(len);
                if (iiIter == tmpInsMap.end()) tmpInsMap[len] = 1;
                else tmpInsMap[len]++;
            } // end of if
            else if (anno.compare("Deletion") == 0)
            {
                numDel++;
                if (iiIter == tmpDelMap.end()) tmpDelMap[len] = 1;
                else tmpDelMap[len]++;
            } // end of else if
			fout2 << "\t" << start + 1 << "\t" << end + 1 << "\t" << anno;			
            /*
            if (len != (end - start + 1))
                fout2 << "\tSplitted one indel" << endl;
            else
                fout2 << endl;
            */
            fout2 << endl;
		}

#ifdef DEBUG_OUTPUT
        cerr << "NumIns:" << numIns << " numDel:" << numDel << endl;
#endif

        for (iiIter = tmpInsMap.begin(); iiIter != tmpInsMap.end(); iiIter++)
            foutIndel << nodeNameMap->operator [](s) << "\tIns\t" << iiIter->first << "\t" << iiIter->second << endl;

        for (iiIter = tmpDelMap.begin(); iiIter != tmpDelMap.end(); iiIter++)
            foutIndel << nodeNameMap->operator [](s) << "\tDel\t" << iiIter->first << "\t" << iiIter->second << endl;
        foutIndel << endl;

        foutIndel2 << nodeNameMap->operator [](s) << "\t" << numIns << "\t" << numDel << "\t" << numIns + numDel << endl;
	}
	fout2.close();
    foutIndel.close();
    foutIndel2.close();

}

double SearchBest::getBestAlign(string sFile, string aFile, string oFile1, string oFile2, string oFile3)
{
    // Call initial alignment function first
    getInitialAlign(sFile, aFile, oFile1, oFile2, oFile3);

	int stabled = 0;
    int false_stabled = 0;
	bool notReduced = true;
    bool notSubReduced = true;
	bool notPrevBest = true;
    double prevScore = 0.0;

    int numIter = 0;
	do	
	{
		numIter++;
		cerr << endl;
		cerr << "Iteration:" << numIter << endl;

		int numSubIter = 0;
		int subStabled = 0;

        if (numIter == 1) prevScore = bestScore;

        map<int, BoundaryChunk>::iterator bcIter;
        for(bcIter = bestBChunkMap.begin(); bcIter != bestBChunkMap.end(); bcIter++)
        {
            int iaNum = bcIter->first;  // Inter-Anchor number
            m_subBestBC = bcIter->second;  // Boundary chunk for the inter-anchor
            interanchorScore = -100000000.0;//Set the minimum interanchor score
            
            //cerr << endl;
            cerr << "Processing Inter-Anchor: " << iaNum << "/" << bestBChunkMap.size() << endl; 

            int iterCnt = 0;
            m_numConv = 0;
            m_bestAnnVec.clear();
            vector<BestAnnotation>().swap(m_bestAnnVec);

            // calculate initial score
            m_subBestScore = 0.0;
            m_subBestAnnVec = bestBestScoreIAnchorMap[iaNum];

#ifdef DEBUG_OUTPUT
            cerr << "\tInitial sequences" << endl;
            dumpBC(&m_subBestBC);
            dumpAnnVec(&m_subBestBC, &m_subBestAnnVec);
#endif

            for (int i = 0; i < (int)m_subBestAnnVec.size(); i++)
            {
                BestAnnotation bAnn = m_subBestAnnVec.at(i);
                m_subBestScore += bAnn.getScore();
            } // end of for

            double currentScore = -100000000.0;
            m_bSavedBothLocation = false;
            m_bChangedScore = false;
            // Sequence queue init.
            
            Util::seqQueueInit(nSeq);
            while(true)
            {

                iterCnt++;
                possibleSeq.clear();
                map<int, vector<string> >().swap(possibleSeq);
                int numCol = (int)(m_subBestBC.getSeqVec())->at(0).length();  // total number of column
                locationChangeV2(m_subBestBC.getSeqVec(), nSeq, numCol, iaNum);    
                
#ifdef DEBUG_OUTPUT
                // dump result
                cerr << "<-- Selected best candidate:" << endl;
                dumpBC(&m_subBestBC);
                dumpAnnVec(&m_subBestBC, &m_subBestAnnVec);
                cerr << "-->" << endl;
#endif

#ifdef DEBUG_OUTPUT
                cerr << "\tBest score seen so far: " << m_subBestScore << endl;
                cerr << "\tWhole IA Score: " << bestScore << ", numConv: " << m_numConv << endl;
#endif
                
                if (m_bChangedScore == true) 
                {
                    m_numConv = 0;
                    m_bChangedScore = false;
                } // end of if
                else m_numConv++;

                if (m_numConv >= m_numIter) break;
            } // end of while

            //
            // Save the found best inter-anchor structure and annotation to subBChunkMap
            // and subBestScoreIAnchorMap
            //
            subBChunkMap[iaNum] = m_subBestBC;
            subBestScoreIAnchorMap[iaNum].clear();
            vector<BestAnnotation>().swap(subBestScoreIAnchorMap[iaNum]);
            subBestScoreIAnchorMap[iaNum] = m_subBestAnnVec;
            m_subBestAnnVec.clear();
            vector<BestAnnotation>().swap(m_subBestAnnVec);
        } // end of for int i
        
        //
        // Check global convergence
        //
	double newScore;
	newScore = getFinalScoreEx(&subBestScoreIAnchorMap);

#ifdef DEBUG_OUTPUT
        cerr << "New Total Score:" << newScore << endl;
#endif
        prevScore = newScore;
	if(newScore < bestScore){
	   notReduced = false;		
            stabled = 0;

            subBestScoreIAnchorMap.clear();
            map<int, vector<BestAnnotation> >().swap(subBestScoreIAnchorMap);

            if (prevScore == newScore)
            {
                false_stabled++;
            } // end of if
		}else{
            false_stabled = 0;
			if(newScore == bestScore){
                stabled++;
			}else{
				bestScore = newScore;
                bestBChunkMap = subBChunkMap;

                bestBestScoreIAnchorMap.clear();
                map<int, vector<BestAnnotation> >().swap(bestBestScoreIAnchorMap);

                bestBestScoreIAnchorMap = subBestScoreIAnchorMap;
                subBestScoreIAnchorMap.clear();
                map<int, vector<BestAnnotation> >().swap(subBestScoreIAnchorMap);
                
		stabled = 0;
                summaryBranchInfo(&bestBChunkMap, &bestBestScoreIAnchorMap);
                if (notRe == false) reestimateParam();

                /*
                cerr << endl;
                cerr << "[Realignment]" << endl;

                cerr << bestScore;

                cerr << "New Initial parameters:" << endl;
                cerr << "\tconstIns:" << constIns << endl;
                cerr << "\tconstDel:" << constDel << endl;
                cerr << "\tF81 param:" << m_paramU << endl;
                */
			}
		}

#ifdef DEBUG_OUTPUT
		cerr << "New Best Score:" << bestScore << endl;
#endif
    }while(stabled < NUM_ITER && false_stabled < NUM_ITER);

	summaryBranchInfo(&bestBChunkMap, &bestBestScoreIAnchorMap);
	if (notRe == false) reestimateParam();

#ifdef DEBUG_OUTPUT
    cerr << endl;
    cerr << "Final results..." << endl;
    for (int i = 0; i < tInterAnchor->getNumOfInterAnchor(); i++)
    {
        cerr << "Inter-Anchor:" << i + 1 << endl;
        dumpBC(&bestBChunkMap[i + 1]);
        dumpAnnVec(&bestBChunkMap[i + 1], &bestBestScoreIAnchorMap[i + 1]);
    } // end of for
    cerr << endl;
#endif

    //cerr << "[Final] " << endl;
    //cout << "Final ";
        
    cerr << endl;
    cerr << "Indelign finished the annotation with search." << endl;
    outputResults(sFile, aFile, oFile1, oFile2, oFile3);
    outputParameters();
    return bestScore;
}

double SearchBest::annotateAlign(string sFile, string aFile, string oFile1, string oFile2, string oFile3)
{
#ifdef DEBUG_OUTPUT
    cerr << "annotateAlign function" << endl;
#endif
    double bestTScore = -10000000.0;
    int cnt = 0;
    
    while (true)
    {
//#ifdef DEBUG_OUTPUT
        cerr << endl;
        cerr << "Iteration: " << cnt + 1 << endl;
//#endif
        map<int, BoundaryChunk>::iterator bcIter;
        for(bcIter = bestBChunkMap.begin(); bcIter != bestBChunkMap.end(); bcIter++)
        {
            cerr << "Processing Inter-Anchor: " << bcIter->first << "/" << bestBChunkMap.size() << endl;
            int iaNum = bcIter->first;  // Inter-Anchor number
            BoundaryChunk bc = bcIter->second;  // Boundary chunk for the inter-anchor

    #ifdef DEBUG_OUTPUT
            cerr << "\tInitial sequences" << endl;
            dumpBC(&bc);
    #endif
	    int numCol = (int)(bc.getSeqVec())->at(0).length();  // total number of column
            vector<BestAnnotation> ba = findBestAnnotationHybrid(&bc, numCol, 0);
            bestBestScoreIAnchorMap[iaNum] = ba;

    #ifdef DEBUG_OUTPUT        
            dumpAnnVec(&bc, &ba);
    #endif
        } // end of for int i
        
        double newScore = getFinalScoreEx(&bestBestScoreIAnchorMap);
        //cerr << newScore;
          
        if (cnt == 0 || newScore > bestTScore)
        {
            bestTScore = newScore;

            // estimate parameters
            summaryBranchInfo(&bestBChunkMap, &bestBestScoreIAnchorMap);
            if (notRe == false) reestimateParam();
 
            /*
            cerr << "New Initial parameters:" << endl;
            cerr << "\tconstIns:" << constIns << endl;
            cerr << "\tconstDel:" << constDel << endl;
            cerr << "\tF81 param:" << m_paramU << endl;
            */
        } // end of if
        else if ((cnt > 0 && newScore <= bestTScore) || notRe == true)
        {
            break;
        } // end of else if

        cnt++;
    } // end of while
    
	// estimate parameters
	summaryBranchInfo(&bestBChunkMap, &bestBestScoreIAnchorMap);
	if (notRe == false) reestimateParam();

    double newScore = getFinalScoreEx(&bestBestScoreIAnchorMap);
    outputResults(sFile, aFile, oFile1, oFile2, oFile3);
    
    //string cmd = "cp " + oFile2 + " SampleAnnotation.txt";
    //runSystemCmd(cmd, false);
    //cout << endl;
    //cerr << endl;
    
    cerr << endl;
    cerr << "Indelign finished the annotation with search." << endl;
    outputParameters();
	return newScore;
}


void SearchBest::checkAbnormalAlignment(string sFile, string aFile)
{
    m_bAbnormalAlignment = false;
    double bestTScore = -10000000.0;
    int cnt = 0;

    map<int, BoundaryChunk>::iterator bcIter;
    for(bcIter = bestBChunkMap.begin(); bcIter != bestBChunkMap.end(); bcIter++)
    {
        int iaNum = bcIter->first;  // Inter-Anchor number
#ifdef DEBUG_OUTPUT        
        cerr << endl;
        cerr << "[Inter-Anchor Number: " << iaNum << "]" << endl;
#endif
        BoundaryChunk bc = bcIter->second;  // Boundary chunk for the inter-anchor

        int numCol = (int)(bc.getSeqVec())->at(0).length();  // total number of column
        checkAlignment(&bc, numCol, 0);

        if (m_bAbnormalAlignment == true) break;
    } // end of for int i
        
    if (m_bAbnormalAlignment == false) cout << "false";
    else cout << "true";
}

// 
// Consider total 3n candidate locations at a time
//
void SearchBest::locationChangeV2(vector<string>* seqVec, int ns, int nc, int iaNum)
{
    // Do the process for each inter-anchor

	int nCol = (int)seqVec->at(0).length();
	string bitMap(nCol,'U');
	bool gapNotStarted = true;

    int seqIndex = Util::getRoundRobinSeqNum();
    //
    // Make possible sequences locations
    // 
	for(int i=0;i<nSeq;i++)
	{
        if (i == seqIndex) continue;

		for(int j=0;j<nCol;j++){
			if(seqVec->at(i).at(j) == '-'){
				if(gapNotStarted){
					bitMap.replace(j,1,"G");
					gapNotStarted= false;
				}
			}else{
				gapNotStarted = true;

                if (j > 0 && seqVec->at(i).at(j - 1) == '-')
                    bitMap.replace(j, 1, "G");
			}
		}
	}

    string line = seqVec->at(seqIndex);
    SeqGen sg(bitMap, line, seqIndex);
    vector<SeqInfo> sInfoVec = sg.approxCombGen(numShift, tInterAnchor, iaNum);

    int savedBestIndex = -1;
    double savedBestScore = m_subBestScore;
    vector<int> savedBAIndexVec;
    vector<BestAnnotation> savedBAVec;

    for(int i = 0; i < sInfoVec.size(); i++)
    {
        SeqInfo sInfo = sInfoVec.at(i);
        string selectedSeq = sInfo.getSeq();

        // find BestAnnotation index which have to be recalculated
        double subScore = 0.0;
        vector<int> baIndexVec = getOverlapBA(&m_subBestAnnVec, sInfo.getStartIndexOfChange(), sInfo.getEndIndexOfChange(), &subScore);
        if (baIndexVec.size() == 0) continue;

        int sIndex = baIndexVec.at(0);
        int eIndex = baIndexVec.at(baIndexVec.size() - 1);

        int sColIndex = m_subBestAnnVec.at(sIndex).getStartColIndex();
        int eColIndex = m_subBestAnnVec.at(eIndex).getEndColIndex();

        // cut string from sColIndex to eColIndex
        int numColumn = eColIndex - sColIndex + 1;
        vector<string> strVec;
        for (int s = 1; s <= nSeq; s++)
        {
            if (s - 1 == seqIndex)
            {
                strVec.push_back(selectedSeq.substr(sColIndex, numColumn));
            } // end of if
            else
            {
                strVec.push_back(seqVec->at(s - 1).substr(sColIndex, numColumn));
            } // end of else
        } // end of for

        if(sanityCheck(&strVec))
	    {
            BoundaryChunk bc(nSeq, &strVec);
            vector<BestAnnotation> ba = findBestAnnotationHybrid(&bc, numColumn, sColIndex);

            double tempScore = 0.0; 
			for(int k=0;k < (int)ba.size();k++)
			{
				tempScore += ba.at(k).getScore();
			} // end of for int k
            tempScore += subScore;
            // score check
            if (tempScore > savedBestScore)
            {
                m_bChangedScore = true;
                savedBestIndex = i;
                savedBestScore = tempScore;
                savedBAIndexVec = baIndexVec;
                savedBAVec = ba;
            } // end of if
        } // end of if
    } // end of for

    // Save selected best chunk to the original data structure
    if (savedBestIndex >= 0)
    {
        SeqInfo sInfo = sInfoVec.at(savedBestIndex);
        m_subBestScore = savedBestScore;

        // copy new sequence
        seqVec->at(seqIndex) = sInfo.getSeq();
        // copy BestAnnotation
        m_subBestAnnVec.insert(m_subBestAnnVec.begin() + savedBAIndexVec.at(0), savedBAVec.begin(), savedBAVec.end());
        // remove old BestAnnotation
        vector<BestAnnotation>::iterator sIter = m_subBestAnnVec.begin();
        sIter += (savedBAIndexVec.at(0) + savedBAVec.size());
        vector<BestAnnotation>::iterator eIter = sIter;
        eIter += (savedBAIndexVec.size());
        m_subBestAnnVec.erase(sIter, eIter);
    } // end of if
}

bool SearchBest::sanityCheck(vector<string>* seqVec)
{
	string palette(nSeq,'G');
	int numCol = (int)seqVec->at(0).length();

	for(int j=0; j < numCol; j++)
	{
		string tempPalette(nSeq,'U');

		for(int i=0; i < nSeq; i++)
		{
			if((seqVec->at(i)).at(j) == '-'){
				tempPalette.replace(i,1,"G");
			}	
		}

		if(palette.compare(tempPalette) == 0){
			return false;
		}
	}	
	return true;	
}

void SearchBest::reestimateParam()
{
    constMut = 0.0;
    constIns = 0.0;
    constDel = 0.0;

    // estimate constMat
    double sumMut = 0.0;
    double sumIns = 0.0;
    double sumDel = 0.0;

    double matN = 0.0;
    double mutN = 0.0;
    double insN = 0.0;
    double delN = 0.0;

    // key: branch number, value: vector of number of insertion and deletion
    map<int, vector<int> > brIndelMap;
    vector<int>* ingroupSeqNumVec = tInterAnchor->getIngroupSeqNumVec();
    for (int i = 0; i < ingroupSeqNumVec->size(); i++)
    {
        int brNum = tInterAnchor->getBranchNumForSeq(ingroupSeqNumVec->at(i));
        vector<int> tmpVec;
        brIndelMap[brNum] = tmpVec;
    } // end of for
    
	// calculate sum
    map<int, vector<double> > prMap;
	for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
	{
		vector<double> numVec = branchSummary[bIndex]; //tbMap[bIndex];
        double numMat = numVec.at(0);
		double numMut = numVec.at(1);
		double numIns = numVec.at(2);
		double numDel = numVec.at(3);
        double numDelLen = numVec.at(4);

        // save the indel count for parameter estimation
        map<int, vector<int> >::iterator tmpIter;
        tmpIter = brIndelMap.find(bIndex);
        if (tmpIter != brIndelMap.end())
        {
            (tmpIter->second).push_back((int)numIns);
            (tmpIter->second).push_back((int)numDel);
        } // end of if
            numMat += m_anchorVec.at(0).length();

        double numNonIns = numMat + numMut + 1 + numDel - numIns;
        double numNonDel = numMat + numMut;

        double prMut = 0.0;
		double prIns = numIns / (numIns + numNonIns);
		double prDel = numDel / (numDel + numNonDel);

		vector<double> prVec;
		prVec.push_back(prMut);
		prVec.push_back(prIns);
		prVec.push_back(prDel);
		prMap[bIndex] = prVec;
	} // end of for bIndex

	for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
	{
		vector<double> prVec = prMap[bIndex];
		double prMut = prVec.at(0);
		double prIns = prVec.at(1);
		double prDel = prVec.at(2);

		sumMut += (tInterAnchor->getBranchLenAt(bIndex) * prMut);
		sumIns += (tInterAnchor->getBranchLenAt(bIndex) * prIns);
		sumDel += (tInterAnchor->getBranchLenAt(bIndex) * prDel);
	} // end of for
	constMut = sumMut / tInterAnchor->getSumOfLenSquare();
    
    // Calculate new constIns and constDel values
    int totalInsNum = 0;
    int totalDelNum = 0;
    double totalIndelRate = 0.0;
    map<int, vector<int> >::iterator tmpIter;
    for (tmpIter = brIndelMap.begin(); tmpIter != brIndelMap.end(); tmpIter++)
    {
        int brNum = tmpIter->first;
        double brLen = tInterAnchor->getBranchLenAt(brNum);
        vector<int> tmpIndelVec = tmpIter->second;
        int tmpInsNum = tmpIndelVec.at(0);
        int tmpDelNum = tmpIndelVec.at(1);
        
        totalInsNum += tmpInsNum;
        totalDelNum += tmpDelNum;
        
        int parentSeqLen = parentSeqLenSummary[brNum];
        parentSeqLen += tInterAnchor->getAnchorSeqLen();
        
        double tmpIndelRate = (double)(tmpInsNum + tmpDelNum) / (double)parentSeqLen / brLen;
        totalIndelRate += tmpIndelRate;
    } // end of for
    
    totalIndelRate /= (brIndelMap.size());  // Average indel rate
    if (totalInsNum != 0) 
    {
        constIns = totalIndelRate / (1.0 + (double)totalDelNum / (double)totalInsNum);
        constDel = constIns * (double)totalDelNum / (double)totalInsNum;
    } // end of if
    else
    {
        constIns = 0.0; //totalIndelRate / (1 + totalDelNum / totalInsNum);
        constDel = totalIndelRate; //constIns * totalDelNum / totalInsNum;
    } // end of else
    
    // calculate indel length distribution parameter
        if (lenDist == Param::LDIST_PS)
    {
        insLenAvg = delLenAvg = 0.0;
        int numIndel = 0;
        int numIns = 0;
        int numDel = 0;
        for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
        {
            vector<int> insLenVec = insLengSummary[bIndex];
            numIns += insLenVec.size();
            for (int i = 0; i < (int)insLenVec.size(); i++) insLenAvg += insLenVec.at(i);

            vector<int> delLenVec = delLengSummary[bIndex];
            numDel += delLenVec.size();
            for (int i = 0; i < (int)delLenVec.size(); i++) delLenAvg += delLenVec.at(i);
        } // end of for

        if (diffLenDist == false)
        {
            double lenAvg = insLenAvg + delLenAvg;
            if (numIns + numDel != 0) lenAvg = lenAvg / (numIns + numDel);
            insLenAvg = delLenAvg = lenAvg;
        } // end of if
        else
        {
            if (numIns != 0) insLenAvg /= numIns;
            if (numDel != 0) delLenAvg /= numDel;
        } // end of else
        
    } // end of if
    else if (lenDist == Param::LDIST_PL)
    {
        map<int, int> tmpLenMap;
        map<int, int> tmpInsLenMap;
        map<int, int> tmpDelLenMap;
        map<int, int>::iterator tmpIter;
        int numIns = 0;
        int numDel = 0;

        for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
        {
            vector<int> insLenVec = insLengSummary[bIndex];
            numIns += insLenVec.size();
            for (int i = 0; i < (int)insLenVec.size(); i++)
            {
                int len = insLenVec.at(i);
                tmpIter = tmpLenMap.find(len);
                if (tmpIter == tmpLenMap.end())
                {
                    tmpLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpLenMap[len])++;
                } // end of else
                tmpIter = tmpInsLenMap.find(len);
                if (tmpIter == tmpInsLenMap.end())
                {
                    tmpInsLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpInsLenMap[len])++;
                } // end of else
            } // end of for

            vector<int> delLenVec = delLengSummary[bIndex];
            numDel += delLenVec.size();
            for (int i = 0; i < (int)delLenVec.size(); i++)
            {
                int len = delLenVec.at(i);
                tmpIter = tmpLenMap.find(len);
                if (tmpIter == tmpLenMap.end())
                {
                    tmpLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpLenMap[len])++;
                } // end of else
                tmpIter = tmpDelLenMap.find(len);
                if (tmpIter == tmpDelLenMap.end())
                {
                    tmpDelLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpDelLenMap[len])++;
                } // end of else
            } // end of for
        } // end of for


        if (diffLenDist == false)
        {
            // calculate power law parameter
            // code from Dawg tool
            double sx = 0.0;
            double sx2 = 0.0;
            double sxy = 0.0;
            double sy = 0.0;
            double n = 5;
            if (tmpLenMap.size() < 5) n = tmpLenMap.size();
    
            double numgaps = 0.0;
            tmpIter = tmpLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                numgaps += tmpIter->second;
                tmpIter++;
            } // end of for
    
            tmpIter = tmpLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                double x = log((double)tmpIter->first);
                double y = log((double)tmpIter->second);
                sx += x;
                sy += y;
                sxy += x * y;
                sx2 += x * x;
                tmpIter++;
            } // end of for
    
            insLambda = -(n * sxy - sx * sy) / (n * sx2 - sx * sx);
            delLambda = insLambda;
            tmpIter = tmpLenMap.end();
            tmpIter--;
            double maxLen = tmpIter->first;
    
            insrzeta = delrzeta = 0.0;
            double d = 0.0;
                for(unsigned long u = 1;u<=(int)maxLen;++u)
                {
                        d = pow((double)u, -insLambda);
                        insrzeta += d;
                } // end of for
            delrzeta = insrzeta;

        } // end of if
        else
        {
            // For insertions
            double sx = 0.0;
            double sx2 = 0.0;
            double sxy = 0.0;
            double sy = 0.0;
            double n = 5;
            if (tmpInsLenMap.size() < 5) n = tmpInsLenMap.size();
    
            double numgaps = 0.0;
            tmpIter = tmpInsLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                numgaps += tmpIter->second;
                tmpIter++;
            } // end of for
    
            tmpIter = tmpInsLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                double x = log((double)tmpIter->first);
                double y = log((double)tmpIter->second);
                sx += x;
                sy += y;
                sxy += x * y;
                sx2 += x * x;
                tmpIter++;
            } // end of for
    
            insLambda = -(n * sxy - sx * sy) / (n * sx2 - sx * sx);
            tmpIter = tmpInsLenMap.end();
            tmpIter--;
            double maxLen = tmpIter->first;
    
            insrzeta = 0.0;
            double d = 0.0;
                for(unsigned long u = 1;u<=(int)maxLen;++u)
                {
                        d = pow((double)u, -insLambda);
                        insrzeta += d;
                } // end of for

            // For deletions
            sx = sx2 = sxy = sy = 0.0;
            n = 5;
            if (tmpDelLenMap.size() < 5) n = tmpDelLenMap.size();
    
            numgaps = 0.0;
            tmpIter = tmpDelLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                numgaps += tmpIter->second;
                tmpIter++;
            } // end of for
    
            tmpIter = tmpDelLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                double x = log((double)tmpIter->first);
                double y = log((double)tmpIter->second);
                sx += x;
                sy += y;
                sxy += x * y;
                sx2 += x * x;
                tmpIter++;
            } // end of for
    
            delLambda = -(n * sxy - sx * sy) / (n * sx2 - sx * sx);
            tmpIter = tmpDelLenMap.end();
            tmpIter--;
            maxLen = tmpIter->first;
    
            delrzeta = 0.0;
            d = 0.0;
                for(unsigned long u = 1;u<=(int)maxLen;++u)
                {
                        d = pow((double)u, -delLambda);
                        delrzeta += d;
                } // end of for
        } // end of else
    } // end of else if
    else if (lenDist == Param::LDIST_GM)
    {
        double sumIns = 0.0;
        double sumDel = 0.0;
        int numIns = 0;
        int numDel = 0;
        for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
        {
            vector<int> insLenVec = insLengSummary[bIndex];
            numIns += insLenVec.size();
            for (int i = 0; i < (int)insLenVec.size(); i++) sumIns += insLenVec.at(i);

            vector<int> delLenVec = delLengSummary[bIndex];
            numDel += delLenVec.size();
            for (int i = 0; i < (int)delLenVec.size(); i++) sumDel += delLenVec.at(i);
        } // end of for

        if (diffLenDist == false)
        {
            if (numIns + numDel != 0) insProbSuccess = 1 / ((sumIns + sumDel) / (numIns + numDel));
            delProbSuccess = insProbSuccess;
        } // end of if
        else
        {
            if (numIns != 0) insProbSuccess = 1 / (sumIns / numIns);
            if (numDel != 0) delProbSuccess = 1 / (sumDel / numDel);
        } // end of else
        
    } // end of if

#ifdef DEBUG_OUTPUT
    cerr << "Cins:" << constIns << " Cdel:" << constDel << endl;

    if (lenDist == Param::LDIST_PS)
    {
        cerr << "Indel length distribution: Poisson" << endl;
        cerr << "Ins length average: " << insLenAvg << endl;
        cerr << "Del length average: " << delLenAvg << endl;
    } // end of if
    else if (lenDist == Param::LDIST_PL)
    {
        cerr << "Indel length distribution: Power law" << endl;
        cerr << "Ins Exponent: " << insLambda << endl;
        cerr << "Del Exponent: " << delLambda << endl;
        cerr << "Ins Value of Riemann zeta function: " << insrzeta << endl;
        cerr << "Del Value of Riemann zeta function: " << delrzeta << endl; 
    } // end of else if
    else if (lenDist == Param::LDIST_GM)
    {
        cerr << "Indel length distribution: Geometric" << endl;
        cerr << "Ins Prob. Success: " << insProbSuccess << endl;
        cerr << "Del Prob. Success: " << delProbSuccess << endl;
    } // end of if

    cerr << endl;
    cerr << "Indel count difference:" << endl;
#endif

    // Estimate the parameter for F81 model
    // do for each possible pair of leaf sequences
#ifdef DEBUG_OUTPUT
    cerr << "[SearchBest: reestimateParameter]" << endl;
#endif
    m_paramU = 0.0;
    int paramCnt = 0;
    for (int i = 0; i < ingroupSeqNumVec->size() - 1; i++)
    {
        int seqNum1 = ingroupSeqNumVec->at(i);
        if (seqNum1 > nSeq) continue;
            
        for (int j = i + 1; j < ingroupSeqNumVec->size(); j++)
        {
            int seqNum2 = ingroupSeqNumVec->at(j);
            if (seqNum2 > nSeq) continue;
            
            double totalTime = 0.0; 
            // make string key
            char buff[1024];
            sprintf(buff, "%d:%d", seqNum1, seqNum2);
            string strKey(buff);

            NodeMapValue* nmValue = tInterAnchor->getNodeMapValue(strKey);
            if (nmValue == NULL) continue;

            totalTime = nmValue->getTotalTime();
#ifdef DEBUG_OUTPUT
            cerr << "Passed sequence pair: " << seqNum1 << " " << seqNum2 << " Common ancestor: " << nmValue->getCommonAncestorNum() << " Branch length: " << totalTime << endl;
#endif                
                
            // 2. Make temporary array for counting the number of substitution
            int** anchorNumArray = tInterAnchor->getSubNumArrayAnchor();
            int subNumArray[4][4];
        
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    subNumArray[i][j] = anchorNumArray[i][j];
                
            // 3. Count the number of substitution in each inter-anchor
            for (int ia = 1; ia <= tInterAnchor->getNumOfInterAnchor(); ia++)
            {
                BoundaryChunk bc = bestBChunkMap[ia];	
                string str1 = (bc.getSeqVec())->at(seqNum1 - 1);    
                string str2 = (bc.getSeqVec())->at(seqNum2 - 1);    
                
                for (int i = 0; i < str1.length(); i++)
                {
                    char ch1 = str1.at(i);
                    char ch2 = str2.at(i);
                    if (ch1 == '-' || ch2 == '-') continue;
        
                    if (ch1 == 'A' && ch2 == 'A') subNumArray[0][0]++;
                    else if (ch1 == 'A' && ch2 == 'C') subNumArray[0][1]++;
                    else if (ch1 == 'A' && ch2 == 'G') subNumArray[0][2]++;
                    else if (ch1 == 'A' && ch2 == 'T') subNumArray[0][3]++;
                    else if (ch1 == 'C' && ch2 == 'A') subNumArray[1][0]++;
                    else if (ch1 == 'C' && ch2 == 'C') subNumArray[1][1]++;
                    else if (ch1 == 'C' && ch2 == 'G') subNumArray[1][2]++;
                    else if (ch1 == 'C' && ch2 == 'T') subNumArray[1][3]++;
                    else if (ch1 == 'G' && ch2 == 'A') subNumArray[2][0]++;
                    else if (ch1 == 'G' && ch2 == 'C') subNumArray[2][1]++;
                    else if (ch1 == 'G' && ch2 == 'G') subNumArray[2][2]++;
                    else if (ch1 == 'G' && ch2 == 'T') subNumArray[2][3]++;
                    else if (ch1 == 'T' && ch2 == 'A') subNumArray[3][0]++;
                    else if (ch1 == 'T' && ch2 == 'C') subNumArray[3][1]++;
                    else if (ch1 == 'T' && ch2 == 'G') subNumArray[3][2]++;
                    else if (ch1 == 'T' && ch2 == 'T') subNumArray[3][3]++;
                } // end of for
            } // end of for

            double term1 = 0.0;
            double term2 = 0.0;
            double term3 = 0.0;
            for (int i = 0; i < 4; i++)
            {
                double freq = m_freqA;
                if (i == 0) freq = m_freqA;
                else if (i == 1) freq = m_freqC;
                else if (i == 2) freq = m_freqG;
                else if (i == 3) freq = m_freqT;
        
                term1 += subNumArray[i][i] * (1 - freq);
        
                for (int j = 0; j < 4; j++)
                {
                    if (i == j) continue;
        
                    term2 += subNumArray[i][j] * freq;
                    term3 += subNumArray[i][j] * (1 - freq);
                } // end of for
            } // end of for

            m_paramU += -(log((term1 - term2) / (term1 + term3)) / totalTime);

            paramCnt++;
        } // end of for
    } // end of for

    m_paramU /= paramCnt;
#ifdef DEBUG_OUTPUT
    cerr << "F81 Model parameter:" << m_paramU << endl;
    cerr << endl;
#endif
}

void SearchBest::dumpAlign()
{
}

void SearchBest::copyInterAnchor()
{
	int numOfIA = tInterAnchor->getNumOfInterAnchor();
	for(int i = 0; i < numOfIA; i++)
	{
		InterAnchor* ia = tInterAnchor->getInterAnchorAt(i); 
		vector<string> seqVec; 
		for(int j=0; j < nSeq; j++)
		{
			string line = ia->getSequenceP()->at(j);
			seqVec.push_back(line);
		}
        BoundaryChunk bc(nSeq, seqVec);
        bestBChunkMap[i + 1] = bc;
	}
}

// Annotate dependent blocks together
vector<BestAnnotation> SearchBest::findBestAnnotation(BoundaryChunk* bc, int numCol, int startIndex)
{
    // Find set of chunks in the current inter-anchor
    int sIndex = -1;
    int eIndex = -1;
    int i = 0;
    vector<int> chunkColPosVec;
    vector<BestAnnotation> bestAnnVec;

    int treeCnt = 0;
    bool bCont = false;
    int bEndPos = -1;
    int bStartPos = -1;
    while (i < numCol)
    {
        int bIndex = bc->getIndexOfBoundaryStartAt(i);
        if (bIndex != -1)
        {
            if (bCont == false)
            {
                // reset variables
                bEndPos = -1;
                bStartPos = i;
            } // end of if

            // store start index of column
            chunkColPosVec.push_back(i);

            // check whether this chunk column is continued or not
            BoundaryItem* bi = bc->getBoundaryItem(bIndex);
            
            bCont = false;
            for (int j = 0; j < nSeq; j++)
            {
                BoundaryItem* bi = bc->getBoundaryItem(bIndex + j);
                if (j == 0) bEndPos = bi->getEnd();

                if (bi->isContinued())
                {
                    bCont = true;
                    break;
                } // end of if
            } // end of for j
            
            if (bCont == false)
            {
                int bbStart = 0;
                int bbEnd = 0;
                map<int, vector<int> > seqMap;
                for (int seqIndex = 1; seqIndex <= nSeq; seqIndex++)
                {
                    vector<int> seqVec;
                    for (int j = 0; j < (int)chunkColPosVec.size(); j++)
                    {   
                        int pos = chunkColPosVec.at(j);
                        int bIndex = bc->getIndexOfBoundaryStartAt(pos);
                        
                        BoundaryItem* bi = bc->getBoundaryItem(bIndex + seqIndex - 1);
                        if (bi->getIsGap() == true) seqVec.push_back(-(bIndex + 1));
                        else seqVec.push_back(bIndex + 1);

                        if (seqIndex == 1 && j == 0) bbStart = bi->getStart() + 1;
                        if (seqIndex == 1 && j == (chunkColPosVec.size() - 1)) bbEnd = bi->getEnd() + 1;
                    } // end of for

                    seqMap[seqIndex] = seqVec;
                } // end of for
#ifdef DEBUG_OUTPUT
cerr << "Number of dependent blocks:" << chunkColPosVec.size() << " (" << bbStart << " - " << bbEnd << ")" << endl;
#endif
                // call annotation function
                treeCnt++;

                BestAnnotation bestAnn = aux_findBestAnnotation(bc, &seqMap, bStartPos);
                
                bestAnn.setStartColIndex(bStartPos + startIndex);
                bestAnn.setEndColIndex(bEndPos + startIndex);
                bestAnnVec.push_back(bestAnn);
                // reset vector
                chunkColPosVec.clear();
                vector<int>().swap(chunkColPosVec);
            } // end of else

            i = bEndPos + 1;
        } // end of if
        else
        {
            i++;
        } // end of else
    } // end of while
    

    return bestAnnVec;

}

// Annotate all blocks independently but merge the annotation result -> splitted one indels
vector<BestAnnotation> SearchBest::findBestAnnotationV2(BoundaryChunk* bc, int numCol, int startIndex)
{
    int sIndex = -1;
    int eIndex = -1;
    int i = 0;
    vector<int> chunkColPosVec;
    vector<BestAnnotation> bestAnnVec;

    int treeCnt = 0;
    bool bCont = false;
    int bEndPos = -1;
    int bStartPos = -1;
    while (i < numCol)
    {
        int bIndex = bc->getIndexOfBoundaryStartAt(i);
        if (bIndex != -1)
        {
            if (bCont == false)
            {
                // reset variables
                bEndPos = -1;
                bStartPos = i;
            } // end of if

            // store start index of column
            chunkColPosVec.push_back(i);
            // check whether this chunk column is continued or not
            BoundaryItem* bi = bc->getBoundaryItem(bIndex);
            bCont = false;
            
            for (int j = 0; j < nSeq; j++)
            {
                BoundaryItem* bi = bc->getBoundaryItem(bIndex + j);
                if (j == 0) bEndPos = bi->getEnd();

                if (bi->isContinued())
                {
                    bCont = true;
                    break;
                } // end of if
            } // end of for j
            
            if (bCont == false)
            {
                for (int bi = 1; bi <= tInterAnchor->getNumBranch(); bi++) m_tmpSeqMap[bi] = "";
            
                vector<BestAnnotation> tmpBAVec;
                for (int ci = 0; ci < (int)chunkColPosVec.size(); ci++)
                {
                    map<int, vector<int> > seqMap;
                    int pos = chunkColPosVec.at(ci);
                    int bIndex = bc->getIndexOfBoundaryStartAt(pos);

                    BoundaryItem* tmpbi = bc->getBoundaryItem(bIndex);    
                    bStartPos = tmpbi->getStart();
                    bEndPos = tmpbi->getEnd();

                    for (int seqIndex = 1; seqIndex <= nSeq; seqIndex++)
                    {
                        vector<int> seqVec;
                        BoundaryItem* bi = bc->getBoundaryItem(bIndex + seqIndex - 1);
                        if (bi->getIsGap() == true) seqVec.push_back(-(bIndex + 1));
                        else seqVec.push_back(bIndex + 1);

                        seqMap[seqIndex] = seqVec;
                    } // end of for (seqIndex)

                    // call annotation function
                    BestAnnotation bestAnn = aux_findBestAnnotation(bc, &seqMap, bStartPos);
                    bestAnn.setStartColIndex(bStartPos + startIndex);
                    bestAnn.setEndColIndex(bEndPos + startIndex);

                    if (chunkColPosVec.size() == 1) bestAnnVec.push_back(bestAnn);
                    else tmpBAVec.push_back(bestAnn);
                } // end of for

                if (chunkColPosVec.size() > 1)
                {
                    double score = 0;
                    int startColIndex = 0;
                    int endColIndex = 0;
                    BranchInfoSet finalBInfoSet;
                    int baFirstStartIndex = 0;
                    for (int bi = 0; bi < tmpBAVec.size(); bi++)
                    {
                        BestAnnotation ba = tmpBAVec.at(bi);
                        int baStartIndex = ba.getStartColIndex() - startIndex;
                        int baEndIndex = ba.getEndColIndex() - startIndex;
                        score += ba.getScore();
                        
                        if (bi == 0) baFirstStartIndex = baStartIndex;

                        BranchInfoSet* bInfoSet = ba.getBranchInfoSet();
                        finalBInfoSet.addParentSeqLenMap(bInfoSet->getParentSeqLenMap());

                        if (bi == 0) startColIndex = ba.getStartColIndex();
                        if (bi == (tmpBAVec.size() - 1)) endColIndex = ba.getEndColIndex();

                        for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
                        {
                            BranchInfo* bInfo = bInfoSet->getBranchInfoAt(bIndex);
                            BranchInfo* finalBInfo = finalBInfoSet.getBranchInfoAt(bIndex);
                            vector<AnnInfo>* cInfoVec = bInfo->getAnnInfoVec();

                            if (finalBInfo == NULL)
                            {
                                if (cInfoVec->size() != 0)
                                {
                                    BranchInfo newBInfo(bInfo);
                                    finalBInfoSet.addBranchInfo(bIndex, newBInfo);
                                } // end of if
                                else
                                {
                                    BranchInfo newBInfo;
                                    finalBInfoSet.addBranchInfo(bIndex, newBInfo);
                                } // end of else
                            } // end of if (finalBInfo)
                            else if (finalBInfo != NULL && cInfoVec->size() == 0)
                            {
                                ;
                            } // end of else if
                            else
                            {
                                // append mutation information
                                finalBInfo->addMisMatch(bInfo->getNumOfMisMatch());
                                finalBInfo->addMatch(bInfo->getNumOfMatch());

                                vector<AnnInfo>* aInfoVec = finalBInfo->getAnnInfoVec();

                                if (aInfoVec->size() == 0)
                                {
                                    AnnInfo cInfo = cInfoVec->at(0);
                                    cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                    aInfoVec->push_back(cInfo);
                                } // end of if
                                else
                                {
                                    AnnInfo aInfo = aInfoVec->at(aInfoVec->size() - 1);
                                    AnnInfo cInfo = cInfoVec->at(0);
                                    int aEndIndex = aInfo.getEndIndex();
                                    int cStartIndex = cInfo.getStartIndex() + baStartIndex - baFirstStartIndex;
                                    if (aEndIndex + 1 == cStartIndex)
                                    {
                                        // adjacent gaps
                                        if (aInfo.getAnn() == cInfo.getAnn())
                                        {
                                            // equal annotation -> append to the existing one
                                            aInfo.setEndIndex(cInfo.getEndIndex() + baStartIndex - baFirstStartIndex);
                                            aInfo.setLength(aInfo.getLength() + cInfo.getLength());
                                            aInfoVec->operator[](aInfoVec->size() - 1) = aInfo;
                                        } // end of if (aInfo)
                                        else
                                        {
                                            // unequal annotation -> insert new one
                                            cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                            aInfoVec->push_back(cInfo);
                                        } // end of else
                                    } // end of if (aInfo)
                                    else
                                    {
                                        string tmpSeqStr = m_tmpSeqMap[bIndex];
                                        if (aInfo.getAnn() == PhyloTreeNode::DELETION && aInfo.getAnn() == cInfo.getAnn())
                                        {
                                            bool bFoundNonGap = false;
                                            for (int afi = aInfo.getEndIndex() + 1; afi < cInfo.getStartIndex() + baStartIndex - baFirstStartIndex; afi++)
                                            {
                                                if (tmpSeqStr.at(afi) != '-')
                                                {
                                                    bFoundNonGap = true;
                                                    break;
                                                } // end of if
                                            } // end of for
                                            
                                            if (bFoundNonGap == false)
                                            {
                                                // splitted deletion -> append to the existing one
                                                aInfo.setEndIndex(cInfo.getEndIndex() + baStartIndex - baFirstStartIndex);
                                                aInfo.setLength(aInfo.getLength() + cInfo.getLength());
                                                aInfoVec->operator[](aInfoVec->size() - 1) = aInfo;
                                            } // end of if
                                            else
                                            {
                                                cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                                aInfoVec->push_back(cInfo);
                                            } // end of else
                                        } // end of if
                                        else
                                        {
                                            cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                            aInfoVec->push_back(cInfo);
                                        } // end of else
                                    } // end of else
                                } // end of else
                            } // end of else

                        } // end of for (bIndex)
                    } // end of for (bi)

                    for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
                    {
                        BranchInfo* finalBInfo = finalBInfoSet.getBranchInfoAt(bIndex);
                        vector<AnnInfo>* annVec = finalBInfo->getAnnInfoVec();
                        for (int ai = 0; ai < annVec->size(); ai++)
                        {
                            AnnInfo aInfo = annVec->at(ai);
                            if (aInfo.getAnn() == PhyloTreeNode::INSERTION)
                                finalBInfo->addInsertion(aInfo.getLength());
                            else if (aInfo.getAnn() == PhyloTreeNode::DELETION)
                                finalBInfo->addDeletion(aInfo.getLength());
                        } // end of for
                    } // end of for
                        
                    BestAnnotation finalBA(score, finalBInfoSet);
                    finalBA.setStartColIndex(startColIndex);
                    finalBA.setEndColIndex(endColIndex);
                    bestAnnVec.push_back(finalBA);

                    // clear contents
                    tmpBAVec.clear();
                    vector<BestAnnotation>().swap(tmpBAVec);
                } // end of if
                
                // reset vector
                chunkColPosVec.clear();
                vector<int>().swap(chunkColPosVec);
             } // end of if   
            i = bEndPos + 1;
        } // end of if
        else
        {
            i++;
        } // end of else
    } // end of while
    

    return bestAnnVec;

}

// Number of dependent blocks <= 10 -> Annotate dependent blocks together
// Number of dependent blocks > 10 -> Annotate blocks independently
vector<BestAnnotation> SearchBest::findBestAnnotationHybrid(BoundaryChunk* bc, int numCol, int startIndex)
{
    int sIndex = -1;
    int eIndex = -1;
    int i = 0;
    vector<int> chunkColPosVec;
    vector<BestAnnotation> bestAnnVec;
    multimap<int, int> numGappedSeqMap;
    
    int treeCnt = 0;
    bool bCont = false;
    int bEndPos = -1;
    int bStartPos = -1;
    while (i < numCol)
    {
        int bIndex = bc->getIndexOfBoundaryStartAt(i);
        if (bIndex != -1)
        {
            if (bCont == false)
            {
                // reset variables
                bEndPos = -1;
                bStartPos = i;
            } // end of if

            // store start index of column
            chunkColPosVec.push_back(i);
            // check whether this chunk column is continued or not
            BoundaryItem* bi = bc->getBoundaryItem(bIndex);
            bCont = false;
            
            int numGapped = 0;
            for (int j = 0; j < nSeq; j++)
            {
                BoundaryItem* bi = bc->getBoundaryItem(bIndex + j);
                if (j == 0) bEndPos = bi->getEnd();
                if (bi->isContinued()) bCont = true;
                if (bi->getIsGap()) numGapped++;
            } // end of for j
            numGappedSeqMap.insert(map<int, int>::value_type(numGapped, chunkColPosVec.size() - 1));
            
            if (bCont == false)
            {
#ifdef DEBUG_OUTPUT
cerr << "Number of dependent blocks:" << chunkColPosVec.size() << endl;
#endif
                for (int bi = 1; bi <= tInterAnchor->getNumBranch(); bi++) m_tmpSeqMap[bi] = "";
            
                if (chunkColPosVec.size() <= MAX_DEPT_BLOCKS)
                {
                    int bbStart = 0;
                    int bbEnd = 0;
                    map<int, vector<int> > seqMap;
                    for (int seqIndex = 1; seqIndex <= nSeq; seqIndex++)
                    {
                        vector<int> seqVec;
                        for (int j = 0; j < (int)chunkColPosVec.size(); j++)
                        {   
                            int pos = chunkColPosVec.at(j);
                            int bIndex = bc->getIndexOfBoundaryStartAt(pos);
                            
                            BoundaryItem* bi = bc->getBoundaryItem(bIndex + seqIndex - 1);
                            if (bi->getIsGap() == true) seqVec.push_back(-(bIndex + 1));
                            else seqVec.push_back(bIndex + 1);
    
                            if (seqIndex == 1 && j == 0) bbStart = bi->getStart() + 1;
                            if (seqIndex == 1 && j == (chunkColPosVec.size() - 1)) bbEnd = bi->getEnd() + 1;
                        } // end of for
    
                        seqMap[seqIndex] = seqVec;
                    } // end of for
                   
                    // call annotation function
                    treeCnt++;
    
                    BestAnnotation bestAnn = aux_findBestAnnotation(bc, &seqMap, bStartPos);
                    
                    bestAnn.setStartColIndex(bStartPos + startIndex);
                    bestAnn.setEndColIndex(bEndPos + startIndex);
                    bestAnnVec.push_back(bestAnn);
                } // end of if
                else
                {
                    // Split dependent blocks by MAX_DEPT_BLOCKS
                    string strMark(chunkColPosVec.size(), 'N'); // N means non-split, S means split position
                    int numBorders = (int)floor(chunkColPosVec.size() / MAX_DEPT_BLOCKS);
                    vector<int> splitPoints;
                    map<int, int>::iterator tmpIter;
                    for (tmpIter = numGappedSeqMap.begin(); tmpIter != numGappedSeqMap.end(); tmpIter++)
                    {
                        int numGappedSeq = tmpIter->first;
                        int blockIndex = tmpIter->second;
                        if (blockIndex == 0 || blockIndex == chunkColPosVec.size() - 1) continue;

                        int fDel = strMark.rfind('S', blockIndex);
                        int bDel = strMark.find('S', blockIndex);
                        if (fDel != blockIndex - 1 && bDel != blockIndex + 1)
                        {
                            splitPoints.push_back(blockIndex);
                            strMark.replace(blockIndex, 1, 1, 'S');
                        } // end of if

                        // termination check
                        int prevMPos = -1;
                        bool bDone = true;
                        for (int smi = 0; smi < strMark.length(); smi++)
                        {
                            char ch = strMark.at(smi);
                            if (ch == 'N' && smi != strMark.length() - 1) continue;

                            if (smi - prevMPos > MAX_DEPT_BLOCKS) 
                            {
                                bDone = false;
                                break;
                            } // end of if
                            prevMPos = smi;
                        } // end of for
                        
                        if (bDone == true) break;
                    } // end of for
                    sort(splitPoints.begin(), splitPoints.end());
    
                    vector<BestAnnotation> tmpBAVec;
                    int pspIndex = -1;
                    for (int spi = 0; spi <= splitPoints.size(); spi++)
                    {
                        int spIndex = chunkColPosVec.size() - 1;
                        if (spi < splitPoints.size()) spIndex = splitPoints.at(spi);
                        
                        int bbStart = 0;
                        int bbEnd = 0;
                        map<int, vector<int> > seqMap;
                        for (int seqIndex = 1; seqIndex <= nSeq; seqIndex++)
                        {
                            vector<int> seqVec;
                            for (int j = pspIndex + 1; j <= spIndex; j++)
                            {   
                                int pos = chunkColPosVec.at(j);
                                int bIndex = bc->getIndexOfBoundaryStartAt(pos);
                                BoundaryItem* bi = bc->getBoundaryItem(bIndex + seqIndex - 1);
                                if (bi->getIsGap() == true) seqVec.push_back(-(bIndex + 1));
                                else seqVec.push_back(bIndex + 1);
        
                                if (seqIndex == 1 && j == (pspIndex + 1)) bbStart = bi->getStart();
                                if (seqIndex == 1 && j == (spIndex)) bbEnd = bi->getEnd();
                            } // end of for
        
                            seqMap[seqIndex] = seqVec;
                        } // end of for
                        pspIndex = spIndex;

                        BestAnnotation bestAnn = aux_findBestAnnotation(bc, &seqMap, bbStart);
                        bestAnn.setStartColIndex(bbStart + startIndex);
                        bestAnn.setEndColIndex(bbEnd + startIndex);
    
                        tmpBAVec.push_back(bestAnn);
                    } // end of for (spi)
                
                    if (chunkColPosVec.size() > 1)
                    {
                        double score = 0;
                        int startColIndex = 0;
                        int endColIndex = 0;
                        BranchInfoSet finalBInfoSet;
                        int baFirstStartIndex = 0;
                        for (int bi = 0; bi < tmpBAVec.size(); bi++)
                        {
                            BestAnnotation ba = tmpBAVec.at(bi);
                            int baStartIndex = ba.getStartColIndex() - startIndex;
                            int baEndIndex = ba.getEndColIndex() - startIndex;
                            score += ba.getScore();
                            
                            if (bi == 0) baFirstStartIndex = baStartIndex;
    
                            BranchInfoSet* bInfoSet = ba.getBranchInfoSet();
                            finalBInfoSet.addParentSeqLenMap(bInfoSet->getParentSeqLenMap());
    
                            if (bi == 0) startColIndex = ba.getStartColIndex();
                            if (bi == (tmpBAVec.size() - 1)) endColIndex = ba.getEndColIndex();
    
                            for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
                            {
                                BranchInfo* bInfo = bInfoSet->getBranchInfoAt(bIndex);
                                BranchInfo* finalBInfo = finalBInfoSet.getBranchInfoAt(bIndex);
                                vector<AnnInfo>* cInfoVec = bInfo->getAnnInfoVec();
    
                                if (finalBInfo == NULL)
                                {
                                    if (cInfoVec->size() != 0)
                                    {
                                        BranchInfo newBInfo(bInfo);
                                        finalBInfoSet.addBranchInfo(bIndex, newBInfo);
                                    } // end of if
                                    else
                                    {
                                        BranchInfo newBInfo;
                                        finalBInfoSet.addBranchInfo(bIndex, newBInfo);
                                    } // end of else
                                } // end of if (finalBInfo)
                                else if (finalBInfo != NULL && cInfoVec->size() == 0)
                                {
                                    ;
                                } // end of else if
                                else
                                {
                                    // append mutation information
                                    finalBInfo->addMisMatch(bInfo->getNumOfMisMatch());
                                    finalBInfo->addMatch(bInfo->getNumOfMatch());
    
                                    vector<AnnInfo>* aInfoVec = finalBInfo->getAnnInfoVec();
    
                                    if (aInfoVec->size() == 0)
                                    {
                                        for (int cvi = 0; cvi < cInfoVec->size(); cvi++)
                                        {
                                            AnnInfo cInfo = cInfoVec->at(cvi);
                                            cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                            aInfoVec->push_back(cInfo);
                                        } // end of for (cvi)
                                    } // end of if
                                    else
                                    {
                                        AnnInfo aInfo = aInfoVec->at(aInfoVec->size() - 1);
                                        AnnInfo cInfo = cInfoVec->at(0);
                                        int aEndIndex = aInfo.getEndIndex();
                                        int cStartIndex = cInfo.getStartIndex() + baStartIndex - baFirstStartIndex;
                                        if (aEndIndex + 1 == cStartIndex)
                                        {
                                            // adjacent gaps
                                            if (aInfo.getAnn() == cInfo.getAnn())
                                            {
                                                // equal annotation -> append to the existing one
                                                aInfo.setEndIndex(cInfo.getEndIndex() + baStartIndex - baFirstStartIndex);
                                                aInfo.setLength(aInfo.getLength() + cInfo.getLength());
                                                aInfoVec->operator[](aInfoVec->size() - 1) = aInfo;
                                            } // end of if (aInfo)
                                            else
                                            {
                                                // unequal annotation -> insert new one
                                                cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                                aInfoVec->push_back(cInfo);
                                             } // end of else
                                        } // end of if (aInfo)
                                        else
                                        {
                                            string tmpSeqStr = m_tmpSeqMap[bIndex];
                                            if (aInfo.getAnn() == PhyloTreeNode::DELETION && aInfo.getAnn() == cInfo.getAnn())
                                            {
                                                bool bFoundNonGap = false;
                                                for (int afi = aInfo.getEndIndex() + 1; afi < cInfo.getStartIndex() + baStartIndex - baFirstStartIndex; afi++)
                                                {
                                                    if (tmpSeqStr.at(afi) != '-')
                                                    {
                                                        bFoundNonGap = true;
                                                        break;
                                                    } // end of if
                                                } // end of for
                                                
                                                if (bFoundNonGap == false)
                                                {
                                                    // splitted deletion -> append to the existing one
                                                    aInfo.setEndIndex(cInfo.getEndIndex() + baStartIndex - baFirstStartIndex);
                                                    aInfo.setLength(aInfo.getLength() + cInfo.getLength());
                                                    aInfoVec->operator[](aInfoVec->size() - 1) = aInfo;
                                                } // end of if
                                                else
                                                {
                                                    cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                                    aInfoVec->push_back(cInfo);
                                                } // end of else
                                            } // end of if
                                            else
                                            {
                                                cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                                aInfoVec->push_back(cInfo);
                                            } // end of else
                                        } // end of else

                                        // append remaining AppInfo
                                        for (int cvi = 1; cvi < cInfoVec->size(); cvi++)
                                        {
                                            AnnInfo cInfo = cInfoVec->at(cvi);
                                            cInfo.addOffset(baStartIndex - baFirstStartIndex);
                                            aInfoVec->push_back(cInfo);
                                        } // end of for (cvi)
                                    } // end of else
                                } // end of else
                            } // end of for (bIndex)
                        } // end of for (bi)
    
                        for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
                        {
                            BranchInfo* finalBInfo = finalBInfoSet.getBranchInfoAt(bIndex);
                            vector<AnnInfo>* annVec = finalBInfo->getAnnInfoVec();
                            for (int ai = 0; ai < annVec->size(); ai++)
                            {
                                AnnInfo aInfo = annVec->at(ai);
                                if (aInfo.getAnn() == PhyloTreeNode::INSERTION)
                                    finalBInfo->addInsertion(aInfo.getLength());
                                else if (aInfo.getAnn() == PhyloTreeNode::DELETION)
                                    finalBInfo->addDeletion(aInfo.getLength());
                            } // end of for
                        } // end of for
                            
                        BestAnnotation finalBA(score, finalBInfoSet);
                        finalBA.setStartColIndex(startColIndex);
                        finalBA.setEndColIndex(endColIndex);
                        bestAnnVec.push_back(finalBA);
    
                        // clear contents
                        tmpBAVec.clear();
                        vector<BestAnnotation>().swap(tmpBAVec);
                    } // end of if
                } // end of else

                // reset vector
                chunkColPosVec.clear();
                vector<int>().swap(chunkColPosVec);
                numGappedSeqMap.clear();
                ////////////////////////////////////////////////////////////
             } // end of if   
            i = bEndPos + 1;
        } // end of if
        else
        {
            i++;
        } // end of else
    } // end of while
    

    return bestAnnVec;

}

void SearchBest::checkAlignment(BoundaryChunk* bc, int numCol, int startIndex)
{
    // Find set of chunks in the current inter-anchor
    int sIndex = -1;
    int eIndex = -1;
    int i = 0;
    vector<int> chunkColPosVec;
    vector<BestAnnotation> bestAnnVec;

    int treeCnt = 0;
    bool bCont = false;
    int bEndPos = -1;
    int bStartPos = -1;
    while (i < numCol)
    {
        int bIndex = bc->getIndexOfBoundaryStartAt(i);
        if (bIndex != -1)
        {
            if (bCont == false)
            {
                // reset variables
                bEndPos = -1;
                bStartPos = i;
            } // end of if

            // store start index of column
            chunkColPosVec.push_back(i);

            // check whether this chunk column is continued or not
            BoundaryItem* bi = bc->getBoundaryItem(bIndex);
            
            bCont = false;
            for (int j = 0; j < nSeq; j++)
            {
                BoundaryItem* bi = bc->getBoundaryItem(bIndex + j);
                if (j == 0) bEndPos = bi->getEnd();

                if (bi->isContinued())
                {
                    bCont = true;
                    break;
                } // end of if
            } // end of for j
            
            if (bCont == false)
            {
               if ((int)chunkColPosVec.size() >= 10) m_bAbnormalAlignment = true;
                // call annotation function
                treeCnt++;

                // reset vector
                chunkColPosVec.clear();
                vector<int>().swap(chunkColPosVec);
            } // end of else

            i = bEndPos + 1;
        } // end of if
        else
        {
            i++;
        } // end of else
    } // end of while
}

BestAnnotation SearchBest::aux_findBestAnnotation(BoundaryChunk* bc, map<int, vector<int> >* seqMap, int startIndex)
{
    PhyloTreeNodeEx* rootNode = makeTree(bc, seqMap);        

    int tmpp;
    int branchIndex = 1 ;
    computeSubstScoreStep1(rootNode, &branchIndex, bc);
    
    int tmpSize = rootNode->getSubstInfoVecSize();
    vector<double>* scrVec = new vector<double>;
    for (int i = 0; i < tmpSize; i++) scrVec->push_back(0.0);
    computeSubstScoreStep2(rootNode, scrVec);
   
    rootNode->setSubstScore(scrVec);
    delete scrVec;

    // enumerate all possible candidate anntations
    branchIndex = 1;
    enumCandidateAnnotation(rootNode, &branchIndex, bc, startIndex);

    // choose the best annotation 
    BestAnnotation bestAnn = findBestCandidate(rootNode, bc, startIndex);
    freeMemory(rootNode);    

    return bestAnn;
}

SearchBest::SearchBest(int numSeq, TInterAnchor* tInt, map<int,double> bLenMap,
                    map<int, vector<int> >* trMap, int rootIndex, bool notre, int numshift, int ldist, bool iAnchor,                       int numIter, Param param, map<int, string>* nameMap)
{
    treeMap = trMap;            /////
    nodeNameMap = nameMap;
    rootNodeIndex = rootIndex;  /////
    baseVec.push_back('A');
    baseVec.push_back('C');
    baseVec.push_back('G');
    baseVec.push_back('T');

	tInterAnchor = tInt;
	nSeq = numSeq;
    notRe = notre;
    numShift = numshift;
    lenDist = ldist;
    includeAnchor = iAnchor;
    m_numIter = numIter;
    branchLength = bLenMap;
    diffLenDist = param.getDiffLenDist();

    if (param.getInsLenAvg() != 0) insLenAvg = param.getInsLenAvg();
    else insLenAvg = tInterAnchor->getInsLenAvg();

    if (param.getDelLenAvg() != 0) delLenAvg = param.getDelLenAvg();
    else delLenAvg = tInterAnchor->getDelLenAvg();

    if (param.getInsLambda() != 0) insLambda = param.getInsLambda();
    else insLambda = tInterAnchor->getInsLambda();

    if (param.getDelLambda() != 0) delLambda = param.getDelLambda();
    else delLambda = tInterAnchor->getDelLambda();

    if (param.getInsRzeta() != 0) insrzeta = param.getInsRzeta();
    else insrzeta = tInterAnchor->getInsRzeta(); 

    if (param.getDelRzeta() != 0) delrzeta = param.getDelRzeta();
    else delrzeta = tInterAnchor->getDelRzeta();

    if (param.getInsProbSuccess() != 0) insProbSuccess = param.getInsProbSuccess();
    else insProbSuccess = tInterAnchor->getInsProbSuccess(); 

    if (param.getDelProbSuccess() != 0) delProbSuccess = param.getDelProbSuccess();
    else delProbSuccess = tInterAnchor->getDelProbSuccess();

    if (param.getConstMut() != 0) constMut = param.getConstMut();
	else constMut = tInterAnchor->getConstMut(); // Functions required

    if (param.getConstIns() != 0) constIns = param.getConstIns();
	else constIns = tInterAnchor->getConstIns(); // Functions required

    if (param.getConstDel() != 0) constDel = param.getConstDel();
	else constDel = tInterAnchor->getConstDel(); // Functions required

    if (param.getF81param() != 0) m_paramU = param.getF81param();
    else m_paramU = tInterAnchor->getParamU();

    m_freqA = tInterAnchor->getFreqA();
    m_freqC = tInterAnchor->getFreqC();
    m_freqG = tInterAnchor->getFreqG();
    m_freqT = tInterAnchor->getFreqT();
    
    m_anchorVec = tInterAnchor->getAnchorString();
	sumOfLenSquare = tInterAnchor->getSumOfLenSquare(); // Functions required
	bestScore = -100000000.0;
	copyInterAnchor();
    calculateAnchorScore();
}

PhyloTreeNodeEx* SearchBest::makeTree(BoundaryChunk* bc, map<int, vector<int> >* seqMap)
{
    PhyloTreeNodeEx* pNode = new PhyloTreeNodeEx();
    aux_makeTree(bc, pNode, NULL, rootNodeIndex, seqMap);
    return pNode;
}

// Parameters: cNode - current node, pNode - parent node
void SearchBest::aux_makeTree(BoundaryChunk* bc, PhyloTreeNodeEx* cNode, PhyloTreeNodeEx* pNode, 
                            int nodeIndex, map<int, vector<int> >* seqMap)
{
    if (nodeIndex > nSeq)
    {
        vector<int> childIndex = treeMap->operator[](nodeIndex);
		int leftCIndex = childIndex.at(0);
		int rightCIndex = childIndex.at(1);

        // if left child is leaf node
        PhyloTreeNodeEx* leftTree = new PhyloTreeNodeEx();
        PhyloTreeNodeEx* rightTree = new PhyloTreeNodeEx();
        cNode->setLeftChild(leftTree);
        cNode->setRightChild(rightTree);

        if (leftCIndex > nSeq)
        {
            aux_makeTree(bc, leftTree, cNode, leftCIndex, seqMap);
        } // end of if
        else
        {
            vector<int> colIdNumVec = seqMap->operator[](leftCIndex);
            IndelEntry* iEntry = new IndelEntry();
            // store real subsequences for each chunk column id
            for (int cid = 0; cid < (int)colIdNumVec.size(); cid++)
            {
                int tmpId = colIdNumVec.at(cid);
                SubstInfo* substInfo = NULL;
                iEntry->addChunkId(tmpId);
                
                if (tmpId > 0)
                {
                    string str = bc->getChunkSeq(tmpId - 1, leftCIndex);
                    NodeScoreMatrixSet* nsVecNew = new NodeScoreMatrixSet();
                    for (int sid = 0; sid < (int)str.size(); sid++)
                    {
                        NodeScoreMatrix* nsMatNew = new NodeScoreMatrix();
                        nsMatNew->setScore(str.at(sid), 1.0);
                        nsVecNew->addNodeScoreMatrix(nsMatNew);
                    } // end of for
    
                    // codes for new substitution score calculation
                    substInfo = new SubstInfo(nsVecNew); 
                    substInfo->setFixed();
                    substInfo->setLeftStar();
                    substInfo->setRightStar();                    
                } // end of if
                else
                {
                    substInfo = new SubstInfo(NULL);
                } // end of else
                leftTree->addSubstInfo(substInfo);
            } // end of for
            leftTree->addIndelEntry(iEntry);

        } // end of else

        if (rightCIndex > nSeq)
        {
            aux_makeTree(bc, rightTree, cNode, rightCIndex, seqMap);
        } // end of if
        else
        {
            vector<int> colIdNumVec = seqMap->operator[](rightCIndex);
            
            IndelEntry* iEntry = new IndelEntry();
            // store real subsequences for each chunk column id
            for (int cid = 0; cid < (int)colIdNumVec.size(); cid++)
            {
                int tmpId = colIdNumVec.at(cid);
                SubstInfo* substInfo = NULL;
                iEntry->addChunkId(tmpId);

                if (tmpId > 0)
                {
                    string str = bc->getChunkSeq(tmpId - 1, rightCIndex);
                    NodeScoreMatrixSet* nsVecNew = new NodeScoreMatrixSet();
                    for (int sid = 0; sid < (int)str.size(); sid++)
                    {
                        NodeScoreMatrix* nsMatNew = new NodeScoreMatrix();
                        nsMatNew->setScore(str.at(sid), 1.0);
                        nsVecNew->addNodeScoreMatrix(nsMatNew);
                    } // end of for
                    
                    substInfo = new SubstInfo(nsVecNew);
                    substInfo->setFixed();
                    substInfo->setLeftStar();
                    substInfo->setRightStar();  
                } // end of if
                else
                {
                    substInfo = new SubstInfo(NULL);
                } // end of else
                
                rightTree->addSubstInfo(substInfo);
            } // end of for
            rightTree->addIndelEntry(iEntry);
       } // end of else
    } // end of if
    else
    {
    } // end of else
}

void SearchBest::freeMemory(PhyloTreeNodeEx* pNode)
{
    if (pNode == NULL) return;

    PhyloTreeNodeEx* leftChild = pNode->getLeftChild();
    PhyloTreeNodeEx* rightChild = pNode->getRightChild();

    if (leftChild != NULL) freeMemory(leftChild);
    if (rightChild != NULL) freeMemory(rightChild);

    pNode->setLeftChild(NULL);
    pNode->setRightChild(NULL);
    
    delete pNode;
    pNode = NULL;
}

void SearchBest::enumCandidateAnnotation(PhyloTreeNodeEx* pNode, int* bIndex, BoundaryChunk* bc, int startIndex)
{
    PhyloTreeNodeEx* leftChild = pNode->getLeftChild();
    int leftBIndex = *bIndex;

    // recursive call
    if (leftChild->getLeftChild() != NULL)
    {
        (*bIndex) += 1;
        enumCandidateAnnotation(leftChild, bIndex, bc, startIndex);
    } // end of if

    PhyloTreeNodeEx* rightChild = pNode->getRightChild();
    (*bIndex) += 1;
    int rightBIndex = *bIndex;

    if (rightChild->getRightChild() != NULL)
    {
        (*bIndex) += 1;
        enumCandidateAnnotation(rightChild, bIndex, bc, startIndex);
    } // end of if
    
    // Base case
    // Case1: current node is leaf node
    if (pNode->getLeftChild() == NULL) return;
    
    IndelEntry* tmpIE = leftChild->getIndelEntryAt(0);
    int numChunk = tmpIE->getChunkIdVecSize();

    for (int i = 0; i < numChunk; i++)
    {
        int tmpChunkId = abs(tmpIE->getChunkIdAt(i));
        
        SubstInfo* subInfo = pNode->getSubstInfoAt(i);
        if (subInfo->isFixed())
        {
            if (pNode->getIndelEntryVecSize() == 0)
            {
                IndelEntry* ie = new IndelEntry();
                ie->addChunkId(tmpChunkId);
                pNode->addIndelEntry(ie);
            } // end of if
            else
            {
                for (int ia = 0; ia < pNode->getIndelEntryVecSize(); ia++)
                    pNode->getIndelEntryAt(ia)->addChunkId(tmpChunkId);
            } // end of else                
        } // end of if
        else
        {
            if (pNode->getIndelEntryVecSize() == 0)
            {
                IndelEntry* ie1 = new IndelEntry();
                ie1->addChunkId(tmpChunkId);
                IndelEntry* ie2 = new IndelEntry();
                ie2->addChunkId(-tmpChunkId);
                pNode->addIndelEntry(ie1);
                pNode->addIndelEntry(ie2);
            } // end of if
            else
            {
                vector<IndelEntry*> tmpVec;
                for (int ia = 0; ia < pNode->getIndelEntryVecSize(); ia++)
                {
                    IndelEntry* ie = new IndelEntry(pNode->getIndelEntryAt(ia));
                    pNode->getIndelEntryAt(ia)->addChunkId(tmpChunkId);
                    ie->addChunkId(-tmpChunkId);
                    tmpVec.push_back(ie);
                } // end of for
                
                for (int ia = 0; ia < tmpVec.size(); ia++)
                    pNode->addIndelEntry(tmpVec.at(ia));
            } // end of else
        } // end of else
    } // end of for
    
    for (int i = 0; i < pNode->getIndelEntryVecSize(); i++)
    {
        IndelEntry* pEntry = pNode->getIndelEntryAt(i);
        
        // left branch
        double leftMaxScore = 0.0;
        int lIndex = 0;
        
        for (int j = 0; j < leftChild->getIndelEntryVecSize(); j++)
        {
            IndelEntry* cEntry = leftChild->getIndelEntryAt(j);
            double score = getIndelScore(bc, leftBIndex, startIndex, pEntry, cEntry);
            
            if (j == 0 || score > leftMaxScore)
            {
                leftMaxScore = score;
                lIndex = j;
            } // end of if
        } // end of for

        // right branch
        double rightMaxScore = 0.0;
        int rIndex = 0;
        
        for (int j = 0; j < rightChild->getIndelEntryVecSize(); j++)
        {
            IndelEntry* cEntry = rightChild->getIndelEntryAt(j);
            double score = getIndelScore(bc, rightBIndex, startIndex, pEntry, cEntry);
            
            if (j == 0 || score > rightMaxScore)
            {
                rightMaxScore = score;
                rIndex = j;
            } // end of if
        } // end of for

        // set the best left and right children
        pEntry->setScore(leftMaxScore + rightMaxScore);
        pEntry->setLeftChildEntryIndex(lIndex);
        pEntry->setRightChildEntryIndex(rIndex);
    } // end of for
}

double SearchBest::getFinalScoreEx(map<int, vector<BestAnnotation> >* bAnnMap)
{
    double score = 0.0;
    map<int, vector<BestAnnotation> >::iterator iter;
    for (iter = bAnnMap->begin(); iter != bAnnMap->end(); iter++)
    {
        vector<BestAnnotation> annVec = iter->second;
        for (int i = 0; i < (int)annVec.size(); i++)
        {
            BestAnnotation bAnn = annVec.at(i);
            score += bAnn.getScore();
        } // end of for
    } // end of for

    return score + m_scoreOfAnchors;
}

double SearchBest::getFinalScore()
{
    double score = 0.0;
    map<int, vector<BestAnnotation> >::iterator iter;
    for (iter = bestScoreIAnchorMap.begin(); iter != bestScoreIAnchorMap.end(); iter++)
    {
        vector<BestAnnotation> annVec = iter->second;
        for (int i = 0; i < annVec.size(); i++)
        {
            BestAnnotation bAnn = annVec.at(i);
            score += bAnn.getScore();
        } // end of for
    } // end of for

    return score;
}

void SearchBest::summaryBranchInfo(map<int, BoundaryChunk>* bcMap, map<int, vector<BestAnnotation> >* bestAnnMap)
{
    branchSummary.clear();
    map<int, vector<double> >().swap(branchSummary);
    insLengSummary.clear();
    map<int, vector<int> >().swap(insLengSummary);
    delLengSummary.clear();
    map<int, vector<int> >().swap(delLengSummary);
    parentSeqLenSummary.clear();
    map<int, int>().swap(parentSeqLenSummary);

    for (int i = 1; i <= tInterAnchor->getNumOfInterAnchor(); i++)
    {
        BoundaryChunk bc = bcMap->operator[](i);
        vector<BestAnnotation> annVec = bestAnnMap->operator[](i);

        for (int j = 0; j < (int)annVec.size(); j++)
        {
            int branchIndex =1;
            BestAnnotation bAnn = annVec.at(j);
            BranchInfoSet* bInfoSet = bAnn.getBranchInfoSet();

            for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
            {
                map<int, int>::iterator iiIter;
                iiIter = parentSeqLenSummary.find(bIndex);
                if (iiIter == parentSeqLenSummary.end())
                {
                    parentSeqLenSummary[bIndex] = bInfoSet->getParentSeqLenAt(bIndex);
                } // end of if
                else
                {
                    parentSeqLenSummary[bIndex] += bInfoSet->getParentSeqLenAt(bIndex);
                } // end of else

                BranchInfo* bInfo = bInfoSet->getBranchInfoAt(bIndex);
                double numMat = bInfo->getNumOfMatch();
                double numMut = bInfo->getNumOfMisMatch();
                double numIns = bInfo->getNumOfInsertion();
                double numDel = bInfo->getNumOfDeletion();
                double numDelLen = bInfo->getTotalLenOfDel();

                double numNonIns = numMat + numMut + 1 - numIns;
                double numNonDel = numMat + numMut;
                map<int, vector<double> >::iterator iter;
                iter = branchSummary.find(bIndex);
                if (iter == branchSummary.end())
                 {
                    // insert new summary vector
                    vector<double> smmVec;
                    smmVec.push_back(numMat);
                    smmVec.push_back(numMut);
                    smmVec.push_back(numIns);
                    smmVec.push_back(numDel);
                    smmVec.push_back(numDelLen);
                    branchSummary[bIndex] = smmVec;

                 } 
                 else
                 {
                    // use previous summary vector
                    vector<double> smmVec = branchSummary[bIndex];
                    
                    double pNumMat = smmVec.at(0);
                    pNumMat += numMat;
                    smmVec[0] = pNumMat;
                    double pNumMut = smmVec.at(1);
                    pNumMut += numMut;
                    smmVec[1] = pNumMut;
                    double pNumIns = smmVec.at(2);
                    pNumIns += numIns;
                    smmVec[2] = pNumIns;
                    double pNumDel = smmVec.at(3);
                    pNumDel += numDel;
                    smmVec[3] = pNumDel;
                    double pNumDelLen = smmVec.at(4);
                    pNumDelLen += numDelLen;
                    smmVec[4] = pNumDelLen;
                    
                    branchSummary[bIndex] = smmVec;

                }

                vector<int> lengInsVec = bInfo->getInsLenVecValue();
                map<int, vector<int> >::iterator iterIns;
                iterIns = insLengSummary.find(bIndex);
                if (iterIns == insLengSummary.end())
                {
                    insLengSummary[bIndex] = lengInsVec;
                }
                else
                {
                    vector<int> insVec = insLengSummary[bIndex];
                    for (int indel = 0; indel < (int)lengInsVec.size(); indel++)
                        insVec.push_back(lengInsVec.at(indel));
                    insLengSummary[bIndex] = insVec;
                }

                vector<int> lengDelVec = bInfo->getDelLenVecValue();
                map<int, vector<int> >::iterator iterDel;
                iterDel = delLengSummary.find(bIndex);
                if (iterDel == delLengSummary.end())
                {
                    delLengSummary[bIndex] = lengDelVec;
                }
                else
                {
                    vector<int> delVec = delLengSummary[bIndex];
                    for (int indel = 0; indel < (int)lengDelVec.size(); indel++)
                        delVec.push_back(lengDelVec.at(indel));
                    delLengSummary[bIndex] = delVec;
                }
            } // end of for
        } // end of for
    } // end of for
}

 void SearchBest::nodeBestAnnotation(PhyloTreeNodeEx* root)
 {
     PhyloTreeNodeEx* leftNode = root->getLeftChild();
     PhyloTreeNodeEx* rightNode = root->getRightChild();
     
     if(leftNode->getLeftChild() != NULL)
    	 nodeBestAnnotation(leftNode);
     if(rightNode->getLeftChild() != NULL)
	    nodeBestAnnotation(rightNode);      

 }

void SearchBest::dumpBC(BoundaryChunk* pbc)
{
    vector<string>* seqVec = pbc->getSeqVec();
    
    for (int i = 0; i < (int)seqVec->size(); i++)
    {
        if (i == 0)
        {
            cerr << "\t";
            for (int j = 0; j < (int)seqVec->at(i).size(); j++)
            {
                if (j % 5 == 4) cerr << "|";
                else cerr << " ";
            } // end of for
            cerr << endl;
        } // end of if
        
        cerr << "\t" << seqVec->at(i) << endl;
    } // end of for
    cerr << endl;
}

void SearchBest::dumpSeqVec(vector<string>* seqVec)
{
    for (int i = 0; i < (int)seqVec->size(); i++)
    {
        if (i == 0)
        {
            cerr << "\t";
            for (int j = 0; j < (int)seqVec->at(i).size(); j++)
            {
                if (j % 5 == 4) cerr << "|";
                else cerr << " ";
            } // end of for
            cerr << endl;
        } // end of if
        
        cerr << "\t" << seqVec->at(i) << endl;
    } // end of for
    cerr << endl;
}


void SearchBest::dumpAnnVec(BoundaryChunk* pbc, vector<BestAnnotation>* pAnnVec)
{
    map<int, vector<OutputDS> > finalResultOut;
    for (int j = 0; j < (int)pAnnVec->size(); j++)
    {
        BestAnnotation bAnn = pAnnVec->at(j);
        int baStartIndex = bAnn.getStartColIndex();
        BranchInfoSet* bInfoSet = bAnn.getBranchInfoSet();

        for (int s = 1; s <= nSeq; s++)
        {
            int bIndex = tInterAnchor->getBranchForLeafSeq(s);
            BranchInfo* bInfo = bInfoSet->getBranchInfoAt(bIndex);
            vector<AnnInfo>* aInfoVec = bInfo->getAnnInfoVec();

            for (int afIndex = 0; afIndex < aInfoVec->size(); afIndex++)
            {
                AnnInfo aInfo = aInfoVec->at(afIndex);
                int start = aInfo.getStartIndex() + baStartIndex;// + startPos;
	            int end = aInfo.getEndIndex() + baStartIndex;// + startPos;
	            int anno = aInfo.getAnn();	
    			
	            string anno_str;
                if(anno == PhyloTreeNode::INSERTION){anno_str = "Insertion";}
	            else{
                    if(anno == PhyloTreeNode::DELETION){anno_str = "Deletion";}
		            else{anno_str = "anno_error";}
	            }
    			
	            OutputDS currentItem(start,end,anno_str,aInfo.getLength());
	            finalResultOut[s].push_back(currentItem);
            } // end of for
        } // end of for
        
    } // end of for int i

    for(int s=1;s<=nSeq;s++)
    {
        // Merge continuous indels
        vector<OutputDS> newResult;
        for(int j=0;j<(int)finalResultOut[s].size();j++)
        {
		    int start = finalResultOut[s].at(j).getStartIndex();
		    int end = finalResultOut[s].at(j).getEndIndex();
		    string anno = finalResultOut[s].at(j).getAnnotation();
  	        
            if (j == 0)
                newResult.push_back(finalResultOut[s].at(j));
            else
            {
                int pend = newResult.at(newResult.size() - 1).getEndIndex();
                string panno = newResult.at(newResult.size() - 1).getAnnotation();
                if (anno != panno)
                {
                    newResult.push_back(finalResultOut[s].at(j));
                } // end of if
                else
                {
                    if ((pend + 1) == start)
                    {
                        int pstart = newResult.at(newResult.size() - 1).getStartIndex();
                        OutputDS currentItem(pstart,end,anno,finalResultOut[s].at(j).getLength() + newResult.at(newResult.size() - 1).getLength());
                        newResult.pop_back();
                        newResult.push_back(currentItem);
                    } // end of if
                    else
                    {
                        newResult.push_back(finalResultOut[s].at(j));
                    } // end of else
                } // end of else
            } // end of else
	    }

        cerr << "\tSequence " << s << endl;	
  	    for(int j=0;j<(int)newResult.size();j++)
        {
		    int start = newResult.at(j).getStartIndex();
		    int end = newResult.at(j).getEndIndex();
		    string anno = newResult.at(j).getAnnotation();
            int len = newResult.at(j).getLength();
  	        cerr << "\t\t" << (start + 1) << "\t" << (end + 1)<< "\t" << anno;
            
            if (len != (end - start + 1))
                cerr << "\tSplitted one indel" << endl;
            else
                cerr << endl;
	    }
    }
    cerr << endl;
}

double SearchBest::getConstMut()
{
    return constMut;
}

double SearchBest::getConstIns()
{
    return constIns;
}

double SearchBest::getConstDel()
{
    return constDel;
}

int SearchBest::getLenDist()
{
    return lenDist;
}

double SearchBest::getInsLenAvg()
{
    return insLenAvg;
}

double SearchBest::getDelLenAvg()
{
    return delLenAvg;
}

double SearchBest::getInsLambda()
{
    return insLambda;
}

double SearchBest::getDelLambda()
{
    return delLambda;
}

double SearchBest::getInsRZeta()
{
    return insrzeta;
}

double SearchBest::getDelRZeta()
{
    return delrzeta;
}

double SearchBest::getInsProbSuccess()
{
    return insProbSuccess;
}

double SearchBest::getDelProbSuccess()
{
    return delProbSuccess;
}

void SearchBest::setAnchorBranchInfo(TotalBranch* tBranch)
{
    anchorBranchInfo = tBranch;
}

bool SearchBest::getDiffLenDist()
{
    return diffLenDist;
}

void SearchBest::dumpBranchInfo(vector<BestAnnotation>* pAnnVec)
{
    cerr << endl;
    cerr << "<Branch Information>" << endl;
    
    for (int bIndex = 1; bIndex <= tInterAnchor->getNumBranch(); bIndex++)
    {
        cerr << "Branch Index:" << bIndex << endl;
        double numMat = 0.0;
        double numMut = 0.0;
        double numIns = 0.0;
        double numDel = 0.0;
        double numNonIns = 0.0;
        double numNonDel = 0.0;
        
        vector<int> insVec;
        vector<int> delVec;

        for (int i = 0; i < pAnnVec->size(); i++)
        {
            BestAnnotation bAnn = pAnnVec->at(i);
            BranchInfoSet* biSet = bAnn.getBranchInfoSet();
            BranchInfo* bi = biSet->getBranchInfoAt(bIndex);
            numMat += bi->getNumOfMatch();
            numMut += bi->getNumOfMisMatch();
            numIns += bi->getNumOfInsertion();
            numDel += bi->getNumOfDeletion();

            vector<int> tmpVec = bi->getInsLenVecValue();
            for (int ti = 0; ti < tmpVec.size(); ti++)
                insVec.push_back(tmpVec.at(ti));

            tmpVec = bi->getDelLenVecValue();
            for (int ti = 0; ti < tmpVec.size(); ti++)
                delVec.push_back(tmpVec.at(ti));
            
        } // end of for

        numNonIns = numMat + numMut + numDel + 1 - numIns;
        numNonDel = numMat + numMut;

        cerr << "\tMat:" << numMat << endl;
        cerr << "\tMut:" << numMut << endl;
        cerr << "\tIns:" << numIns << endl;
        cerr << "\tNonIns:" << numNonIns << endl;
        cerr << "\tDel:" << numDel << endl;
        cerr << "\tNonDel:" << numNonDel << endl;

        for (int j = 0; j < insVec.size(); j++)
        {
            cerr << "\tIns len:" << insVec.at(j) << endl;
        } // end of for

        for (int j = 0; j < delVec.size(); j++)
        {
            cerr << "\tDel len:" << delVec.at(j) << endl;
        } // end of for
    } // end of for
}

double SearchBest::getNucFreq(char ch)
{
    double freq = 0.0;
    if (ch == 'A') freq = m_freqA;
    else if (ch == 'C') freq = m_freqC;
    else if (ch == 'G') freq = m_freqG;
    else if (ch == 'T') freq = m_freqT;

    return freq;
}

void SearchBest::calculateAnchorScore()
{
    int tmpNumCol = m_anchorVec.at(0).length();
    m_scoreOfAnchors = 0.0;

    map<int, vector<int> > seqMap;
    for (int i = 1; i <= nSeq; i++)
    {
        vector<int> tmpVec;
        tmpVec.push_back(i);
        seqMap[i] = tmpVec;
    } // end of for

    for (int colIndex = 0; colIndex < tmpNumCol; colIndex++)
    {
        // make temporary anchor vector
        vector<string> anchorVec;
        for (int i = 0; i < m_anchorVec.size(); i++)
            anchorVec.push_back(m_anchorVec.at(i).substr(colIndex, 1));
        
        BoundaryChunk bc(nSeq, anchorVec);
        PhyloTreeNodeEx* rootNode = makeTree(&bc, &seqMap);        

        int branchIndex = 1 ;
        // Compute substition score for each block in the given tree before generating candidiate annotations
        computeSubstScoreStep1(rootNode, &branchIndex, &bc);
        
        int tmpSize = rootNode->getSubstInfoVecSize();
        vector<double>* scrVec = new vector<double>;
        for (int i = 0; i < tmpSize; i++) scrVec->push_back(0.0);
        computeSubstScoreStep2(rootNode, scrVec);
        
        for (int i = 0; i < scrVec->size(); i++) m_scoreOfAnchors += scrVec->at(i);
        rootNode->setSubstScore(scrVec);
        delete scrVec;
        freeMemory(rootNode);
    } // end of for
#ifdef DEBUG_OUTPUT
    cerr << "Score of Anchors:" << m_scoreOfAnchors << endl;
#endif
}

// index 0(ins) 1(del)
vector<int> SearchBest::getIndelCnt(map<int, vector<BestAnnotation> >* pAnnVecMap)
{
    int numIns = 0;
    int numDel = 0;
    
    vector<int> brNumVec;
    vector<int>* ingroupSeqNumVec = tInterAnchor->getIngroupSeqNumVec();
    for (int i = 0; i < ingroupSeqNumVec->size(); i++)
    {
        int brNum = tInterAnchor->getBranchNumForSeq(ingroupSeqNumVec->at(i));
        brNumVec.push_back(brNum);
    } // end of for
    
    for (int iaNum = 1; iaNum <= tInterAnchor->getNumOfInterAnchor(); iaNum++)
    {
        vector<BestAnnotation> annVec = pAnnVecMap->operator [](iaNum);
        for (int i = 0; i < annVec.size(); i++)
        {
            BestAnnotation bAnn = annVec.at(i);
            BranchInfoSet* biSet = bAnn.getBranchInfoSet();
            
            for (int j = 0; j < brNumVec.size(); j++)
            {
                BranchInfo* bi = biSet->getBranchInfoAt(brNumVec.at(j));
                numIns += bi->getNumOfInsertion();
                numDel += bi->getNumOfDeletion();
            } // end of for
        } // end of for
    } // end of for

    vector<int> numVec;
    numVec.push_back(numIns);
    numVec.push_back(numDel);
    
    return numVec;
}

vector<int> SearchBest::getSeparateIndelCnt(map<int, vector<BestAnnotation> >* pAnnVecMap)
{
    int numIns = 0;
    int numDel = 0;
    
    vector<int> brNumVec;
    vector<int>* ingroupSeqNumVec = tInterAnchor->getIngroupSeqNumVec();
    for (int i = 0; i < ingroupSeqNumVec->size(); i++)
    {
        int brNum = tInterAnchor->getBranchNumForSeq(ingroupSeqNumVec->at(i));
        brNumVec.push_back(brNum);
    } // end of for
    
    vector<int> numVec;
    // initialize the vector
    numVec.push_back(0);    // for total number of insertion
    numVec.push_back(0);    // for total number of deletion
    for (int i = 0; i < ingroupSeqNumVec->size(); i++)
    {
        numVec.push_back(0);    // for insertion of this sequence
        numVec.push_back(0);    // for deletion of this sequence
    } // end of for
    
    for (int iaNum = 1; iaNum <= tInterAnchor->getNumOfInterAnchor(); iaNum++)
    {
        vector<BestAnnotation> annVec = pAnnVecMap->operator [](iaNum);
        for (int i = 0; i < annVec.size(); i++)
        {
            BestAnnotation bAnn = annVec.at(i);
            BranchInfoSet* biSet = bAnn.getBranchInfoSet();
            
            for (int j = 0; j < brNumVec.size(); j++)
            {
                BranchInfo* bi = biSet->getBranchInfoAt(brNumVec.at(j));
                numVec.at(2 + 2 * j) += bi->getNumOfInsertion();
                numVec.at(2 + 2 * j + 1) += bi->getNumOfDeletion();
                numVec.at(0) += bi->getNumOfInsertion();
                numVec.at(1) += bi->getNumOfDeletion();
            } // end of for
        } // end of for
    } // end of for
    
    return numVec;
}

void SearchBest::calculateIndelScore(map<int, vector<BestAnnotation> >* pAnnVecMap)
{
    vector<int> numVec = getIndelCnt(pAnnVecMap);
    int numIns = numVec.at(0);
    int numDel = numVec.at(1);
    int trueInsNum = 0;
    int trueDelNum = 0;
    vector<int>* ingroupSeqNumVec = tInterAnchor->getIngroupSeqNumVec();

    for (int i = 0; i < ingroupSeqNumVec->size(); i++)
    {
        int num = ingroupSeqNumVec->at(i);
        vector<int> trueVec = tInterAnchor->getTrueIndelVec(num);
        trueInsNum += trueVec.at(0);
        trueDelNum += trueVec.at(1);
    } // end of for
    
    // error check
    if (trueInsNum == 0 || trueDelNum == 0) 
    {
        cerr << "Error!" << endl;
        cerr << "There does not exist the true indel count." << endl;
        cerr << "Check there is a 'TrueIndelCnt.txt' file." << endl;
        cerr << "Or set the 'UseTrueIndel' value to 'true' in the input parameter file." << endl;
        exit(1);
    } // end of if

    cout << trueInsNum << " " << trueDelNum;
    cout << " " << numIns << " " << numDel;

    double indelAgree = Util::getIndelAgreement(trueInsNum, numIns, trueDelNum, numDel);
    double indelRatio = Util::getIndelRatio(trueInsNum, numIns, trueDelNum, numDel);
    
    cout << " " << indelAgree << " " << indelRatio << " ";
}

vector<int> SearchBest::getOverlapBA(vector<BestAnnotation>* baVec, int sIndex, int eIndex, double* subScore)
{
    vector<int> baIndexVec;

    for (int i = 0; i < baVec->size(); i++)
    {
        BestAnnotation ba = baVec->at(i);
        if (ba.getStartColIndex() <= eIndex && ba.getEndColIndex() >= sIndex)
            baIndexVec.push_back(i);
        else if (ba.getStartColIndex() - 1 == eIndex || ba.getEndColIndex() + 1 == sIndex)
            baIndexVec.push_back(i);
        else
            (*subScore) += ba.getScore();
    } // end of for

    return baIndexVec;
}

void SearchBest::runSystemCmd(string cmd, bool bout)
{
    FILE* fp;
    char buff[1024];
    fp = popen(cmd.c_str(), "r");
    while (fgets(buff, 1024, fp) != NULL)
    {
        if (bout == true) cout << buff;
    } // end of while
    pclose(fp);
    if (bout == true) cout << " ";
}

// Fill the data of SubstInfo class bottom-up 
void SearchBest::computeSubstScoreStep1(PhyloTreeNodeEx* pNode, int* bIndex, BoundaryChunk* bc)
{
    PhyloTreeNodeEx* leftChild = pNode->getLeftChild();
    int leftBIndex = *bIndex;
    
    // recursive call
    if (leftChild->getLeftChild() != NULL)
    {
        (*bIndex) += 1;
        computeSubstScoreStep1(leftChild, bIndex, bc);
    } // end of if

    PhyloTreeNodeEx* rightChild = pNode->getRightChild();
    (*bIndex) += 1;
    int rightBIndex = *bIndex;

    // recursive call
    if (rightChild->getRightChild() != NULL)
    {
        (*bIndex) += 1;
        computeSubstScoreStep1(rightChild, bIndex, bc);
    } // end of if
    
    // Base case
    // Case1: current node is leaf node
    if (pNode->getLeftChild() == NULL) return;
    
    assert(leftChild->getSubstInfoVecSize() == rightChild->getSubstInfoVecSize());
    int vecSize = leftChild->getSubstInfoVecSize();
    double lbLength = branchLength[leftBIndex];
    double rbLength = branchLength[rightBIndex];
    
    for (int i = 0; i < vecSize; i++)
    {
        SubstInfo* leftSubInfo = leftChild->getSubstInfoAt(i);
        SubstInfo* rightSubInfo = rightChild->getSubstInfoAt(i);
        
        SubstInfo* newSubInfo = new SubstInfo();
        if (leftSubInfo->isLeftStar() || leftSubInfo->isRightStar()) newSubInfo->setLeftStar();
        if (rightSubInfo->isLeftStar() || rightSubInfo->isRightStar()) newSubInfo->setRightStar();

        // calculate substitution score
        NodeScoreMatrixSet* leftMatSet = leftSubInfo->getNodeScoreMatrixSet();
        NodeScoreMatrixSet* rightMatSet = rightSubInfo->getNodeScoreMatrixSet();
        NodeScoreMatrixSet* newMatSet = NULL;            
        
        if (leftMatSet == NULL && rightMatSet == NULL)
        {
            ; // do nothing
        } // end of if            
        else if (leftMatSet != NULL && rightMatSet == NULL)
        {
            newMatSet = new NodeScoreMatrixSet();
            for (int j = 0; j < leftMatSet->getSize(); j++)
            {
                NodeScoreMatrix* leftMat = leftMatSet->getNodeScoreMatrixAt(j);
                NodeScoreMatrix* nsMat = new NodeScoreMatrix();
                for (int bsIndex = 0; bsIndex < (int)baseVec.size(); bsIndex++)
                {
                    char nodeCh = baseVec.at(bsIndex);
    
                    double score = 0.0; //NodeScoreMatrix::MAX_EVENT;
                    
                    for (int tIndex = 0; tIndex < (int)baseVec.size(); tIndex++)
                    {
                        double tmpProb = 1.0;
                        char childCh = baseVec.at(tIndex);  
                        tmpProb *= Util::substProb(nodeCh, childCh, lbLength, m_paramU, getNucFreq(childCh));
                        tmpProb *= leftMat->getProb(childCh);
                        score += tmpProb;
                    } //end of for
                    nsMat->setProb(nodeCh, score);
                } // end of for
                newMatSet->addNodeScoreMatrix(nsMat);
            } // end of for
        } // end of else if
        else if (leftMatSet == NULL && rightMatSet != NULL)
        {
            newMatSet = new NodeScoreMatrixSet();
            for (int j = 0; j < rightMatSet->getSize(); j++)
            {
                NodeScoreMatrix* rightMat = rightMatSet->getNodeScoreMatrixAt(j);
                NodeScoreMatrix* nsMat = new NodeScoreMatrix();
                for (int bsIndex = 0; bsIndex < (int)baseVec.size(); bsIndex++)
                {
                    char nodeCh = baseVec.at(bsIndex);
    
                    double score = 0.0; //NodeScoreMatrix::MAX_EVENT;
                    
                    for (int tIndex = 0; tIndex < (int)baseVec.size(); tIndex++)
                    {
                        double tmpProb = 1.0;
                        char childCh = baseVec.at(tIndex);  
                        tmpProb *= Util::substProb(nodeCh, childCh, rbLength, m_paramU, getNucFreq(childCh));
                        tmpProb *= rightMat->getProb(childCh);
                        score += tmpProb;
                    } //end of for
                    nsMat->setProb(nodeCh, score);
                } // end of for
                newMatSet->addNodeScoreMatrix(nsMat);
            } // end of for
        } // end of else if
        else
        {
            assert(leftMatSet->getSize() == rightMatSet->getSize());
            newMatSet = new NodeScoreMatrixSet();
                        
            for (int im = 0; im < leftMatSet->getSize(); im++)
            {
                NodeScoreMatrix* ns1 = leftMatSet->getNodeScoreMatrixAt(im);
                NodeScoreMatrix* ns2 = rightMatSet->getNodeScoreMatrixAt(im);
                NodeScoreMatrix* ns = new NodeScoreMatrix();

                for (int bsIndex = 0; bsIndex < (int)baseVec.size(); bsIndex++)
                {
                    char nodeCh = baseVec.at(bsIndex);

                    double score = 0.0; //NodeScoreMatrix::MAX_EVENT;
                    for (int ltIndex = 0; ltIndex < (int)baseVec.size(); ltIndex++)
                    {
                        double tmpProb = 1.0;
                        char leftCh = baseVec.at(ltIndex);  
                        tmpProb *= Util::substProb(nodeCh, leftCh, lbLength, m_paramU, getNucFreq(leftCh));                       
                        tmpProb *= ns1->getProb(leftCh);

                        for (int rtIndex = 0; rtIndex < (int)baseVec.size(); rtIndex++)
                        {
                            double tmpProb2 = tmpProb;
                            char rightCh = baseVec.at(rtIndex);  
                            tmpProb2 *= Util::substProb(nodeCh, rightCh, rbLength, m_paramU, getNucFreq(rightCh));
                            tmpProb2 *= ns2->getProb(rightCh);

                            score += tmpProb2;
                        } // end of for
                    } //end of for
                    ns->setScore(nodeCh, score);
                } // end of for

                newMatSet->addNodeScoreMatrix(ns);
            } // end of for
        } // end of else
        
        newSubInfo->setNodeScoreMatrixSet(newMatSet);
        pNode->addSubstInfo(newSubInfo);
    } // end of for
}

// Calculate final substitution score and mark the star nodes
void SearchBest::computeSubstScoreStep2(PhyloTreeNodeEx* pNode, vector<double>* scrVec)
{
    if (pNode == NULL) return;
    
    PhyloTreeNodeEx* leftChild = pNode->getLeftChild();
    PhyloTreeNodeEx* rightChild = pNode->getRightChild();
    
    int vecSize = pNode->getSubstInfoVecSize();
    
    for (int i = 0; i < vecSize; i++)
    {
        SubstInfo* substInfo = pNode->getSubstInfoAt(i);
        double scr = scrVec->at(i);
        if (scr != 0.0)
        {
            if (substInfo->isLeftStar() || substInfo->isRightStar()) substInfo->setFixed();
        } // end of if
        else
        {
            // did not found the least common ancestor
            if (substInfo->isLeftStar() && substInfo->isRightStar())
            {
                substInfo->setFixed();
                double logScore = 0.0;
                NodeScoreMatrixSet* nsMatSet = substInfo->getNodeScoreMatrixSet();
                for (int im = 0; im < nsMatSet->getSize(); im++)
                {
                    double score = 0.0;
                    NodeScoreMatrix* nsMat = nsMatSet->getNodeScoreMatrixAt(im);
                    for (int baseIndex = 0; baseIndex < baseVec.size(); baseIndex++)
                    {
                        char baseCh = baseVec.at(baseIndex);
                        score += nsMat->getProb(baseCh) * getNucFreq(baseCh);
                    } // end of for

                    logScore += log(score);
                } // end of for
                
                scrVec->operator[](i) = logScore;
            } // end of if
        } // end of else
    } // end of for
    
    pNode->compactSubstInfoVec();
    // recursion part
    computeSubstScoreStep2(leftChild, scrVec);
    computeSubstScoreStep2(rightChild, scrVec);
}

double SearchBest::getIndelScore(BoundaryChunk* bc, int bIndex, int startIndex, IndelEntry* pEntry, IndelEntry* cEntry)
{
    double totalScore = 0.0;
    totalScore += cEntry->getScore();
        
    vector<int> insCIDVec;
    vector<int> delCIDVec;
    vector<int> lengInsVec;
    vector<int> lengDelVec;
    
    vector<int>* pChunkIDVec = pEntry->getChunkIdVec();
    vector<int>* cChunkIDVec = cEntry->getChunkIdVec();
    int numMatMut = 0;
    
    for(int i=0; i< (int)pChunkIDVec->size(); i++)
    {
        int pIndex = pChunkIDVec->at(i);
        int cIndex = cChunkIDVec->at(i);

        if(pIndex == cIndex && pIndex > 0)
        {
            BoundaryItem* tbi = bc->getBoundaryItem(pIndex);
            numMatMut += (tbi->getEnd() - tbi->getStart() + 1);
        } // end of if
        else if (pIndex < 0 && cIndex > 0 && cIndex == -pIndex)
            insCIDVec.push_back(cIndex);    // Insertion
        else if (pIndex > 0 && cIndex < 0 && cIndex == -pIndex)
            delCIDVec.push_back(pIndex);    // Deletion
    } // end of for

    map<int, int>::iterator iter;
    
    if(insCIDVec.size() >0) sort( insCIDVec.begin(), insCIDVec.end() );
    if(delCIDVec.size() >0) sort( delCIDVec.begin(), delCIDVec.end() );

    int chunkLength = 0;
    int sAnn = 0;
    BoundaryItem* bItem = NULL;
    int numIns = 0;
    int numDel = 0;
    
    // process insertion vector
    for(int i=0; i<(int)insCIDVec.size(); i++)
    {
        int cID = insCIDVec.at(i);
        bItem = bc->getBoundaryItem(cID-1);
        
        if (chunkLength == 0) sAnn = bItem->getStart();

        if( (i+1) == insCIDVec.size())
        {
            numIns++;
            chunkLength +=  (bItem->getEnd() - bItem->getStart() + 1);
            lengInsVec.push_back(chunkLength);
            
            chunkLength=0;
        }
        else if( insCIDVec.at(i+1) == (nSeq + cID)) 
        {
            chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
        }
        else 
        {
            // check whether middle items between cID and nextcID are all gaps
            int nextId = insCIDVec.at(i + 1);
            int j = 0;
            for (j = cID + nSeq; j < nextId; j += nSeq)
            {
                vector<int>::iterator iter1 = find(pChunkIDVec->begin(), pChunkIDVec->end(), -j);
                vector<int>::iterator iter2 = find(cChunkIDVec->begin(), cChunkIDVec->end(), -j);
                if (iter1 == pChunkIDVec->end() || iter2 == cChunkIDVec->end()) break;
            } // end of for

            if (j == nextId)
            {
                // all middle items are gaps
                chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
            } // end of if
            else
            {
                 numIns++;
                 chunkLength += (bItem->getEnd() - bItem->getStart() + 1);
                 lengInsVec.push_back(chunkLength);

                 chunkLength=0;
            } // end of else
        } // end of else  
    } // end of for

    // process deletion vector
    chunkLength = 0;
    sAnn = 0;
    int numDelLen = 0;
    for(int i=0; i<(int)delCIDVec.size(); i++)
    {
        int cID = delCIDVec.at(i);
        bItem = bc->getBoundaryItem(cID-1);
        if (chunkLength == 0) sAnn = bItem->getStart(); 
             
        if( (i+1) == delCIDVec.size())
        {
            chunkLength +=  (bItem->getEnd() - bItem->getStart() + 1);
            numDelLen += chunkLength;
            numDel++;
            lengDelVec.push_back(chunkLength);
            
            chunkLength=0;
        } // end of if
        else if( delCIDVec.at(i+1) == (nSeq+cID)) 
        {
            chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
        } // end of else if
        else 
        {
            // check whether middle items between cID and nextcID are all gaps
            int nextId = delCIDVec.at(i + 1);
            int j = 0;
            for (j = cID + nSeq; j < nextId; j += nSeq)
            {
                vector<int>::iterator iter1 = find(pChunkIDVec->begin(), pChunkIDVec->end(), -j);
                vector<int>::iterator iter2 = find(cChunkIDVec->begin(), cChunkIDVec->end(), -j);
                if (iter1 == pChunkIDVec->end() || iter2 == cChunkIDVec->end()) break;
            } // end of for

            if (j == nextId)
            {
                // all middle items are gaps
                chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
            } // end of if
            else
            {
                chunkLength += (bItem->getEnd() - bItem->getStart() + 1);
                numDelLen += chunkLength;
                numDel++;
                lengDelVec.push_back(chunkLength);
                
                chunkLength=0;
                //cnt=0;
            } // end of else
        } // end of else  
    } // end of for
    
    int numNonIns = numMatMut + 1 + numDel - numIns;
    if (numNonIns < 0) numNonIns = 0;

    int numNonDel = numMatMut;
    if (numNonDel < 0) numNonDel = 0;

    double bLength = branchLength[bIndex];
	double prIns = constIns * bLength;
	double prDel =constDel * bLength;

	if (prIns != 0.0) totalScore += (log(prIns) * numIns);
	if ((1 - prIns) != 0.0) totalScore += (log(1 - prIns) * numNonIns);  

    for(int i=0; i<(int)lengInsVec.size(); i++)
    {
        int len = lengInsVec.at(i);
        if (lenDist == Param::LDIST_PS) 
            totalScore += log(Util::getLenProb(lenDist, len, insLenAvg, 0.0, 0.0));
        else if (lenDist == Param::LDIST_PL)
            totalScore += log(Util::getLenProb(lenDist, len, insLambda, insrzeta, 0.0));
        else if (lenDist == Param::LDIST_GM)
            totalScore += log(Util::getLenProb(lenDist, len, 0.0, 0.0, insProbSuccess));

    } // end of for

    if (prDel != 0.0) totalScore += (log(prDel) * numDel);
	if ((1 - prDel) != 0.0) totalScore += (log(1 - prDel) * numNonDel); 
    
    for(int i=0; i<(int)lengDelVec.size(); i++)
    {
        int len = lengDelVec.at(i);
        if (lenDist == Param::LDIST_PS) 
            totalScore += log(Util::getLenProb(lenDist, len, delLenAvg, 0.0, 0.0));
        else if (lenDist == Param::LDIST_PL)
            totalScore += log(Util::getLenProb(lenDist, len, delLambda, delrzeta, 0.0));
        else if (lenDist == Param::LDIST_GM)
            totalScore += log(Util::getLenProb(lenDist, len, 0.0, 0.0, delProbSuccess));
    } // end of for

    return totalScore;    
}

BestAnnotation SearchBest::findBestCandidate (PhyloTreeNodeEx* root, BoundaryChunk* bc, int startIndex)
{
    // find the best scored Indel Entry
    int bestIndex = 0;
    double bestScore = 0.0;
    int bestLeftIndex = 0;
    int bestRightIndex = 0;
    
    for (int i = 0; i < root->getIndelEntryVecSize(); i++)
    {
        IndelEntry* ie = root->getIndelEntryAt(i);

        
        if (i == 0 || ie->getScore() > bestScore)
        {
            bestIndex = i;
            bestScore = ie->getScore();
            bestLeftIndex = ie->getLeftChildEntryIndex();
            bestRightIndex = ie->getRightChildEntryIndex();
        } // end of if
    } // end of for
    root->setBestEntryIndex(bestIndex);

    BranchInfoSet bestBInfoSet;
    bestScore += root->getTotalSubstScore();
    
    int branchIndex = 1;
    aux_findBestCandidate(bc, root, bestLeftIndex, bestRightIndex, &branchIndex, &bestBInfoSet, startIndex);

    BestAnnotation scoreIA(bestScore, bestBInfoSet);
    return scoreIA;
}

void SearchBest::aux_findBestCandidate(BoundaryChunk* bc, PhyloTreeNodeEx* root, int bestLeftIndex, int bestRightIndex, int* bIndex, BranchInfoSet* bInfoSet, int startIndex)
{
    // calculate total length of root sequence
    int totalLen = 0;
    IndelEntry* pIE = root->getIndelEntryAt(root->getBestEntryIndex());
    vector<int>* pChunkIDVec = pIE->getChunkIdVec();
    for (int i = 0; i < pChunkIDVec->size(); i++)
    {
        int pIndex = pChunkIDVec->at(i);
        if(pIndex > 0)
        {
             BoundaryItem* tbi = bc->getBoundaryItem(pIndex);
             totalLen += (tbi->getEnd() - tbi->getStart() + 1);
        }
    } // end of for

    PhyloTreeNodeEx* leftNode = root->getLeftChild();
    PhyloTreeNodeEx* rightNode = root->getRightChild();

    int leftBIndex = *bIndex;
    IndelEntry* leftIE = leftNode->getIndelEntryAt(bestLeftIndex);
    leftNode->setBestEntryIndex(bestLeftIndex);
    
    BranchInfo bInfo = summaryIndelAnnotation(bc, leftBIndex, startIndex, pIE, leftIE);
    bInfoSet->addBranchInfo(leftBIndex, bInfo, totalLen);

    if(leftNode->getLeftChild() != NULL)
    {       
        (*bIndex) += 1;
        aux_findBestCandidate(bc, leftNode, leftIE->getLeftChildEntryIndex(), leftIE->getRightChildEntryIndex(), bIndex, bInfoSet, startIndex);
    }

    (*bIndex) += 1;
    int rightBIndex = *bIndex;
    IndelEntry* rightIE = rightNode->getIndelEntryAt(bestRightIndex);
    rightNode->setBestEntryIndex(bestRightIndex);
    
    bInfo = summaryIndelAnnotation(bc, rightBIndex, startIndex, pIE, rightIE);
    bInfoSet->addBranchInfo(rightBIndex, bInfo, totalLen);

    if(rightNode->getLeftChild() != NULL)
    {       
        (*bIndex) += 1;
        aux_findBestCandidate(bc, rightNode, rightIE->getLeftChildEntryIndex(), rightIE->getRightChildEntryIndex(), bIndex, bInfoSet, startIndex);
    }
}

BranchInfo SearchBest::summaryIndelAnnotation(BoundaryChunk* bc, int bIndex, int startIndex, IndelEntry* pEntry, IndelEntry* cEntry)
{
    BranchInfo bInfo;
    vector<int> insCIDVec;
    vector<int> delCIDVec;
    vector<int> lengInsVec;
    vector<int> lengDelVec;
    
    vector<int>* pChunkIDVec = pEntry->getChunkIdVec();
    vector<int>* cChunkIDVec = cEntry->getChunkIdVec();
    int numMatMut = 0;
    
    for(int i=0; i< (int)pChunkIDVec->size(); i++)
    {
        int pIndex = pChunkIDVec->at(i);
        int cIndex = cChunkIDVec->at(i);
        string tmpstr = "";

        BoundaryItem* tbi = bc->getBoundaryItem(abs(pIndex));
        int tlen = tbi->getEnd() - tbi->getStart() + 1;
        if(pIndex == cIndex && pIndex > 0)
        {
            numMatMut += tlen;
            string tmpstr2(tlen, 'N');
            tmpstr = tmpstr2;
        } // end of if
        else if (pIndex < 0 && cIndex > 0 && cIndex == -pIndex)
        {
            insCIDVec.push_back(cIndex);    // Insertion
            string tmpstr2(tlen, 'N');
            tmpstr = tmpstr2;
        } // end of else if
        else if (pIndex > 0 && cIndex < 0 && cIndex == -pIndex)
        {
            delCIDVec.push_back(pIndex);    // Deletion
            string tmpstr2(tlen, '-');
            tmpstr = tmpstr2;
        } // end of else if
        else
        {
            string tmpstr2(tlen, '-');
            tmpstr = tmpstr2;
        } // end of else if
        m_tmpSeqMap[bIndex] += tmpstr;
    } // end of for
    bInfo.addMatch(numMatMut);
    bInfo.addMisMatch(0);

    map<int, int>::iterator iter;
    
    if(insCIDVec.size() >0) sort( insCIDVec.begin(), insCIDVec.end() );
    if(delCIDVec.size() >0) sort( delCIDVec.begin(), delCIDVec.end() );

    int chunkLength = 0;
    int sAnn = 0;
    BoundaryItem* bItem = NULL;
    int numIns = 0;
    int numDel = 0;
    
    // process insertion vector
    for(int i=0; i<(int)insCIDVec.size(); i++)
    {
        int cID = insCIDVec.at(i);
        bItem = bc->getBoundaryItem(cID-1);
        
        if (chunkLength == 0) sAnn = bItem->getStart();

        if( (i+1) == insCIDVec.size())
        {
            numIns++;
            chunkLength +=  (bItem->getEnd() - bItem->getStart() + 1);
            lengInsVec.push_back(chunkLength);
            
            bInfo.addInsertion(chunkLength);
            AnnInfo aInfo(sAnn - startIndex, bItem->getEnd() - startIndex, PhyloTreeNode::INSERTION, chunkLength);
            bInfo.addAnnInfo(aInfo);

            chunkLength=0;
        }
        else if( insCIDVec.at(i+1) == (nSeq + cID)) 
        {
            chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
        }
        else 
        {
            // check whether middle items between cID and nextcID are all gaps
            int nextId = insCIDVec.at(i + 1);
            int j = 0;
            for (j = cID + nSeq; j < nextId; j += nSeq)
            {
                vector<int>::iterator iter1 = find(pChunkIDVec->begin(), pChunkIDVec->end(), -j);
                vector<int>::iterator iter2 = find(cChunkIDVec->begin(), cChunkIDVec->end(), -j);
                if (iter1 == pChunkIDVec->end() || iter2 == cChunkIDVec->end()) break;
            } // end of for

            if (j == nextId)
            {
                // all middle items are gaps
                chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
            } // end of if
            else
            {
                 numIns++;
                 chunkLength += (bItem->getEnd() - bItem->getStart() + 1);
                 lengInsVec.push_back(chunkLength);

                 bInfo.addInsertion(chunkLength);
                 AnnInfo aInfo(sAnn - startIndex, bItem->getEnd() - startIndex, PhyloTreeNode::INSERTION, chunkLength);
                 bInfo.addAnnInfo(aInfo);

                 chunkLength=0;
            } // end of else
        } // end of else  
    } // end of for

    // process deletion vector
    chunkLength = 0;
    sAnn = 0;
    int numDelLen = 0;
    for(int i=0; i<(int)delCIDVec.size(); i++)
    {
        int cID = delCIDVec.at(i);
        bItem = bc->getBoundaryItem(cID-1);
        if (chunkLength == 0) sAnn = bItem->getStart(); 
             
        if( (i+1) == delCIDVec.size())
        {
            chunkLength +=  (bItem->getEnd() - bItem->getStart() + 1);
            numDelLen += chunkLength;
            numDel++;
            lengDelVec.push_back(chunkLength);
            
            bInfo.addDeletion(chunkLength);
            AnnInfo aInfo(sAnn - startIndex, bItem->getEnd() - startIndex, PhyloTreeNode::DELETION, chunkLength);
            bInfo.addAnnInfo(aInfo);
            
            chunkLength=0;
        } // end of if
        else if( delCIDVec.at(i+1) == (nSeq+cID)) 
        {
            chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
        } // end of else if
        else 
        {
            // check whether middle items between cID and nextcID are all gaps
            int nextId = delCIDVec.at(i + 1);
            int j = 0;
            for (j = cID + nSeq; j < nextId; j += nSeq)
            {
                vector<int>::iterator iter1 = find(pChunkIDVec->begin(), pChunkIDVec->end(), -j);
                vector<int>::iterator iter2 = find(cChunkIDVec->begin(), cChunkIDVec->end(), -j);
                if (iter1 == pChunkIDVec->end() || iter2 == cChunkIDVec->end()) break;
            } // end of for

            if (j == nextId)
            {
                // all middle items are gaps
                chunkLength += (bItem->getEnd()- bItem->getStart() + 1);
            } // end of if
            else
            {
                chunkLength += (bItem->getEnd() - bItem->getStart() + 1);
                numDelLen += chunkLength;
                numDel++;
                lengDelVec.push_back(chunkLength);
                
                bInfo.addDeletion(chunkLength);
                AnnInfo aInfo(sAnn - startIndex, bItem->getEnd() - startIndex, PhyloTreeNode::DELETION, chunkLength);
                bInfo.addAnnInfo(aInfo);

                chunkLength=0;
            } // end of else
        } // end of else  
    } // end of for
    
    return bInfo;
}

// Added for the reconstruction component
int SearchBest::getNumOfSeq()
{
    return nSeq;
}

map<int, vector<int> >* SearchBest::getTreeMap()
{
    return treeMap;
}

int SearchBest::getRootNodeNum()
{
    return rootNodeIndex;
}

vector<string> SearchBest::getLeafSeqVec()
{
    return m_leafSeqVec;
}

vector<string> SearchBest::getAncSeqVec()
{
    return m_ancSeqVec;
}

double SearchBest::getParamU()
{
    return m_paramU;
}

void SearchBest::outputParameters()
{
    cout << "[Estimated parameter values]" << endl;
    cout << "constIns: " << constIns << endl;
    cout << "constDel: " << constDel << endl;
    cout << "F81param: " << m_paramU << endl;
    
    if (lenDist == Param::LDIST_PS)
    {
        cout << "Indel length distribution: Poisson" << endl;
        cout << "   Ins length average: " << insLenAvg << endl;
        cout << "   Del length average: " << delLenAvg << endl;
    } // end of if
    else if (lenDist == Param::LDIST_PL)
    {
        cout << "Indel length distribution: Power law" << endl;
        cout << "   Ins Exponent: " << insLambda << endl;
        cout << "   Ins Value of Riemann zeta function: " << insrzeta << endl;
        cout << "   Del Exponent: " << delLambda << endl;
        cout << "   Del Value of Riemann zeta function: " << delrzeta << endl; 
    } // end of else if
    else if (lenDist == Param::LDIST_GM)
    {
        cout << "Indel length distribution: Geometric" << endl;
        cout << "   Ins Prob. Success: " << insProbSuccess << endl;
        cout << "   Del Prob. Success: " << delProbSuccess << endl;
    } // end of if

    cout << "Nucleotides frequencies" << endl;
    cout << "   A: " << m_freqA << endl;
    cout << "   C: " << m_freqC << endl;
    cout << "   G: " << m_freqG << endl;
    cout << "   T: " << m_freqT << endl;

}

double SearchBest::getInitialAlign(string sFile, string aFile, string oFile1, string oFile2, string oFile3)
{
#ifdef DEBUG_OUTPUT
    cerr << "getInitialAlign function" << endl;
#endif
    map<int, BoundaryChunk>::iterator bcIter;
    for(bcIter = bestBChunkMap.begin(); bcIter != bestBChunkMap.end(); bcIter++)
    {
        int iaNum = bcIter->first;  // Inter-Anchor number
        BoundaryChunk bc = bcIter->second;  // Boundary chunk for the inter-anchor

#ifdef DEBUG_OUTPUT
        cerr << "\tInitial sequences" << endl;
        dumpBC(&bc);
#endif
	    int numCol = (int)(bc.getSeqVec())->at(0).length();  // total number of column
        vector<BestAnnotation> ba = findBestAnnotationHybrid(&bc, numCol, 0);
        bestBestScoreIAnchorMap[iaNum] = ba;
#ifdef DEBUG_OUTPUT        
        dumpAnnVec(&bc, &ba);
#endif
    } // end of for int i
    
    double newScore = getFinalScoreEx(&bestBestScoreIAnchorMap);
    return newScore;
}



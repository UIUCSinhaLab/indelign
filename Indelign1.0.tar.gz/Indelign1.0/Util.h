// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef UTIL_H
#define UTIL_H

#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <math.h>
#include <queue>
#include "TInterAnchor.h"
#include "Param.h"

using namespace std;

class TInterAnchor;

class NWTreeNode
{
private:
    NWTreeNode* m_leftChild;
    NWTreeNode* m_rightChild;
    NWTreeNode* m_parent;
    int m_nodeNum;
    string m_nodeName;
    double m_bLength;

public:
    NWTreeNode();
    ~NWTreeNode();
    void setLeftChild(NWTreeNode* leftChild);
    void setRightChild(NWTreeNode* rightChild);
    void setParent(NWTreeNode* parent);
    NWTreeNode* getLeftChild();
    NWTreeNode* getRightChild();
    NWTreeNode* getParent();
    int getNodeNum();
    string getNodeName();
    double getBLength();
    void setBLength(double len);
    void setNodeNum(int num);
    void setNodeName(string name);
    void dump();
};

class Util 
{
public:
    static queue<int> seqQ;
    static map<int, queue<int> > gapQMap;

public:
    static Param parseTreeEx(string parFile, string* strTree, map<int, vector<int> >* treeMap, map<int, double>* bLenMap, int* n, map<int, string>* nodeNameMap);
    static int getSubstScore(char b1, char b2);
    static double getLenProb(int type, int value, double lamda, double rzeta, double p);

    static void seqQueueInit(int nSeq);
    static int getRoundRobinSeqNum();
    static int getRoundRobinGapNum(int sindex, int gapCnt);
    static string trim(string str);
    static double substProb(char fromCh, char toCh, double t, double u, double pi);
    static double getIndelAgreement(int numInsTrue, int numIns, int numDelTrue, int numDel);
    static double getIndelRatio(int numInsTrue, int numIns, int numDelTrue, int numDel);
    static string aux_parseTree(string strTree, map<int, vector<int> >* treeMap, int* n);
    static string aux_parseTreeEx(NWTreeNode* pNode, string strTree, int* offset, map<int, vector<int> >* treeMap, int* n, int* leafNum);
    static string toUpper(string str);

private:
    static double poissonDist(int value, double mean);
    static double geometricDist(int value, double p);
    static double powerlawDist(int value, double lamda, double rzeta);
    static void freeMemory(NWTreeNode* pNode);
    static void extractTreeInfo(NWTreeNode* pNode, int* bNum, map<int, vector<int> >* treeMap, map<int, double>* bLenMap, map<int, string>* nodeNameMap);
};

#endif

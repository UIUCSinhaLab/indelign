// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef SEQGEN_H
#define SEQGEN_H

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "Util.h"
#include "rand.h"
#include "TInterAnchor.h"

using namespace std;

class SeqInfo
{
private:
    string m_seq;   // sequence string
    int m_startIndexOfChange;   
    int m_endIndexOfChange;

public:
    SeqInfo();
    SeqInfo(string str, int sIndex, int eIndex);
    SeqInfo(const SeqInfo& sInfo);
    ~SeqInfo();

    string getSeq();
    int getStartIndexOfChange();
    int getEndIndexOfChange();
};

class SeqGen {

private:
	string orgSeq;
	vector<string> strVec;  
	int seqIndex;   // start from 0

	int residueCnt;
	int gapCnt;
	string residue;
	vector<int> gapLength;
	vector<int> gapStartIndex;
	

public:
	SeqGen(); // default constructor
	SeqGen(string originalSeq);   
	SeqGen(string bMap,string originalSeq, int sIndex);   
	~SeqGen(); // default destructor
	vector<string> combGen();
	vector<string> approxCombGen();
    vector<SeqInfo> approxCombGen(int numShift, TInterAnchor* tAnchor, int iaNum);

    int getGapCnt();

private:
	void seqGen(int residuePtr,int gapPtr,string currentString);
};

#endif

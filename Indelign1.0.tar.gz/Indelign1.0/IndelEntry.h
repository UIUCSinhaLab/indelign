// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef INDELENTRY_H
#define INDELENTRY_H

#include <iostream>
#include <vector>
#include "BranchInfo.h"

using namespace std;

class IndelEntry
{
private:
    vector<int> m_vecChunkId;    // Negative: gap, Positive: starred block
    double m_score;             // score of this enrty
    int m_leftChildEntryIndex;  // index of a left child's table
    int m_rightChildEntryIndex; // index of a right child's table

public:
    IndelEntry();
    IndelEntry(IndelEntry* ie);
    ~IndelEntry();

    double getScore();
    int getLeftChildEntryIndex();
    int getRightChildEntryIndex();
    vector<int>* getChunkIdVec();
    int getChunkIdAt(int index);
    int getChunkIdVecSize();

    void setScore(double scr);
    void setLeftChildEntryIndex(int index);
    void setRightChildEntryIndex(int index);
    void addChunkId(int ckId);

    void dump();
};

#endif

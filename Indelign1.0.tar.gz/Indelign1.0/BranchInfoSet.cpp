// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "BranchInfoSet.h"

BranchInfoSet::BranchInfoSet()
{
    
}

BranchInfoSet::~BranchInfoSet()
{

}

BranchInfo* BranchInfoSet::getBranchInfoAt(int bNum)
{
        map<int, BranchInfo>::iterator iter = branchMap.find(bNum);
        if (iter == branchMap.end()) return NULL;
	return &(branchMap[bNum]);
}

void BranchInfoSet::addBranchInfo(int bNum, BranchInfo bInfo, int len)
{
    branchMap[bNum] = bInfo;
    parentSeqLenMap[bNum] = len;
}

void BranchInfoSet::addBranchInfo(int bNum, BranchInfo bInfo)
{
    branchMap[bNum] = bInfo;
}

int BranchInfoSet::getParentSeqLenAt(int bNum)
{
    return parentSeqLenMap[bNum];
}

void BranchInfoSet::addParentSeqLenMap(map<int, int>* lenMap)
{
    map<int, int>::iterator iter;
    for (iter = lenMap->begin(); iter != lenMap->end(); iter++)
    {
        map<int, int>::iterator iter2 = parentSeqLenMap.find(iter->first);
        if (iter2 == parentSeqLenMap.end()) 
            parentSeqLenMap[iter->first] = iter->second;
        else
            parentSeqLenMap[iter->first] += iter->second;
    } // end of for
}
  
map<int, int>* BranchInfoSet::getParentSeqLenMap()
{
    return &parentSeqLenMap;
}

// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "NodeScoreMatrix.h"

SelectedChildBase::SelectedChildBase()
{

}

SelectedChildBase::SelectedChildBase(const SelectedChildBase& scBase)
{
    leftBase = scBase.leftBase;
    rightBase = scBase.rightBase;
}

SelectedChildBase::~SelectedChildBase()
{

}

NodeScoreMatrix::NodeScoreMatrix()
{
  scoreMatrix['A'] = 0.0;
  scoreMatrix['C'] = 0.0;
  scoreMatrix['G'] = 0.0;
  scoreMatrix['T'] = 0.0;
}

NodeScoreMatrix::NodeScoreMatrix(const NodeScoreMatrix& nsMat)   // copy constructor
{
   scoreMatrix = nsMat.scoreMatrix;
}

NodeScoreMatrix::~NodeScoreMatrix()
{
    scoreMatrix.clear();
    map<char, double>().swap(scoreMatrix);
}

double NodeScoreMatrix::getScore(char nucleo)
{
  
  return scoreMatrix[nucleo];
}

void NodeScoreMatrix::setScore(char nucleo, double score)
{
    if (nucleo == 'N') return;
    scoreMatrix[nucleo] = score;
}

double NodeScoreMatrix::getProb(char nucleo)
{
  
  return scoreMatrix[nucleo];
}

void NodeScoreMatrix::setProb(char nucleo, double score)
{
    if (nucleo == 'N') return;
  scoreMatrix[nucleo] = score;
}

char NodeScoreMatrix::getBestLabel()
{
    map<char, double>::iterator iter;
    char bestCh = 'A';
    double bestScore = (double)NodeScoreMatrix::MAX_EVENT;
    for (iter = scoreMatrix.begin(); iter != scoreMatrix.end(); iter++)
    {
        char ch = iter->first;
        double score = iter->second;
        if (score < bestScore)
        {
            bestCh = ch;
            bestScore = score;
        } // end of if
    }
    return bestCh;
}

NodeScoreMatrixPrev::NodeScoreMatrixPrev()
{
  finishScoring = false; 
  scoreMatrix['A'] = 0.0;
  scoreMatrix['C'] = 0.0;
  scoreMatrix['G'] = 0.0;
  scoreMatrix['T'] = 0.0;
}

NodeScoreMatrixPrev::NodeScoreMatrixPrev(const NodeScoreMatrixPrev& nsMat)   // copy constructor
{
   scoreMatrix = nsMat.scoreMatrix;
   finishScoring = nsMat.finishScoring;

   map<char, SelectedChildBase*>::const_iterator iter;
   for (iter = nsMat.childBaseMap.begin(); iter != nsMat.childBaseMap.end(); iter++)
   {
        SelectedChildBase* scBase = new SelectedChildBase();
        scBase->leftBase = iter->second->leftBase;
        scBase->rightBase = iter->second->rightBase;
        childBaseMap[iter->first] = scBase;
   } // end of for
}

NodeScoreMatrixPrev::~NodeScoreMatrixPrev()
{
    scoreMatrix.clear();
    map<char, double>().swap(scoreMatrix);

    map<char, SelectedChildBase*>::iterator iter;
    for (iter = childBaseMap.begin(); iter != childBaseMap.end(); iter++)
        delete iter->second;
    childBaseMap.clear();
    map<char, SelectedChildBase*>().swap(childBaseMap);
}

double NodeScoreMatrixPrev::getScore(char nucleo)
{
  
  return scoreMatrix[nucleo];
}

void NodeScoreMatrixPrev::setScore(char nucleo, double score)
{
  scoreMatrix[nucleo] = score;
}

double NodeScoreMatrixPrev::getProb(char nucleo)
{
  
  return scoreMatrix[nucleo];
}

void NodeScoreMatrixPrev::setProb(char nucleo, double score)
{
  scoreMatrix[nucleo] = score;
}

bool NodeScoreMatrixPrev::getFinishScoring()
{
  return finishScoring; 
}

void NodeScoreMatrixPrev::setFinishScoring()
{
   finishScoring =true;
}

char NodeScoreMatrixPrev::getSelectedLeftBase(char left)
{
    map<char, SelectedChildBase*>::iterator iter;
    iter = childBaseMap.find(left);
    assert (iter != childBaseMap.end());
    return iter->second->leftBase;
}

void NodeScoreMatrixPrev::setSelectedLeftBase(char nucleo, char left)
{
    map<char, SelectedChildBase*>::iterator iter;
    iter = childBaseMap.find(nucleo);
    if (iter == childBaseMap.end())
    {
        // If the object does not exist, make new one and store it in the map
        SelectedChildBase* scBase = new SelectedChildBase();
        childBaseMap[nucleo] = scBase;
    } // end of if

    childBaseMap[nucleo]->leftBase = left; 
}

char NodeScoreMatrixPrev::getSelectedRightBase(char right)
{
    map<char, SelectedChildBase*>::iterator iter;
    iter = childBaseMap.find(right);
    assert (iter != childBaseMap.end());
    return iter->second->rightBase;
}


void NodeScoreMatrixPrev::setSelectedRightBase(char nucleo, char right)
{
    map<char, SelectedChildBase*>::iterator iter;
    iter = childBaseMap.find(nucleo);
    if (iter == childBaseMap.end())
    {
        // If the object does not exist, make new one and store it in the map
        SelectedChildBase* scBase = new SelectedChildBase();
        childBaseMap[nucleo] = scBase;
    } // end of if
    
    childBaseMap[nucleo]->rightBase = right;
}

char NodeScoreMatrixPrev::getBestLabel()
{
    map<char, double>::iterator iter;
    char bestCh = 'A';
    double bestScore = (double)NodeScoreMatrix::MAX_EVENT;
    for (iter = scoreMatrix.begin(); iter != scoreMatrix.end(); iter++)
    {
        char ch = iter->first;
        double score = iter->second;
        if (score < bestScore)
        {
            bestCh = ch;
            bestScore = score;
        } // end of if
    }
    return bestCh;
}



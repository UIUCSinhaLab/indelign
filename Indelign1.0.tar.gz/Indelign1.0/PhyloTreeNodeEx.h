// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef PHYLOTREENODEEX_H
#define PHYLOTREENODEEX_H

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <assert.h>
#include "NodeScoreMatrix.h"
#include "NodeScoreMatrixSet.h"
#include "PhyloTreeNode.h"
#include "BranchInfoSet.h"
#include "AnnInfoSet.h"
#include "IndelEntry.h"

using namespace std;

// Represent an information for the substitution for each chunkID in the tree node
class SubstInfo
{
private:
    bool m_bFix;    // Whether or not to fix this chunk to not-gap
    NodeScoreMatrixSet* m_nsMatSet;  // Substitution score for each nucleotide in this chunk
    bool m_bLeftStar;   // Whether or not left descendents have a non-gap
    bool m_bRightStar;  // Whether or not right descendents have a non-gap

public:
    SubstInfo();    // default constructor
    SubstInfo(NodeScoreMatrixSet* nsMatSet);
    ~SubstInfo();   // default destructor

    bool isFixed();
    bool isLeftStar();
    bool isRightStar();
    NodeScoreMatrixSet* getNodeScoreMatrixSet();
    void removeNodeScoreMatrix();

    void setFixed();
    void setLeftStar();
    void setRightStar();
    void setNodeScoreMatrixSet(NodeScoreMatrixSet* nsMatSet);

    void dump();
};

class PhyloTreeNodeEx
{
private:
    // Pointers to children and parent
    PhyloTreeNodeEx* leftChild;       // left child of this node
    PhyloTreeNodeEx* rightChild;      // right child of this node
    vector<IndelEntry*> m_vecIndelEntry;
    int m_bestEntryIndex;

    // information from substitution for each chunkID in this node
    vector<SubstInfo*> substInfoVec;
    vector<double> substScoreVec;
    double totalSubstScore;

public:
    // Default constructor
    PhyloTreeNodeEx();
    // Destructor
    ~PhyloTreeNodeEx();

    void setLeftChild(PhyloTreeNodeEx* pNode);
    void setRightChild(PhyloTreeNodeEx* pNode);
    PhyloTreeNodeEx* getLeftChild();
    PhyloTreeNodeEx* getRightChild();

    void setBestEntryIndex(int index);
    int getBestEntryIndex();
    void addIndelEntry(IndelEntry* ie);
    IndelEntry* getIndelEntryAt(int index);
    int getIndelEntryVecSize();

    void dump();

    void addSubstInfo(SubstInfo* subInfo);
    SubstInfo* getSubstInfoAt(int index);
    void compactSubstInfoVec();
    int getSubstInfoVecSize();
    
    void addSubstScore(double scr);
    double getSubstScoreAt(int index);
    int getSubstScoreVecSize();
    double getTotalSubstScore();
    void setSubstScore(vector<double>* scrVec);
};

class BestAnnotation
{
private:
    double score;   // score of current annotation of the tree
    BranchInfoSet bInfoSet;
    int m_startColIndex;  // start column index
    int m_endColIndex;    // end column index

public:
    BestAnnotation();   // default constructor
    BestAnnotation(double scr, BranchInfoSet biSet);
    BestAnnotation(const BestAnnotation& ann); // copy constructor
    ~BestAnnotation();  // default destructor
    double getScore();
    BranchInfoSet* getBranchInfoSet(); 
    int getStartColIndex();
    int getEndColIndex();
    void setStartColIndex(int col);
    void setEndColIndex(int col);
};

#endif

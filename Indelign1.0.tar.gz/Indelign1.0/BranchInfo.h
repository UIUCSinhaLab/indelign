// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef BRANCHINFO_H
#define BRANCHINFO_H

#include <iostream>
#include <vector>
#include "AnnInfoSet.h"
#include "PhyloTreeNode.h"

using namespace std;

class BranchInfo
{
private:
    int numOfMisMatch;  // total number of mismatch in this branch
    int numOfMatch;     // total number of match in this branch
    vector<int> insVec; // store each length of insertion in this branch
                        // the size of this vector is the total number of insertion

    vector<int> delVec; // store each length of deletion in this branch
                        // the size of this vector is the total number of deletion

	vector<AnnInfo> annInfoVec; // Store start and end index of each indel

public:
    BranchInfo();   // Default constructor
    //BranchInfo(const BranchInfo& bInfo);
    BranchInfo(BranchInfo* bInfo);
    ~BranchInfo();  // Default destructor

    int getNumOfMisMatch();
    int getNumOfMatch();
    int getNumOfInsertion();
    int getNumOfDeletion();
    int getNumOfNonInsertion();
    int getNumOfNonDeletion();
    int getTotalLenOfIns();
    int getTotalLenOfDel();

    void addMisMatch(int nMat);
    void addMatch(int nMat);
    void addInsertion(int len);
    void addDeletion(int len);
	void addInsertion(int sIndex, int len);
    void addDeletion(int sIndex, int len);
    void addAnnInfo(AnnInfo aInfo);

    vector<int>* getInsLenVec();
    vector<int>* getDelLenVec();

    vector<int> getInsLenVecValue();
    vector<int> getDelLenVecValue();
    vector<AnnInfo>* getAnnInfoVec();

    void clear();
};

#endif

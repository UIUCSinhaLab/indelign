// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef PHYLOTREENODE_H
#define PHYLOTREENODE_H

#include <iostream>
#include "NodeScoreMatrix.h"

using namespace std;

class PhyloTreeNode
{
private:
    char base;  // nucleotide(A,T,G,C) or gap(-) at this node
    PhyloTreeNode* leftChild;       // left child of this node
    PhyloTreeNode* rightChild;      // right child of this node
    PhyloTreeNode* parent;          // parent of this node
    int leftBranchAnn;              // annotation of left branch
    int rightBranchAnn;             // annotation of right branch
                                    // can be MATCH, MISMATCH, INSERTION, DELETION

    NodeScoreMatrixPrev scoreMat;      // score matrix for this node

public:
    const static int MATCH = 1;       // match
    const static int MISMATCH = 2;    // mismatch
    const static int INSERTION = 3;   // insertion
    const static int DELETION = 4;    // deletion
    const static int NODELETION = 5;    // no deletion
    const static int NOEVENT = 6;    // no event

    // Default constructor
    PhyloTreeNode();
    // Copy constructor
    PhyloTreeNode(const PhyloTreeNode& node);
    // Destructor
    ~PhyloTreeNode();

    void setLeftChild(PhyloTreeNode* pNode);
    void setRightChild(PhyloTreeNode* pNode);
    void setParent(PhyloTreeNode* pParent);
    PhyloTreeNode* getLeftChild();
    PhyloTreeNode* getRightChild();
    PhyloTreeNode* getParent();

    void setBase(char ch);
    char getBase();
    int getLeftBranchAnnotation();
    int getRightBranchAnnotation();
    void setLeftBranchAnnotation(int anno);
    void setRightBranchAnnotation(int anno);

    // methods for node score matrix
    double getScore(char base);
    void setScore(char base, double score);
    char getSelectedLeftBase(char left);
    void setSelectedLeftBase(char parent, char left);
    char getSelectedRightBase(char right);
    void setSelectedRightBase(char parent, char right);
    void setFinishScoring();
    bool getFinishScoring();

    void dump();

    // For reconstruction parts
    double getScoreRecon(char base);
    double getScoreReconMLDP(char base);
};

#endif

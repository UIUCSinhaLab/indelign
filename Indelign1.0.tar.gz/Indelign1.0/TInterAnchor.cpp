// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "TInterAnchor.h"
#include "SearchBest.h"
#include <fstream>
#include <math.h>

TInterAnchor::TInterAnchor()
{
	constMut = constIns = constDel = 0.0;
    numColumn = 0;
	sumOfLenSquare = 0.0;
	totalScore = 0.0;
    insLenAvg = delLenAvg = 0.0;
    insLambda = delLambda = 0.0;
    insProbSuccess = delProbSuccess = 0.0;
    insrzeta = delrzeta = 0.0;
    diffLenDist = false;
    lenDist = 0;
    m_numA = 0;
    m_numC = 0;
    m_numG = 0;
    m_numT = 0;
    m_freqA = 0.0;
    m_freqC = 0.0;
    m_freqG = 0.0;
    m_freqT = 0.0;
    m_paramU = 0.0;
    includeAnchor = true;
    m_useTrueIndel = false;
    anchorBranchInfo = NULL;

    readAnchorStat();
}

TInterAnchor::TInterAnchor(string name, int num, int numB, map<int, double> bLenMap, int ldist, bool dlen, bool iAnchor, bool useTrueIndel, map<int, vector<int> >* tMap, int rIndex, string aFile, map<int, string>* nameMap)
{
	constMut = constIns = constDel = 0.0;
    numColumn = 0;
	sumOfLenSquare = 0.0;
	totalScore = 0.0;
    insLenAvg = delLenAvg = 0.0;
    insLambda = delLambda = 0.0;
    insProbSuccess = delProbSuccess = 0.0;
    insrzeta = delrzeta = 0.0;
    diffLenDist = dlen;
 
    m_numA = 0;
    m_numC = 0;
    m_numG = 0;
    m_numT = 0;
    m_freqA = 0.0;
    m_freqC = 0.0;
    m_freqG = 0.0;
    m_freqT = 0.0;
    m_paramU = 0.0;
    includeAnchor = iAnchor;
    m_useTrueIndel = useTrueIndel;
    treeMap = tMap;
    nodeNameMap = nameMap;
    rootNodeIndex = rIndex;
    anchorBranchInfo = NULL;
    
    anchorFile = aFile;
    lenDist = ldist;
	fileName = name;
	nSeq = num;
    numBranch = numB;
    branchLength = bLenMap;
    sumBranchLength();
    makeParentNodeMap();

    readAnchorStat();
    if (m_useTrueIndel == true) readTrueIndexCnt();
    makeInterAnchor();
    findSubAnchors();
}

TInterAnchor::~TInterAnchor()
{
	// free memory
	for (int i = 0; i < (int)branchSummary.size(); i++)
	{
		TotalBranch* tBranch = branchSummary.at(i);
		free(tBranch);
	} // end of for

    delete[] m_subNumArrayAnchor;
    if (anchorBranchInfo != NULL) delete anchorBranchInfo;
}

void TInterAnchor::makeInterAnchor()
{
	ifstream infile(fileName.c_str());
	string line;
	vector<string> seqVec;

    m_numA = 0;
    m_numC = 0;
    m_numG = 0;
    m_numT = 0;
    m_freqA = 0.0;
    m_freqC = 0.0;
    m_freqG = 0.0;
    m_freqT = 0.0;

	if(infile.is_open())
	{
        bool bReady = false;
	  while(!infile.eof())
	  {
	    	getline(infile,line);
		if(line.length() != 0){
            line = Util::toUpper(line);
			seqVec.push_back(line);
            bReady = true;

            // count nucleotides frequency
            for (int i = 0; i < line.length(); i++)
            {
                char ch = line.at(i);
                if (ch == 'A') m_numA++;
                else if (ch == 'C') m_numC++;
                else if (ch == 'G') m_numG++;
                else if (ch == 'T') m_numT++;
            } // end of for
		}		
		// whenever reading the 1 interanchor, add the wholeInAnchor
		else{ 
            if (bReady == true)
            {
                InterAnchor iAnchor(nSeq);
			    iAnchor.setSequence(seqVec);
			    wholeInAnchor.push_back(iAnchor);
			// store number of columns
			numColumn += iAnchor.getColumnNumber();
			    seqVec.clear();
                vector<string>().swap(seqVec);
                bReady = false;

				// store summary structore for current inter-anchor
				TotalBranch* tBranch = new TotalBranch(numBranch);
				branchSummary.push_back(tBranch);
            }
		}
	  }
	infile.close();
	}
}

void TInterAnchor::dump()
{
	for (int i = 0; i < (int)wholeInAnchor.size(); i++)
	{
		cerr << "InterAnchor " << i + 1 << endl;
		InterAnchor ia = wholeInAnchor.at(i);
		ia.dump();

		if (i < (int)wholeInAnchor.size() - 1)
			cerr << endl;
	}
    
    cerr << "Ingroup sequence numbers: ";
    for (int i = 0; i < (int)ingroupSeqNumVec.size(); i++)
        cerr << ingroupSeqNumVec.at(i) << " ";
    cerr << endl;
}

int TInterAnchor::getNumOfInterAnchor()
{
    return (int)wholeInAnchor.size();
}

InterAnchor* TInterAnchor::getInterAnchorAt(int index)
{
    return &(wholeInAnchor.at(index));
}

double TInterAnchor::getScore()
{
	// estimate parameters using current summary of tree branches
	estimateParameters();
	totalScore = 0.0;
	for (int bIndex = 1; bIndex <= numBranch; bIndex++)
	{
		vector<double> numVec = tbMap[bIndex];
        double numMat = numVec.at(0);
		double numMut = numVec.at(1);
		double numIns = numVec.at(2);
        double numNonIns = numVec.at(3);
		double numDel = numVec.at(4);
        double numNonDel = numVec.at(5);
        
		vector<double> prVec = prMap[bIndex];
		double prMut = prVec.at(0);
		double prIns = prVec.at(1);
		double prDel = prVec.at(2);
        // log score version
		if (prMut != 0.0) totalScore += (log(prMut) * numMut);
		if ((1 - prMut) != 0.0) totalScore += (log(1 - prMut) * numMat);
		
		if (prIns != 0.0) totalScore += (log(prIns) * numIns);
		if ((1 - prIns) != 0.0) totalScore += (log(1 - prIns) * numNonIns);
		if (numIns != 0.0)
        {
            vector<int> insLenVec = bInsLenMap[bIndex];

            for (int i = 0; i < (int)insLenVec.size(); i++)
            {
                double dist = 0.0;
                if (lenDist == Param::LDIST_PS) 
                    dist = Util::getLenProb(lenDist, insLenVec.at(i), insLenAvg, 0.0, 0.0);
                else if (lenDist == Param::LDIST_PL)
                    dist = Util::getLenProb(lenDist, insLenVec.at(i), insLambda, insrzeta, 0.0);
                else if (lenDist == Param::LDIST_GM)
                    dist = Util::getLenProb(lenDist, insLenVec.at(i), 0.0, 0.0, insProbSuccess);

                
                if (dist != 0.0) totalScore += log(dist);
            } // end of for

        } // end of if
		
		if (prDel != 0.0) totalScore += (log(prDel) * numDel);
		if ((1 - prDel) != 0.0) totalScore += (log(1 - prDel) * numNonDel);
		if (numDel != 0.0)
        {

            vector<int> delLenVec = bDelLenMap[bIndex];

            for (int i = 0; i < (int)delLenVec.size(); i++)
            {
                double dist = 0.0; //Util::getLenProb(Param::LDIST_PS, delLenVec.at(i), delLenAvg, 0.0); 
                if (lenDist == Param::LDIST_PS) 
                    dist = Util::getLenProb(lenDist, delLenVec.at(i), delLenAvg, 0.0, 0.0);
                else if (lenDist == Param::LDIST_PL)
                    dist = Util::getLenProb(lenDist, delLenVec.at(i), delLambda, delrzeta, 0.0);
                else if (lenDist == Param::LDIST_GM)
                    dist = Util::getLenProb(lenDist, delLenVec.at(i), 0.0, 0.0, delProbSuccess);
                if (dist != 0.0) totalScore += log(dist);
            } // end of for

        } // end of if
	} // end of for bIndex

    return totalScore;
}

void TInterAnchor::estimateParameters()
{
    constMut = 0.0;
    constIns = 0.0;
    constDel = 0.0;

    // estimate constMat
    double sumMut = 0.0;
    double sumIns = 0.0;
    double sumDel = 0.0;

    double N = numColumn;
    double matN = 0.0;
    double mutN = 0.0;
    double insN = 0.0;
    double delN = 0.0;

	// summation of all number of match, insertion and deletion 
	prMap.clear();
    map<int, vector<double> >().swap(prMap);
	tbMap.clear();
    map<int, vector<double> >().swap(tbMap);
    bInsLenMap.clear();
    map<int, vector<int> >().swap(bInsLenMap);
    bDelLenMap.clear();
    map<int, vector<int> >().swap(bDelLenMap);
	for (int bIndex = 1; bIndex <= numBranch; bIndex++)
	{
		vector<double> numVec;
        int numMat = 0;
		int numMut = 0;
		int numIns = 0;
        int numNonIns = 0;
		int numDel = 0;
        int numNonDel = 0;
        vector<int> insLenVec;
        vector<int> delLenVec;
		for (int i = 0; i < (int)branchSummary.size(); i++)
		{
			TotalBranch* tBranch = branchSummary.at(i);
			BranchInfo* bInfo = tBranch->getBranchInfoAt(bIndex);
   		    numMat += bInfo->getNumOfMatch();
			numMut += bInfo->getNumOfMisMatch();
			numIns += bInfo->getNumOfInsertion();
			numDel += bInfo->getNumOfDeletion();
            vector<int>* pVec = bInfo->getInsLenVec();
            for (int vi = 0; vi < (int)pVec->size(); vi++)
                insLenVec.push_back(pVec->at(vi));  

            pVec = bInfo->getDelLenVec();
            for (int vi = 0; vi < (int)pVec->size(); vi++)
                delLenVec.push_back(pVec->at(vi));  
		} // end of for i

            numMat += m_anchorVec.at(0).length();
            
        numNonIns = numMat + numMut + 1 + numDel - numIns;
        numNonDel = numMat + numMut;

        numVec.push_back((double)numMat);
		numVec.push_back((double)numMut);
		numVec.push_back((double)numIns);
        numVec.push_back((double)numNonIns);
		numVec.push_back((double)numDel);
        numVec.push_back((double)numNonDel);
       

		tbMap[bIndex] = numVec;
        bInsLenMap[bIndex] = insLenVec;
        bDelLenMap[bIndex] = delLenVec;

	} // end of for bIndex

	// calculate sum
	for (int bIndex = 1; bIndex <= numBranch; bIndex++)
	{
		vector<double> numVec = tbMap[bIndex];
        double numMat = numVec.at(0);
		double numMut = numVec.at(1);
		double numIns = numVec.at(2);
        double numNonIns = numVec.at(3);
		double numDel = numVec.at(4);
        double numNonDel = numVec.at(5);

        double prMut = 0.0;
		double prIns = numIns / (numIns + numNonIns);
		double prDel = numDel / (numDel + numNonDel);

		vector<double> prVec;
		prVec.push_back(prMut);
		prVec.push_back(prIns);
		prVec.push_back(prDel);
		prMap[bIndex] = prVec;

#ifdef DEBUG_OUTPUT
// dump code
cerr << endl;
cerr << "Branch number:" << bIndex << endl;
cerr << "    Number of Match:" << numMat << endl;
cerr << "    Number of MisMatch:" << numMut << endl;
cerr << "    Number of Insertion:" << numIns << endl;
cerr << "    Number of NonInsertion:" << numNonIns << endl;
cerr << "    Number of Deletion:" << numDel << endl;
cerr << "    Number of NonDeletion:" << numNonDel << endl;
#endif
	} // end of for bIndex

    // calculate indel length distribution parameter
    if (lenDist == Param::LDIST_PS)
    {
        insLenAvg = delLenAvg = 0.0;
        int numIndel = 0;
        int numIns = 0;
        int numDel = 0;
        for (int bIndex = 1; bIndex <= numBranch; bIndex++)
        {
            vector<int> insLenVec = bInsLenMap[bIndex];
            numIns += insLenVec.size();
            for (int i = 0; i < (int)insLenVec.size(); i++) insLenAvg += insLenVec.at(i);

            vector<int> delLenVec = bDelLenMap[bIndex];
            numDel += delLenVec.size();
            for (int i = 0; i < (int)delLenVec.size(); i++) delLenAvg += delLenVec.at(i);
        } // end of for

        if (diffLenDist == false)
        {
            double lenAvg = insLenAvg + delLenAvg;
            if (numIns + numDel != 0) lenAvg = lenAvg / (numIns + numDel);
            insLenAvg = delLenAvg = lenAvg;
        } // end of if
        else
        {
            if (numIns != 0) insLenAvg /= numIns;
            if (numDel != 0) delLenAvg /= numDel;
        } // end of else
        
    } // end of if
    else if (lenDist == Param::LDIST_PL)
    {
        map<int, int> tmpLenMap;
        map<int, int> tmpInsLenMap;
        map<int, int> tmpDelLenMap;
        map<int, int>::iterator tmpIter;
        int numIns = 0;
        int numDel = 0;

        for (int bIndex = 1; bIndex <= numBranch; bIndex++)
        {
            vector<int> insLenVec = bInsLenMap[bIndex];
            numIns += insLenVec.size();
            for (int i = 0; i < (int)insLenVec.size(); i++)
            {
                int len = insLenVec.at(i);
                tmpIter = tmpLenMap.find(len);
                if (tmpIter == tmpLenMap.end())
                {
                    tmpLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpLenMap[len])++;
                } // end of else
                tmpIter = tmpInsLenMap.find(len);
                if (tmpIter == tmpInsLenMap.end())
                {
                    tmpInsLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpInsLenMap[len])++;
                } // end of else
            } // end of for

            vector<int> delLenVec = bDelLenMap[bIndex];
            numDel += delLenVec.size();
            for (int i = 0; i < (int)delLenVec.size(); i++)
            {
                int len = delLenVec.at(i);
                tmpIter = tmpLenMap.find(len);
                if (tmpIter == tmpLenMap.end())
                {
                    tmpLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpLenMap[len])++;
                } // end of else
                tmpIter = tmpDelLenMap.find(len);
                if (tmpIter == tmpDelLenMap.end())
                {
                    tmpDelLenMap[len] = 1;
                } // end of if
                else
                {
                    (tmpDelLenMap[len])++;
                } // end of else
            } // end of for
        } // end of for

        if (diffLenDist == false)
        {
            // calculate power law parameter
            // code from Dawg tool
            double sx = 0.0;
            double sx2 = 0.0;
            double sxy = 0.0;
            double sy = 0.0;
            double n = 5;
            if (tmpLenMap.size() < 5) n = tmpLenMap.size();
    
            double numgaps = 0.0;
            tmpIter = tmpLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                numgaps += tmpIter->second;
                tmpIter++;
            } // end of for
    
            tmpIter = tmpLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                double x = log((double)tmpIter->first);
                double y = log((double)tmpIter->second);
                sx += x;
                sy += y;
                sxy += x * y;
                sx2 += x * x;
                tmpIter++;
            } // end of for
    
            insLambda = -(n * sxy - sx * sy) / (n * sx2 - sx * sx);
            delLambda = insLambda;
            tmpIter = tmpLenMap.end();
            tmpIter--;
            double maxLen = tmpIter->first;
    
            insrzeta = delrzeta = 0.0;
            double d = 0.0;
                for(unsigned long u = 1;u<=(int)maxLen;++u)
                {
                        d = pow((double)u, -insLambda);
                        insrzeta += d;
                } // end of for
            delrzeta = insrzeta;
        } // end of if
        else
        {
            // For insertions
            double sx = 0.0;
            double sx2 = 0.0;
            double sxy = 0.0;
            double sy = 0.0;
            double n = 5;
            if (tmpInsLenMap.size() < 5) n = tmpInsLenMap.size();
    
            double numgaps = 0.0;
            tmpIter = tmpInsLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                numgaps += tmpIter->second;
                tmpIter++;
            } // end of for
    
            tmpIter = tmpInsLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                double x = log((double)tmpIter->first);
                double y = log((double)tmpIter->second);
                sx += x;
                sy += y;
                sxy += x * y;
                sx2 += x * x;
                tmpIter++;
            } // end of for
    
            insLambda = -(n * sxy - sx * sy) / (n * sx2 - sx * sx);
            tmpIter = tmpInsLenMap.end();
            tmpIter--;
            double maxLen = tmpIter->first;
    
            insrzeta = 0.0;
            double d = 0.0;
                for(unsigned long u = 1;u<=(int)maxLen;++u)
                {
                        d = pow((double)u, -insLambda);
                        insrzeta += d;
                } // end of for

            // For deletions
            sx = sx2 = sxy = sy = 0.0;
            n = 5;
            if (tmpDelLenMap.size() < 5) n = tmpDelLenMap.size();
    
            numgaps = 0.0;
            tmpIter = tmpDelLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                numgaps += tmpIter->second;
                tmpIter++;
            } // end of for
    
            tmpIter = tmpDelLenMap.begin();
            for (int mIndex = 0; mIndex < n; mIndex++)        
            {
                double x = log((double)tmpIter->first);
                double y = log((double)tmpIter->second);
                sx += x;
                sy += y;
                sxy += x * y;
                sx2 += x * x;
                tmpIter++;
            } // end of for
    
            delLambda = -(n * sxy - sx * sy) / (n * sx2 - sx * sx);
            tmpIter = tmpDelLenMap.end();
            tmpIter--;
            maxLen = tmpIter->first;
    
            delrzeta = 0.0;
            d = 0.0;
                for(unsigned long u = 1;u<=(int)maxLen;++u)
                {
                        d = pow((double)u, -delLambda);
                        delrzeta += d;
                } // end of for
        } // end of else
    } // end of else if
    else if (lenDist == Param::LDIST_GM)
    {
        double sumIns = 0.0;
        double sumDel = 0.0;
        int numIns = 0;
        int numDel = 0;
        for (int bIndex = 1; bIndex <= numBranch; bIndex++)
        {
            vector<int> insLenVec = bInsLenMap[bIndex];
            numIns += insLenVec.size();
            for (int i = 0; i < (int)insLenVec.size(); i++) sumIns += insLenVec.at(i);

            vector<int> delLenVec = bDelLenMap[bIndex];
            numDel += delLenVec.size();
            for (int i = 0; i < (int)delLenVec.size(); i++) sumDel += delLenVec.at(i);
        } // end of for

        if (diffLenDist == false)
        {
            if (numIns + numDel != 0) insProbSuccess = 1 / ((sumIns + sumDel) / (numIns + numDel));
            delProbSuccess = insProbSuccess;
        } // end of if
        else
        {
            if (numIns != 0) insProbSuccess = 1 / (sumIns / numIns);
            if (numDel != 0) delProbSuccess = 1 / (sumDel / numDel);
        } // end of else
        
    } // end of if

	for (int bIndex = 1; bIndex <= numBranch; bIndex++)
	{
		vector<double> prVec = prMap[bIndex];
		double prMut = prVec.at(0);
		double prIns = prVec.at(1);
		double prDel = prVec.at(2);

		sumMut += (branchLength[bIndex] * prMut);
		sumIns += (branchLength[bIndex] * prIns);
		sumDel += (branchLength[bIndex] * prDel);
#ifdef DEBUG_OUTPUT
        cerr << "Branch Index:" << bIndex << endl;
        cerr << "\tbranch length:" << branchLength[bIndex] << endl;
        cerr << "\tprMut:" << prMut << " prIns:" << prIns << " prDel:" << prDel << endl;
#endif
	} // end of for

#ifdef DEBUG_OUTPUT
    cerr << "sumOfLenSquare:" << sumOfLenSquare << endl;
#endif
	constMut = sumMut / sumOfLenSquare;
	constIns = sumIns / sumOfLenSquare;
	constDel = sumDel / sumOfLenSquare;

#ifdef DEBUG_OUTPUT
    cerr << "Cmut:" << constMut << endl;
    cerr << "Cins:" << constIns << endl;
    cerr << "Cdel:" << constDel << endl;
#endif
    //cout << endl;

#ifdef DEBUG_OUTPUT
    if (lenDist == Param::LDIST_PS)
    {
        cerr << "Indel length distribution: Poisson" << endl;
        cerr << "Ins length average: " << insLenAvg << endl;
        cerr << "Del length average: " << delLenAvg << endl;
    } // end of if
    else if (lenDist == Param::LDIST_PL)
    {
        cerr << "Indel length distribution: Power law" << endl;
        cerr << "Ins Exponent: " << insLambda << endl;
        cerr << "Del Exponent: " << delLambda << endl;
        cerr << "Ins Value of Riemann zeta function: " << insrzeta << endl;
        cerr << "Del Value of Riemann zeta function: " << delrzeta << endl; 
    } // end of else if
    else if (lenDist == Param::LDIST_GM)
    {
        cerr << "Indel length distribution: Geometric" << endl;
        cerr << "Ins Prob. Success: " << insProbSuccess << endl;
        cerr << "Del Prob. Success: " << delProbSuccess << endl;
    } // end of if

#endif

    int nucSum = m_numA + m_numC + m_numG + m_numT;
    m_freqA = (double)m_numA / (double)nucSum;
    m_freqC = (double)m_numC / (double)nucSum;
    m_freqG = (double)m_numG / (double)nucSum;
    m_freqT = (double)m_numT / (double)nucSum;
#ifdef DEBUG_OUTPUT
    cerr << "Nucleotide frequency..." << endl;
    cerr << "\tA:" << m_freqA << " C:" << m_freqC << " G:" << m_freqG << " T:" << m_freqT << endl;
    cerr << endl;
#endif

#ifdef DEBUG_OUTPUT
    cerr << "[TInterAnchor: estimateParameter]" << endl;
#endif
    m_subNumArrayAnchor = new int*[4];
    int subNumArray[4][4];
    for (int i = 0; i < 4; i++)
    {
        m_subNumArrayAnchor[i] = new int[4];
        for (int j = 0; j < 4; j++)
        {
            subNumArray[i][j] = 0;
            m_subNumArrayAnchor[i][j] = 0;
        } // end of for
    } // end of for
    
    m_paramU = 0.0;
    int paramCnt = 0;
    for (int i = 0; i < ingroupSeqNumVec.size() - 1; i++)
    {
        int seqNum1 = ingroupSeqNumVec.at(i);
        if (seqNum1 > nSeq) continue;
            
        for (int j = i + 1; j < ingroupSeqNumVec.size(); j++)
        {
            int seqNum2 = ingroupSeqNumVec.at(j);
            if (seqNum2 > nSeq) continue;
            
            double totalTime = 0.0; 
            
            // not yet exist
            int ansNum = getCommonAncestorNum(seqNum1, seqNum2, &totalTime);
            if (ansNum == rootNodeIndex) continue;
#ifdef DEBUG_OUTPUT
            cerr << "Passed sequence pair: " << seqNum1 << " " << seqNum2 << " Common ancestor: " << ansNum << " Branch length: " << totalTime << endl;
#endif
            char buff[1024];
            sprintf(buff, "%d:%d", seqNum1, seqNum2);
            string strKey(buff);
            
            NodeMapValue nmValue(ansNum, totalTime);
            commonAncMap[strKey] = nmValue;
                            
            // 2. Make temporary array for counting the number of substitution
            string str1 = m_anchorVec.at(seqNum1 - 1);
            string str2 = m_anchorVec.at(seqNum2 - 1);
            for (int i = 0; i < str1.length(); i++)
            {
                char ch1 = str1.at(i);
                char ch2 = str2.at(i);
                if (ch1 == '-' || ch2 == '-') continue;
        
                if (ch1 == 'A' && ch2 == 'A') { subNumArray[0][0]++; m_subNumArrayAnchor[0][0]++; }
                else if (ch1 == 'A' && ch2 == 'C') { subNumArray[0][1]++; m_subNumArrayAnchor[0][1]++; }
                else if (ch1 == 'A' && ch2 == 'G') { subNumArray[0][2]++; m_subNumArrayAnchor[0][2]++; }
                else if (ch1 == 'A' && ch2 == 'T') { subNumArray[0][3]++; m_subNumArrayAnchor[0][3]++; }
                else if (ch1 == 'C' && ch2 == 'A') { subNumArray[1][0]++; m_subNumArrayAnchor[1][0]++; }
                else if (ch1 == 'C' && ch2 == 'C') { subNumArray[1][1]++; m_subNumArrayAnchor[1][1]++; }
                else if (ch1 == 'C' && ch2 == 'G') { subNumArray[1][2]++; m_subNumArrayAnchor[1][2]++; }
                else if (ch1 == 'C' && ch2 == 'T') { subNumArray[1][3]++; m_subNumArrayAnchor[1][3]++; }
                else if (ch1 == 'G' && ch2 == 'A') { subNumArray[2][0]++; m_subNumArrayAnchor[2][0]++; }
                else if (ch1 == 'G' && ch2 == 'C') { subNumArray[2][1]++; m_subNumArrayAnchor[2][1]++; }
                else if (ch1 == 'G' && ch2 == 'G') { subNumArray[2][2]++; m_subNumArrayAnchor[2][2]++; }
                else if (ch1 == 'G' && ch2 == 'T') { subNumArray[2][3]++; m_subNumArrayAnchor[2][3]++; }
                else if (ch1 == 'T' && ch2 == 'A') { subNumArray[3][0]++; m_subNumArrayAnchor[3][0]++; }
                else if (ch1 == 'T' && ch2 == 'C') { subNumArray[3][1]++; m_subNumArrayAnchor[3][1]++; }
                else if (ch1 == 'T' && ch2 == 'G') { subNumArray[3][2]++; m_subNumArrayAnchor[3][2]++; }
                else if (ch1 == 'T' && ch2 == 'T') { subNumArray[3][3]++; m_subNumArrayAnchor[3][3]++; }
            } // end of for
                
            // 3. Count the number of substitution in each inter-anchor
            for (int ia = 0; ia < wholeInAnchor.size(); ia++)
            {
                InterAnchor iAnchor = wholeInAnchor.at(ia);
                str1 = iAnchor.getSequenceAt(seqNum1);
                str2 = iAnchor.getSequenceAt(seqNum2);
        
                for (int i = 0; i < str1.length(); i++)
                {
                    char ch1 = str1.at(i);
                    char ch2 = str2.at(i);
                    if (ch1 == '-' || ch2 == '-') continue;
        
                    if (ch1 == 'A' && ch2 == 'A') subNumArray[0][0]++;
                    else if (ch1 == 'A' && ch2 == 'C') subNumArray[0][1]++;
                    else if (ch1 == 'A' && ch2 == 'G') subNumArray[0][2]++;
                    else if (ch1 == 'A' && ch2 == 'T') subNumArray[0][3]++;
                    else if (ch1 == 'C' && ch2 == 'A') subNumArray[1][0]++;
                    else if (ch1 == 'C' && ch2 == 'C') subNumArray[1][1]++;
                    else if (ch1 == 'C' && ch2 == 'G') subNumArray[1][2]++;
                    else if (ch1 == 'C' && ch2 == 'T') subNumArray[1][3]++;
                    else if (ch1 == 'G' && ch2 == 'A') subNumArray[2][0]++;
                    else if (ch1 == 'G' && ch2 == 'C') subNumArray[2][1]++;
                    else if (ch1 == 'G' && ch2 == 'G') subNumArray[2][2]++;
                    else if (ch1 == 'G' && ch2 == 'T') subNumArray[2][3]++;
                    else if (ch1 == 'T' && ch2 == 'A') subNumArray[3][0]++;
                    else if (ch1 == 'T' && ch2 == 'C') subNumArray[3][1]++;
                    else if (ch1 == 'T' && ch2 == 'G') subNumArray[3][2]++;
                    else if (ch1 == 'T' && ch2 == 'T') subNumArray[3][3]++;
                } // end of for
            } // end of for

#ifdef DEBUG_OUTPUT
            // dump
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    cerr << "i:" << i << " j:" << j << " " << subNumArray[i][j] << endl;
#endif
            
            double term1 = 0.0;
            double term2 = 0.0;
            double term3 = 0.0;
            for (int i = 0; i < 4; i++)
            {
                double freq = m_freqA;
                if (i == 0) freq = m_freqA;
                else if (i == 1) freq = m_freqC;
                else if (i == 2) freq = m_freqG;
                else if (i == 3) freq = m_freqT;
        
                term1 += subNumArray[i][i] * (1 - freq);
        
                for (int j = 0; j < 4; j++)
                {
                    if (i == j) continue;
        
                    term2 += subNumArray[i][j] * freq;
                    term3 += subNumArray[i][j] * (1 - freq);
                } // end of for
            } // end of for
            
#ifdef DEBUG_OUTPUT
            cerr << "term1:" << term1 << " term2:" << term2 << " term3:" << term3 << endl;
#endif
#ifdef DEBUG_OUTPUT
            cerr << "m_paramU: " << -(log((term1 - term2) / (term1 + term3)) / totalTime) << endl;
#endif
            m_paramU += -(log((term1 - term2) / (term1 + term3)) / totalTime);

            paramCnt++;
        } // end of for
    } // end of for
#ifdef DEBUG_OUTPUT
    cerr << "Total m_paramU: " << m_paramU << " Total cnt: " << paramCnt << endl;
#endif    
    m_paramU /= paramCnt;
#ifdef DEBUG_OUTPUT
    cerr << "Average m_paramU: " << m_paramU << endl;
#endif
    //writeAnnotationResult(anchorFile, "ParsimonyAnnotation.txt");
    
    /*
    cerr << "[Parsimony]" << endl;
    cerr << "\tconstIns: " << constIns << endl;
    cerr << "\tconstDel: " << constDel << endl;
    cerr << "\tF81 param: " << m_paramU << endl;
    */
    // count indel score
    vector<int> brNumVec;
    for (int i = 0; i < ingroupSeqNumVec.size(); i++)
    {
        int brNum = getBranchNumForSeq(ingroupSeqNumVec.at(i));
        brNumVec.push_back(brNum);
    } // end of for
    
    int numIns = 0;
    int numDel = 0;
    for (int i = 0; i < brNumVec.size(); i++)
    {
        int br = brNumVec.at(i);
        vector<double> numVec = tbMap[br];
        numIns += (int)numVec.at(2);
        numDel += (int)numVec.at(4);
    } // end of for
    
    //cerr << "\t  Number of Insertion: " << numIns << endl;
    //cerr << "\t  Number of Deletion: " << numDel << endl;

    if (m_useTrueIndel == true)
    {
        int trueInsNum = 0;
        int trueDelNum = 0;
        
        for (int i = 0; i < ingroupSeqNumVec.size(); i++)
        {
            int num = ingroupSeqNumVec.at(i);
            vector<int> trueVec = getTrueIndelVec(num);
            trueInsNum += trueVec.at(0);
            trueDelNum += trueVec.at(1);
        } // end of for
        
        double indelAgree = Util::getIndelAgreement(trueInsNum, numIns, trueDelNum, numDel);
        double indelRatio = Util::getIndelRatio(trueInsNum, numIns, trueDelNum, numDel);
        
        cout << "Parsimony: " << trueInsNum << " " << trueDelNum;
        cout << " " << numIns << " " << numDel << " " << indelAgree << " " << indelRatio << " ";
        cout << endl;
#ifdef DEBUG_OUTPUT
        cerr << "(Initial) IA:" << indelAgree << " IR:" << indelRatio << endl;
#endif
    } // end of if

#ifdef DEBUG_OUTPUT
    cerr << "F81 Model parameter:" << m_paramU << endl;
    cerr << endl;
#endif
}

void TInterAnchor::dumpBranchLength()
{
    cerr << endl;
    cerr << "Dump branch length..." << endl;
    map<int, int>::iterator theIter;
    for (int i = 1; i <= numBranch; i++)
    {
        cerr << "    Branch number:" << i << " Length:" << branchLength[i] << endl;
    } // end of for
}

void TInterAnchor::sumBranchLength()
{
	for (int i = 1; i <= numBranch; i++)
	{
		double len = (double)branchLength[i];
		sumOfLenSquare += pow(len, 2);
	} // end of for
}

void TInterAnchor::addBranchSummary(int iaIndex, int colIndex, int bIndex, int bType, int value, bool bLast)
{
    TotalBranch* tb = branchSummary.at(iaIndex);
    tb->addBranchInfo(colIndex, bIndex, bType, value, bLast);
}

double TInterAnchor::getConstMut()
{
	return constMut;
}

double TInterAnchor::getConstIns()
{
	return constIns;
}

double TInterAnchor::getConstDel()
{
	return constDel;
}

double TInterAnchor::getSumOfLenSquare()
{
	return sumOfLenSquare;
}

double TInterAnchor::returnCurrentScore()
{
	return totalScore;
}

double TInterAnchor::getBranchLenAt(int bIndex)
{
    return branchLength[bIndex];
}

int TInterAnchor::getNumBranch()
{
    return numBranch;
}

int TInterAnchor::getLenDist()
{
    return lenDist;
}

double TInterAnchor::getInsLenAvg()
{
    return insLenAvg;
}

double TInterAnchor::getDelLenAvg()
{
    return delLenAvg;
}

double TInterAnchor::getInsLambda()
{
    return insLambda;
}

double TInterAnchor::getDelLambda()
{
    return delLambda;
}

double TInterAnchor::getInsRzeta()
{
    return insrzeta;
}

double TInterAnchor::getDelRzeta()
{
    return delrzeta;
}

double TInterAnchor::getInsProbSuccess()
{
    return insProbSuccess;
}

double TInterAnchor::getDelProbSuccess()
{
    return delProbSuccess;
}

int TInterAnchor::getNumColumn()
{
    return numColumn;
}

vector<string> TInterAnchor::makeAnchor(string seqFile, string anchorFile)
{
    vector<string> fullSeq;
	vector<string> seqName;
    int anchorNum;
	int totalColNum=0;
    map<int, int> anchorStart;
	map<int, int> anchorLength;

    // Preprocess seqFile
    // Read sequences
	ifstream infile(seqFile.c_str());
	string line;
	string sequence;
	if(infile.is_open())
	{
		bool bReady = false;
		while(!infile.eof())
	  	{
	    	getline(infile,line);

			if(line.length() != 0){
				int loc = (int)line.find('>',0);
				if(loc == string::npos){
                    line = Util::toUpper(line);
					sequence.append(line);
				}else{
					if(bReady){//A sring was formed
						fullSeq.push_back(sequence);
					}
					seqName.push_back(line);
					bReady = true;
					sequence.clear();
				}
			}		
	  	}
		infile.close();
		if(bReady){
			fullSeq.push_back(sequence);
		}
	}

    // Read anchor position information
	int fi;
	ifstream fp_in(anchorFile.c_str());
	if(fp_in.is_open()){
		fp_in >> totalColNum;
		fp_in >> anchorNum;
		fi=1;
		while(fi <= anchorNum)
		{
			int start, end;
			fp_in >> start;
			fp_in >> end;
			anchorStart[fi] = start;
			anchorLength[fi] = end - start + 1;
			fi++;
	  	}
		fp_in.close();
	}

    vector<string> anchorVec;
    for (int s = 0; s < nSeq; s++)
    {
        string str = "";
        anchorVec.push_back(str);
    } // end of for

    map<int, int>::iterator iter;
    int aNum = 1;
    for (iter = anchorStart.begin(); iter != anchorStart.end(); iter++)
    {
#ifdef DEBUG_OUTPUT
        cerr << endl;
        cerr << "Anchor num:" << aNum << endl;
#endif
        int start = iter->second; //anchorStart[anchorPtr];
		int length = anchorLength[iter->first];

        for(int s = 0; s < nSeq; s++)
        {
            string anchor = fullSeq.at(s).substr(start-1,length);
#ifdef DEBUG_OUTPUT
            cerr << anchor << endl;
#endif

            // count nucleotides frequency
            for (int i = 0; i < anchor.length(); i++)
            {
                char ch = anchor.at(i);
                if (ch == 'A') m_numA++;
                else if (ch == 'C') m_numC++;
                else if (ch == 'G') m_numG++;
                else if (ch == 'T') m_numT++;
            } // end of for    

            anchorVec.at(s).append(anchor);
        } // end of for

        aNum++;
    } // end of for

    m_anchorVec = anchorVec;
    return anchorVec;
}

void TInterAnchor::setAnchorBranchInfo(TotalBranch* tBranch)
{
    anchorBranchInfo = tBranch;
}

void TInterAnchor::findSubAnchors()
{
    for (int iaIndex = 0; iaIndex < wholeInAnchor.size(); iaIndex++)
    {
        InterAnchor iAnchor = wholeInAnchor.at(iaIndex);
        for (int i = 1; i <= nSeq - 1; i++)
        {
            string seq1 = iAnchor.getSequenceAt(i);
            for (int j = i + 1; j <= nSeq; j++)
            {
                string seq2 = iAnchor.getSequenceAt(j);
                aux_findSubAnchors(&iAnchor, i, seq1, j, seq2);
                
            } // end of for
        } // end of for
        wholeInAnchor.at(iaIndex) = iAnchor;
    } // end of for
    
}

void TInterAnchor::aux_findSubAnchors(InterAnchor* iAnchor, int seqNum1, string seq1, int seqNum2, string seq2)
{
    int numMisMatch = 0;
    int startIndex = 0;
    int numCol = 0;
    int seqColNum = seq1.length();
    for (int i = 0; i < seqColNum; i++)
    {
        char ch1 = seq1.at(i);
        char ch2 = seq2.at(i);

        if (ch1 == '-' || ch2 == '-')
        {
            // stop recording sub-anchor information
            if (numCol >= 10 && numMisMatch <= anchorStat[numCol])
            {
                // Find sub-anchor
                for (int j = startIndex; j <= i; j++)
                {
                    iAnchor->setAnchorAt(seqNum1, j);
                    iAnchor->setAnchorAt(seqNum2, j);
                } // end of for
            } // end of if

            // reset variables
            numMisMatch = 0;
            numCol = 0;
            startIndex = i + 1;
        } // end of if
        else if (ch1 == ch2 && ch1 != 'N')
        {
            // match case
            numCol++;

            // stop recording sub-anchor information
            if (numCol >= 10 && numMisMatch <= anchorStat[numCol])
            {
                // Find sub-anchor
                for (int j = startIndex; j <= i; j++)
                {
                    iAnchor->setAnchorAt(seqNum1, j);
                    iAnchor->setAnchorAt(seqNum2, j);
                } // end of for

                // reset variables
                numMisMatch = 0;
                numCol = 0;
                startIndex = i + 1;
            } // end of if
        } // end of else if
        else
        {
            // mismatch case
            numCol++;
            numMisMatch++;

            // stop recording sub-anchor information
            if (numCol >= 10 && numMisMatch <= anchorStat[numCol])
            {
                // Find sub-anchor
                for (int j = startIndex; j <= i; j++)
                {
                    iAnchor->setAnchorAt(seqNum1, j);
                    iAnchor->setAnchorAt(seqNum2, j);
                } // end of for

                // reset variables
                numMisMatch = 0;
                numCol = 0;
                startIndex = i + 1;
            } // end of if
        } // end of else

        if (numCol > 50)
        {
            // reset variables
            numMisMatch = 0;
            numCol = 0;
            startIndex = i + 1;
        } // end of if
    } // end of for
}

void TInterAnchor::readAnchorStat()
{
    char * buffer;
    buffer = getenv ("INDELIGN_DIR");
    if (buffer==NULL)
    {
        cerr << "No definition of the environment variable: INDELIGN_DIR" << endl;
        cerr << "Please define the INDELIGN_DIR environment variables." << endl;
        exit(1);
    } // end of if

    string str1(buffer);
    str1 += "/AnchorStat.txt";


    ifstream infile(str1.c_str());
	string line;
	
	if(infile.is_open())
	{
      bool bReady = false;
	  while(!infile.eof())
	  {
	    	getline(infile,line);
            line = Util::trim(line);
		    if(line.length() != 0)
            {
			    int sIndex = line.find('\t');
                string strLen = line.substr(0, sIndex);
                string strMut = line.substr(sIndex + 1);

                int len = atoi(strLen.c_str());
                int mut = atoi(strMut.c_str());
                anchorStat[len] = mut;
		    } // end of if		
	  }
	    infile.close();
	}
    else
    {
        cerr << "AnchorStat.txt file open error!" << endl;
        exit(1);
    } // end of else

}

void TInterAnchor::readTrueIndexCnt()
{
    ifstream infile("TrueIndelCnt.txt");
	string line;
	
	if(infile.is_open())
	{
      bool bReady = false;
      int seqcnt = 1;
	  while(!infile.eof())
	  {
	    	getline(infile,line);
            line = Util::trim(line);
		    if(line.length() != 0)
            {
                if (line.at(0) == '#') continue;

			    int sIndex = line.find('\t');
                string strIns = line.substr(0, sIndex);
                string strDel = line.substr(sIndex + 1);

                int numIns = atoi(strIns.c_str());
                int numDel = atoi(strDel.c_str());
                vector<int> indelVec;
                indelVec.push_back(numIns);
                indelVec.push_back(numDel);
                trueIndelCnt[seqcnt] = indelVec;
                seqcnt++;
		    } // end of if		
	  }
	    infile.close();
	}
    else
    {
        cerr << "TrueIndelCnt.txt file open error!" << endl;
        exit(1);
    } // end of else

#ifdef DEBUG_OUTPUT
    // debug
    cerr << endl;
    map<int, vector<int> >::iterator iter;
    for (iter = trueIndelCnt.begin(); iter != trueIndelCnt.end(); iter++)
    {
        vector<int> tmpVec = iter->second;
        cerr << "Sequence num:" << iter->first << " Ins:" << tmpVec.at(0) << " Del:" << tmpVec.at(1) << endl;
    } // end of for
#endif
    
}

void TInterAnchor::setBranchNumForSeq(int seqnum, int bnum)
{
    branchForLeafSeq[seqnum] = bnum;
}

int TInterAnchor::getBranchNumForSeq(int seqnum)
{
    return branchForLeafSeq[seqnum];
}

int TInterAnchor::getSeqNumForBranch(int bnum)
{
    map<int, int>::iterator iter;
    int seqNum = 0;
    for (iter = branchForLeafSeq.begin(); iter != branchForLeafSeq.end(); iter++)
    {
        if (iter->second == bnum)
        {
            seqNum = iter->first;
            break;
        } // end of if
    } // end of for

    return seqNum;
}

void TInterAnchor::dumpBranchSeq()
{
    map<int, int>::iterator iter;
    for (iter = branchForLeafSeq.begin(); iter != branchForLeafSeq.end(); iter++)
    {
        cerr << "Seq:" << iter->first << " Branch:" << iter->second << endl;
    } // end of for
}

vector<int> TInterAnchor::getTrueIndelVec(int seqnum)
{
    return trueIndelCnt[seqnum];
}
  
double TInterAnchor::getFreqA()
{
    return m_freqA;
}

double TInterAnchor::getFreqC()
{
    return m_freqC;
}

double TInterAnchor::getFreqG()
{
    return m_freqG;
}

double TInterAnchor::getFreqT()
{
    return m_freqT;
}

double TInterAnchor::getParamU()
{
    return m_paramU;
}

vector<string> TInterAnchor::getAnchorString()
{
    return m_anchorVec;
}

int TInterAnchor::getAnchorSeqLen()
{
    return m_anchorVec.at(0).length();
}

int TInterAnchor::getBranchForLeafSeq(int seqnum)
{
    return branchForLeafSeq[seqnum];
}

int** TInterAnchor::getSubNumArrayAnchor()
{
    return m_subNumArrayAnchor;
}

void TInterAnchor::setIngroupSeqNumVec(vector<int> numVec)
{
    ingroupSeqNumVec = numVec;

    ingroupSeqNumList = "";
    ingroupSeqNameList = "";
    for (int i = 0; i < numVec.size(); i++)
    {
        char buff[1024];
        sprintf(buff, "%d", numVec.at(i));
        string tmpStr(buff);
        ingroupSeqNumList += tmpStr;
        if (i != numVec.size() - 1) ingroupSeqNumList += ":";

        ingroupSeqNameList += nodeNameMap->operator[](numVec.at(i));
        if (i != numVec.size() - 1) ingroupSeqNameList += ":";
    } // end of for
}

vector<int>* TInterAnchor::getIngroupSeqNumVec()
{
    return &ingroupSeqNumVec;    
}

bool TInterAnchor::isSubAnchor(int iaNum, int seqNum, int colIndex)
{
    InterAnchor* iAnchor = getInterAnchorAt(iaNum - 1);
    return iAnchor->isAnchorAt(seqNum, colIndex);
}

void TInterAnchor::writeAnnotationResult(string anchorFile, string outFile)
{
    // Write the annotation results to file
    // Default file name is "ParsimonyAnnotation.txt"
    int totalColNum = 0;
    int anchorNum = 0;
	map<int, int> ianchorStart;
    
    int iaCnt = 1;
   	int fi;
	ifstream fp_in(anchorFile.c_str());
	if(fp_in.is_open()){
		fp_in >> totalColNum;
		fp_in >> anchorNum;
		fi=1;
		while(fi <= anchorNum)
		{
			int start, end;
			fp_in >> start;
			fp_in >> end;
            
            if (fi == 1 && start > 1) 
            {
                ianchorStart[iaCnt] = 1;
                iaCnt++;
            } // end of if
            
			fi++;
            
            if (end + 1 < totalColNum)
            {
                ianchorStart[iaCnt] = end + 1;
                iaCnt++;
            } // end of if
	  	}
		fp_in.close();
	}

        if (anchorNum == 0)  ianchorStart[1] = 1;
	map<int, vector<OutputDS> > finalResultOut;

	for (int i = 1; i <= getNumOfInterAnchor(); i++)
    {
    	int startPos = ianchorStart[i];
	    TotalBranch* tBranch = branchSummary.at(i - 1);
        
        for (int s = 1; s <= nSeq; s++)
        {
            int bIndex = getBranchForLeafSeq(s);
            BranchInfo* bInfo = tBranch->getBranchInfoAt(bIndex);
            vector<AnnInfo>* aInfoVec = bInfo->getAnnInfoVec();
        	
            for (int afIndex = 0; afIndex < aInfoVec->size(); afIndex++)
            {
                AnnInfo aInfo = aInfoVec->at(afIndex);
                int start = aInfo.getStartIndex() + startPos - 1;
                int end = aInfo.getEndIndex() + startPos - 1;
                int anno = aInfo.getAnn();	
                
                string anno_str;
                if(anno == PhyloTreeNode::INSERTION){anno_str = "Insertion";}
                else{
                    if(anno == PhyloTreeNode::DELETION){anno_str = "Deletion";}
                    else{anno_str = "anno_error";}
                }
                
                OutputDS currentItem(start,end,anno_str, aInfo.getLength());
                finalResultOut[s].push_back(currentItem);
            } // end of for
         } // end of for
    } // end of for
    	
	ofstream fout2(outFile.c_str());
	for(int s=1;s<=nSeq;s++){
        // Merge continuous indels
        vector<OutputDS> newResult;    

        for(int j=0;j<(int)finalResultOut[s].size();j++)
        {
		    int start = finalResultOut[s].at(j).getStartIndex();
		    int end = finalResultOut[s].at(j).getEndIndex();
		    string anno = finalResultOut[s].at(j).getAnnotation();
  	        
            if (j == 0)
                newResult.push_back(finalResultOut[s].at(j));
            else
            {
                int pend = newResult.at(newResult.size() - 1).getEndIndex();
                string panno = newResult.at(newResult.size() - 1).getAnnotation();
                if (anno != panno)
                {
                    newResult.push_back(finalResultOut[s].at(j));
                } // end of if
                else
                {
                    if ((pend + 1) == start)
                    {
                        int pstart = newResult.at(newResult.size() - 1).getStartIndex();
                        OutputDS currentItem(pstart,end,anno,finalResultOut[s].at(j).getLength() + newResult.at(newResult.size() - 1).getLength());
                        newResult.pop_back();
                        newResult.push_back(currentItem);
                    } // end of if
                    else
                    {
                        newResult.push_back(finalResultOut[s].at(j));
                    } // end of else
                } // end of else
            } // end of else
	    }

		fout2 << "Sequence " << nodeNameMap->operator [](s) << endl;	
        int numIns = 0;
        int numDel = 0;
		for(int j=0;j<(int)newResult.size();j++){
			int start = newResult.at(j).getStartIndex();
			int end = newResult.at(j).getEndIndex();
            int len = newResult.at(j).getLength();
			string anno = newResult.at(j).getAnnotation();
            if (anno.compare("Insertion") == 0) numIns++;
            else if (anno.compare("Deletion") == 0) numDel++;
			fout2 << "\t" << start << "\t" << end << "\t" << anno;			

            if (len != (end - start + 1))
                fout2 << "\tSplitted one indel" << endl;
            else
                fout2 << endl;
		}
	}
	fout2.close();

    
}

int TInterAnchor::getCommonAncestorNum(int seqNum1, int seqNum2, double* tTime)
{
    set<int> numSet1;
    int tmpNum = seqNum1;
    while (true)
    {
        int pNum = parentNodeMap[tmpNum];
        numSet1.insert(pNum);
        if (pNum == rootNodeIndex) break;
            
        tmpNum = pNum;
    } // end of while
    
    set<int> numSet2;
    tmpNum = seqNum2;
    while (true)
    {
        int pNum = parentNodeMap[tmpNum];
        numSet2.insert(pNum);
        if (pNum == rootNodeIndex) break;
            
        tmpNum = pNum;
    } // end of while
    
    // set intersection
    set<int> resultSet;
    set<int>::iterator setIter, setIter2;
    for (setIter = numSet1.begin(); setIter != numSet1.end(); setIter++)
    {
        int num = *setIter;
        setIter2 = numSet2.find(num);
        if (setIter2 != numSet2.end()) resultSet.insert(num);
    } // end of for
    
    int commonAncNum = *(resultSet.begin());
    double totalTime = 0.0;
    
    // calculate total branch length
    tmpNum = seqNum1;
    while (true)
    {
        int bNum = getBranchNumForSeq(tmpNum);
        totalTime += getBranchLenAt(bNum);
        int pNum = parentNodeMap[tmpNum];
        if (pNum == commonAncNum) break;
            
        tmpNum = pNum;
    } // end of while
    
    tmpNum = seqNum2;
    while (true)
    {
        int bNum = getBranchNumForSeq(tmpNum);
        totalTime += getBranchLenAt(bNum);
        int pNum = parentNodeMap[tmpNum];
        if (pNum == commonAncNum) break;
            
        tmpNum = pNum;
    } // end of while
    
    *tTime = totalTime;
    return commonAncNum;
}

void TInterAnchor::makeParentNodeMap()
{
    map<int, vector<int> >::iterator tmpIter;
    for (tmpIter = treeMap->begin(); tmpIter != treeMap->end(); tmpIter++)
    {
        int pNum = tmpIter->first;
        vector<int> chVec = tmpIter->second;
        parentNodeMap[chVec.at(0)] = pNum;
        parentNodeMap[chVec.at(1)] = pNum;
    } // end of for
}

void TInterAnchor::runSystemCmd(string cmd, bool bout)
{
    FILE* fp;
    char buff[1024];
    fp = popen(cmd.c_str(), "r");
    while (fgets(buff, 1024, fp) != NULL)
    {
        if (bout == true) cout << buff;
    } // end of while
    pclose(fp);
    if (bout == true) cout << " ";
}

NodeMapValue* TInterAnchor::getNodeMapValue(string key)
{
    NodeMapValue* result = NULL;
    map<string, NodeMapValue>::iterator tmpIter;
    tmpIter = commonAncMap.find(key);
    if (tmpIter != commonAncMap.end()) result = &(tmpIter->second);
        
    return result;
}

string TInterAnchor::getIngroupSeqNumList()
{
    return ingroupSeqNumList;
}

string TInterAnchor::getIngroupSeqNameList()
{
    return ingroupSeqNameList;
}

bool TInterAnchor::getDiffLenDist()
{
    return diffLenDist;
}

NodeMapValue::NodeMapValue()
{
    commonAncestor = -1;
    totalTime = 0.0;
}

NodeMapValue::NodeMapValue(int num, double len)
{
    commonAncestor = num;
    totalTime = len;
}

NodeMapValue::~NodeMapValue()
{
    
}

int NodeMapValue::getCommonAncestorNum()
{
    return commonAncestor;
}

double NodeMapValue::getTotalTime()
{
    return totalTime;
}

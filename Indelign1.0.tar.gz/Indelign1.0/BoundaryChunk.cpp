// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "BoundaryChunk.h"

BoundaryChunk::BoundaryChunk()
{

}

BoundaryChunk::BoundaryChunk(int numSeq, vector<string> seqVector)
{
	nSeq = numSeq;
	seqVec = seqVector;
	numColumn = (int)seqVec.at(0).length();

	makeBoundaryItem();
}

BoundaryChunk::BoundaryChunk(const BoundaryChunk& bChunk)
{
    wholeBoundaryItems = bChunk.wholeBoundaryItems;
    seqVec = bChunk.seqVec;
    nSeq = bChunk.nSeq;
    numColumn = bChunk.numColumn;  
}

BoundaryChunk::BoundaryChunk(int numSeq, vector<string>* seqVector)
{
	nSeq = numSeq;
	for(int i=0;i<(int)seqVector->size();i++){
		seqVec.push_back(seqVector->at(i));
	}
	numColumn = (int)seqVec.at(0).length();

	makeBoundaryItem();
}

BoundaryChunk::~BoundaryChunk()
{

}

void BoundaryChunk::makeBoundaryItem()
{
	bool itemCreated = false;
	string palette(nSeq,'G');
	int sIndex = -1;

	for(int j=0; j < numColumn; j++)
	{
		string tempPalette(nSeq,'U');
                bool allGaps = true;
                for(int i=0; i < nSeq; i++)
		{
			if((seqVec.at(i)).at(j) == '-'){
				tempPalette.replace(i,1,"G");
			} // end of if
            else
            {
                allGaps = false;
            } // end of else
		}

		if(palette.compare(tempPalette) != 0){
			if(itemCreated){
				for(int i=0;i < nSeq; i++){
					bool ig = false;
					bool continued = false;
					if(palette.at(i) == 'G'){
						ig = true;
						if(tempPalette.at(i) == 'G'){
							continued = true;
						}
					}
					BoundaryItem bItem(sIndex,j-1,i,ig,continued);
					wholeBoundaryItems.push_back(bItem);
				}
					sIndex = j;
			}else{
					sIndex = j;
					itemCreated = true;
			}
			palette.replace(0,tempPalette.length(),tempPalette);	
		}
	}
	if(itemCreated){
		for(int i=0;i < nSeq; i++){
			bool ig = false;
			bool continued = false;
			if(palette.at(i) == 'G'){
				ig = true;
			}
			BoundaryItem bItem(sIndex,numColumn-1,i,ig,continued);
			wholeBoundaryItems.push_back(bItem);
		}
	}
}

void BoundaryChunk::dump()
{
	for (int i = 0; i < (int)wholeBoundaryItems.size(); i++)
	{
		cerr << "ChunkId:" << i << endl;
		BoundaryItem bi = wholeBoundaryItems.at(i);
		bi.dump();

		if (i < (int)wholeBoundaryItems.size() - 1)
			cerr << endl;
	}

    for (int i = 0; i < (int)seqVec.size(); i++)
    {
        cerr << seqVec.at(i) << endl;
    } // end of for
}

int BoundaryChunk::getNumOfBoundaryItem()
{
    return (int)wholeBoundaryItems.size();
}

BoundaryItem* BoundaryChunk::getBoundaryItem(int index)
{
    return &(wholeBoundaryItems.at(index));
}

int BoundaryChunk::getIndexOfBoundaryStartAt(int start)
{
	for (int i = 0; i < (int)wholeBoundaryItems.size(); i++)
	{
		BoundaryItem bi = wholeBoundaryItems.at(i);
		int chunkId = bi.getStart();

		if (chunkId == start){return i;} 
	}

	return -1;
}

string BoundaryChunk::getChunkSeq(int colid, int seqNum)
{
    BoundaryItem* bi = getBoundaryItem(colid);
    int sIndex = bi->getStart();
    int eIndex = bi->getEnd();
    string str = seqVec.at(seqNum - 1);
    return str.substr(sIndex, eIndex - sIndex + 1);
}

string BoundaryChunk::getChunkSeq(int colid)
{
    string str;
    for (int i = 0; i < nSeq; i++)
    {
        BoundaryItem* bi = getBoundaryItem(colid + i);
        if (bi->getIsGap() == false)
        {
            int sIndex = bi->getStart();
            int eIndex = bi->getEnd();
            string tmpStr = seqVec.at(i);
            str = tmpStr.substr(sIndex, eIndex - sIndex + 1);
            break;
        } // end of if
    } // end of for

    return str;
}

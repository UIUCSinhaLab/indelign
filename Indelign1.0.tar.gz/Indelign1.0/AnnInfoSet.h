// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef ANNINFOSET_H
#define ANNINFOSET_H

#include <iostream>
#include <vector>
#include <map>

using namespace std;

class AnnInfo
{
private:
    int m_startIndex;   // relative start index to the start index of BestAnnotation
    int m_endIndex;     // relative end index to the start index of BestAnnotation
    int m_length;       // gap length
    int m_ann;

public:
    AnnInfo();
    AnnInfo(int sIndex, int eIndex, int ann, int length);
    AnnInfo(const AnnInfo& aInfo);
    ~AnnInfo();

    int getStartIndex();
    int getEndIndex();
    int getLength();
    int getAnn();

    void setStartIndex(int sIndex);
    void setEndIndex(int eIndex);
    void setLength(int length);
    void addOffset(int offset);
};

class AnnInfoSet
{
private:
	// Key: branch number, Value: vector of AnnInfo
	map<int, vector<AnnInfo> > m_annMap;

public:
	AnnInfoSet();	// Default constructor
    AnnInfoSet(const AnnInfoSet& aInfo);
	~AnnInfoSet();	// Default destructor

	void addAnnInfo(int bNum, vector<AnnInfo> infoVec);
    void appendAnnInfo(int bNum, vector<AnnInfo>* infoVec);
	vector<AnnInfo>* getAnnInfoAt(int bNum);
};

#endif


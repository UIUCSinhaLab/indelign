// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include "PhyloTreeNodeEx.h"

///////////////////////////////////////////////////////////////////////
// For PhyloTreeNodeEx class

// Default constructor
PhyloTreeNodeEx::PhyloTreeNodeEx()
{
    leftChild = rightChild = NULL;
    m_bestEntryIndex = -1;
    totalSubstScore = 0.0;
}

// Destructor
PhyloTreeNodeEx::~PhyloTreeNodeEx()
{
    for (int i = 0; i < m_vecIndelEntry.size(); i++)
        delete m_vecIndelEntry.at(i);
    m_vecIndelEntry.clear();
    
    for (int i = 0; i < substInfoVec.size(); i++)
        delete substInfoVec.at(i);
    substInfoVec.clear();
    
}

void PhyloTreeNodeEx::setLeftChild(PhyloTreeNodeEx* pNode)
{
    leftChild = pNode;
}

void PhyloTreeNodeEx::setRightChild(PhyloTreeNodeEx* pNode)
{
    rightChild = pNode;
}

PhyloTreeNodeEx* PhyloTreeNodeEx::getLeftChild()
{
    return leftChild;
}

PhyloTreeNodeEx* PhyloTreeNodeEx::getRightChild()
{
    return rightChild;
}

void PhyloTreeNodeEx::dump()
{
    cerr << endl;
    cerr << "Size of IndelEntry vector:" << (int)m_vecIndelEntry.size() << endl;
    for (int i = 0; i < (int)m_vecIndelEntry.size(); i++)
    {
        IndelEntry* ie = m_vecIndelEntry.at(i);
        ie->dump();
    } // end of for

    cerr << "Size of subst vec:" << (int)substInfoVec.size() << endl;
    for (int i = 0; i < (int)substInfoVec.size(); i++)
    {
        cerr << "    SubstInfo id:" << i << endl;
        SubstInfo* substInfo = substInfoVec.at(i);
        substInfo->dump();
    } // end of for
}

void PhyloTreeNodeEx::setBestEntryIndex(int index)
{
    m_bestEntryIndex = index;
}

int PhyloTreeNodeEx::getBestEntryIndex()
{
    return m_bestEntryIndex;
}

void PhyloTreeNodeEx::addSubstInfo(SubstInfo* subInfo)
{
    substInfoVec.push_back(subInfo);
}

SubstInfo* PhyloTreeNodeEx::getSubstInfoAt(int index)
{
    return substInfoVec.at(index);    
}

// delete the unnecessary NodeScoreMatrix data from the vector
// this function can be called after completing the calculation of the substitution score
void PhyloTreeNodeEx::compactSubstInfoVec()
{
    for (int i = 0; i < substInfoVec.size(); i++)
    {
        SubstInfo* subInfo = substInfoVec.at(i);
        subInfo->removeNodeScoreMatrix();
    } // end of for
}

int PhyloTreeNodeEx::getSubstInfoVecSize()
{
    return substInfoVec.size();
}

void PhyloTreeNodeEx::addSubstScore(double scr)
{
    if (substScoreVec.size() == 0) totalSubstScore = 0.0;
    substScoreVec.push_back(scr);
    totalSubstScore += scr;
}

double PhyloTreeNodeEx::getSubstScoreAt(int index)
{
    return substScoreVec.at(index);
}

int PhyloTreeNodeEx::getSubstScoreVecSize()
{
    return substScoreVec.size();
}

double PhyloTreeNodeEx::getTotalSubstScore()
{
    return totalSubstScore;
}

void PhyloTreeNodeEx::setSubstScore(vector<double>* scrVec)
{
    for (int i = 0; i < scrVec->size(); i++)
    {
        addSubstScore(scrVec->at(i));
    } // end of for
}

void PhyloTreeNodeEx::addIndelEntry(IndelEntry* ie)
{
    m_vecIndelEntry.push_back(ie);    
}

IndelEntry* PhyloTreeNodeEx::getIndelEntryAt(int index)
{
    assert (index < m_vecIndelEntry.size());
    return m_vecIndelEntry.at(index);
}

int PhyloTreeNodeEx::getIndelEntryVecSize()
{
    return m_vecIndelEntry.size();
}
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////
// For BestAnnotation class
BestAnnotation::BestAnnotation()
{
    score = 0.0;
    m_startColIndex = m_endColIndex = -1;
}

// Copy constructor
BestAnnotation::BestAnnotation(const BestAnnotation& ann)
{
    score = ann.score;   // score of current annotation of the tree
    bInfoSet = ann.bInfoSet;
    m_startColIndex = ann.m_startColIndex;
    m_endColIndex = ann.m_endColIndex;
}

BestAnnotation::BestAnnotation(double scr, BranchInfoSet biSet)
{
    score = scr;
    bInfoSet = biSet;
}

BestAnnotation::~BestAnnotation()
{

}
 
double BestAnnotation::getScore()
{
    return score;
}

BranchInfoSet* BestAnnotation::getBranchInfoSet()
{
    return &(bInfoSet);
}

int BestAnnotation::getStartColIndex()
{
    return m_startColIndex;
}

int BestAnnotation::getEndColIndex()
{
    return m_endColIndex;
}

void BestAnnotation::setStartColIndex(int col)
{
    m_startColIndex = col;
}

void BestAnnotation::setEndColIndex(int col)
{
    m_endColIndex = col;
}

SubstInfo::SubstInfo()
{
    m_bFix = false;
    m_nsMatSet = NULL;
    m_bLeftStar = false;
    m_bRightStar = false;
}

SubstInfo::SubstInfo(NodeScoreMatrixSet* nsMatSet)
{
    m_bFix = false;
    m_nsMatSet = nsMatSet;
    m_bLeftStar = false;
    m_bRightStar = false;
}

SubstInfo::~SubstInfo()
{
    // free memory
    if (m_nsMatSet != NULL) delete m_nsMatSet;
}

bool SubstInfo::isFixed()
{
    return m_bFix;
}

NodeScoreMatrixSet* SubstInfo::getNodeScoreMatrixSet()
{
    return m_nsMatSet;
}

void SubstInfo::removeNodeScoreMatrix()
{
    if (m_nsMatSet != NULL) delete m_nsMatSet;
    m_nsMatSet = NULL;
}

bool SubstInfo::isLeftStar()
{
    return m_bLeftStar;
}

bool SubstInfo::isRightStar()
{
    return m_bRightStar;
}

void SubstInfo::setLeftStar()
{
    m_bLeftStar = true;
}

void SubstInfo::setRightStar()
{
    m_bRightStar = true;
}

void SubstInfo::setFixed()
{
    m_bFix = true;
}

void SubstInfo::setNodeScoreMatrixSet(NodeScoreMatrixSet* nsMatSet)
{
    m_nsMatSet = nsMatSet;
}

void SubstInfo::dump()
{
    string strFix = "false";
    if (m_bFix) strFix = "true";
    cerr << "        Fixed? " << strFix << endl;
    
    string strLeftStar = "false";
    if (m_bLeftStar) strLeftStar = "true";
    cerr << "        Left star? " << strLeftStar << endl;
    string strRightStar = "false";
    if (m_bRightStar) strRightStar = "true";
    cerr << "        Right star? " << strRightStar << endl;
    
    if (m_nsMatSet == NULL) cerr << "        NodeScoreMatrixSet=NULL" << endl;
    else
    {
        for (int i = 0; i < m_nsMatSet->getSize(); i++)
        {
            NodeScoreMatrix* ns = m_nsMatSet->getNodeScoreMatrixAt(i);
            vector<char> baseVec;
            baseVec.push_back('A');
            baseVec.push_back('C');
            baseVec.push_back('G');
            baseVec.push_back('T');
            for (int baseIndex = 0; baseIndex < baseVec.size(); baseIndex++)
            {
                char baseCh = baseVec.at(baseIndex);
                cerr << "        " << baseCh << ": " << ns->getProb(baseCh) << endl;
            } // end of for
        } // end of for
    } // end of else
}


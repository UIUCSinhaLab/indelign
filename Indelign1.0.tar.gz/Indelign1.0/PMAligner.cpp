// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include <map>
#include <vector>
#include "Util.h"
#include "TInterAnchor.h"
#include "PhyloTreeSet.h"
#include "InterAnchor.h"
#include "SearchBest.h"
#include "BoundaryItem.h"
#include "BoundaryChunk.h"
#include "Param.h"

#define DEBUG

using namespace std;

void usage()
{
    cerr << endl;
    cerr << "Usage: PMAligner seq_file anchor_file int_anchor_file parameter_file execution_mode" << endl;
    cerr << "Possible execution mode: -A: only annotation, -S: search with annotation" << endl;
    cerr << endl;
}

int parseParams(int argc, char* argv[], string* seqFile, string* anchorFile, string* strFile, string* parFile, string* exeMode)
{
    if (argc != 6)
    {
        usage();
        return 1;
    } // end of if 

    // file open check
    ifstream sfile(argv[1]);
    if (!sfile)
    {
        cerr << "Error opening sequence file: " << argv[1] << "." << endl;
        usage();
        return 1;
    } // end of if
    sfile.close();
    *seqFile = argv[1];

    // file open check
    ifstream ancfile(argv[2]);
    if (!ancfile)
    {
        cerr << "Error opening anchor file: " << argv[2] << "." << endl;
        usage();
        return 1;
    } // end of if
    ancfile.close();
    *anchorFile = argv[2];

    // file open check
    ifstream infile(argv[3]);
    if (!infile)
    {
        cerr << "Error opening inter anchor file: " << argv[3] << "." << endl;
        usage();
        return 1;
    } // end of if
    infile.close();
    *strFile = argv[3];

    // file open check
    ifstream pafile(argv[4]);
    if (!pafile)
    {
        cerr << "Error opening parameter file: " << argv[4] << "." << endl;
        usage();
        return 1;
    } // end of if
    pafile.close();
    *parFile = argv[4];

    *exeMode = argv[5];
    if ((*exeMode).compare("-A") != 0 && (*exeMode).compare("-E") != 0 && (*exeMode).compare("-S") != 0)
    {
        cerr << "Error in the execution mode: " << argv[5] << "." << endl;
        usage();
        return 1;
    } // end of if, 

#ifdef DEBUG_OUTPUT
    cerr << endl;
    cerr << "<Parameters>" << endl;
    cerr << "    Sequence filename: " << *seqFile << endl; 
    cerr << "    Anchor filename: " << *anchorFile << endl; 
    cerr << "    Inter anchor filename: " << *strFile << endl; 
    cerr << "    Execution mode:" << *exeMode << endl;
    cerr << endl;
#endif

    return 0;
}

void addSeqNum(int numSeq, int key, map<int, vector<int> >* treeMapPtr, vector<int>* numVec)
{
    vector<int> chVec = treeMapPtr->operator[](key);
    if (chVec.at(0) <= numSeq) numVec->push_back(chVec.at(0));
    if (chVec.at(1) <= numSeq) numVec->push_back(chVec.at(1));
    
    if (chVec.at(0) > numSeq) addSeqNum(numSeq, chVec.at(0), treeMapPtr, numVec);
    if (chVec.at(1) > numSeq) addSeqNum(numSeq, chVec.at(1), treeMapPtr, numVec);
}

int main(int argc, char* argv[])
{
    int numSeq = 0;     // number of sequences
    string strTree;     // string for phylogenetic tree
    string strFile;     // input filename
    string parFile;
    string seqFile;
    string anchorFile;
    string outFile1;
    string outFile2;
    string outFile3;
    bool notRe;
    int numShift;
    int lenDist;
    bool includeAnchor;
    bool diffLenDist;
    int numIter;
    string exeMode;

    // parse parameters
    if (parseParams(argc, argv, &seqFile, &anchorFile, &strFile, &parFile, &exeMode))
        return 1;

#ifdef DEBUG_OUTPUT
    cerr << "<Start program...>" << endl;
#endif    
    
    map<int, vector<int> > treeMap;
    map<int, double> bLenMap;  // branch length map
    map<int, string> nodeNameMap;
    int nodeIndex = 0;
    Param param = Util::parseTreeEx(parFile, &strTree, &treeMap, &bLenMap, &nodeIndex, &nodeNameMap);

    numSeq = param.getNumSeq();
    outFile1 = param.getOutFile1();
    outFile2 = param.getOutFile2();
    outFile3 = param.getOutFile3();
    notRe = param.getNotRe();
    numShift = param.getNumShift();
    lenDist = param.getLenDist();
    includeAnchor = param.getIncludeAnchor();
    numIter = param.getNumIter();
    diffLenDist = param.getDiffLenDist();

    bool useTrueIndel = param.getUseTrueIndel();

    nodeIndex--;

    map<int, vector<int> >::iterator theIter;
#ifdef DEBUG_OUTPUT
    ///////////
    // tree map dump
    for (theIter = treeMap.begin(); theIter != treeMap.end(); theIter++)
    {
        cerr << "Parent node number:" << theIter->first << "(" << nodeNameMap[theIter->first] << ")" << endl;
        vector<int> chVec = theIter->second;
        for (int i = 0; i < (int)chVec.size(); i++)
            cerr << "    child " << i + 1 << ":" << chVec.at(i) << "(" << nodeNameMap[chVec.at(i)] << ")" << endl;
    } // end of for

    cerr << "Number of sequence:" << numSeq << endl;
    cerr << "Whether a reestimation of parameters is used:" << notRe << endl;
    cerr << "Number of shift:" << numShift << endl;
    cerr << "Outfile1: " << outFile1 << endl;
    cerr << "Outfile2: " << outFile2 << endl;
    cerr << "Outfile3: " << outFile3 << endl;
    ///////////

    cerr << "root node number:" << nodeIndex << endl;
    cerr << "Read inter-anchor data from file..." << endl;
#endif
    
    TInterAnchor* tIAnchor = new TInterAnchor(strFile, numSeq, nodeIndex - 1, bLenMap, lenDist, diffLenDist, includeAnchor, useTrueIndel, &treeMap, nodeIndex, anchorFile, &nodeNameMap);

    ////////////////////////////////////////////////////////////////
    // Find the closest sequence numbers
    vector<int> ingroupSeqNumVec;
    vector<int> chVec = treeMap[nodeIndex];
    
    if (chVec.at(0) > numSeq)
    {
        addSeqNum(numSeq, chVec.at(0), &treeMap, &ingroupSeqNumVec);
    } // end of if
    
    if (chVec.at(1) > numSeq)
    {
        addSeqNum(numSeq, chVec.at(1), &treeMap, &ingroupSeqNumVec);
    } // end of if
    
    tIAnchor->setIngroupSeqNumVec(ingroupSeqNumVec);
#ifdef DEBUG_OUTPUT
	cerr << "[Chosen ingroup sequence numbers]" << endl;
	for (int i = 0; i < ingroupSeqNumVec.size(); i++)
		cerr << ingroupSeqNumVec.at(i) << " ";
	cerr << endl;
#endif
    ////////////////////////////////////////////////////////////////
    tIAnchor->makeAnchor(seqFile, anchorFile);

    // tree branch length dump
#ifdef DEBUG_OUTPUT
    tIAnchor->dumpBranchLength();
#endif

#ifdef DEBUG_OUTPUT
    cerr << "Make phylogenetic tree..." << endl;
#endif

//////////
    int numOfIA = tIAnchor->getNumOfInterAnchor();
    for (int i = 0; i < numOfIA; i++)
    {
        InterAnchor* ia = tIAnchor->getInterAnchorAt(i);
        PhyloTreeSet pSet(nodeIndex, &treeMap, numSeq, ia->getSequenceP(), tIAnchor, i);
    } // end of for

#ifdef DEBUG_OUTPUT
    tIAnchor->dumpBranchSeq();
#endif
    tIAnchor->estimateParameters();

#ifdef DEBUG_OUTPUT
    cerr << endl;
    cerr << "End of processing" << endl;
    cerr << endl;
#endif

    SearchBest sb(numSeq,tIAnchor,bLenMap, &treeMap, nodeIndex, notRe, numShift, lenDist, includeAnchor, numIter, param, &nodeNameMap); 

#ifdef DEBUG_OUTPUT
    cerr << "Next step..." << endl;
#endif

    if (exeMode.compare("-A") == 0) sb.annotateAlign(seqFile, anchorFile, outFile1, outFile2, outFile3);
    else if (exeMode.compare("-S") == 0) sb.getBestAlign(seqFile, anchorFile, outFile1, outFile2, outFile3);

    delete tIAnchor;
    return 0;
}

// Copyright (C) 2007 Jaebum Kim (all rights reserved)

#ifndef PARAM_H
#define PARAM_H

#include <iostream>
#include <string>

using namespace std;

class Param 
{
public:
    const static int LDIST_PS = 1;    // poisson distribution
    const static int LDIST_PL = 2;    // power law distribution
    const static int LDIST_GM = 3;    // geometric distribution

private:
    int numSeq;
    bool notRe;
    int numShift;
    string outFile1;
    string outFile2;
    string outFile3;
    int lenDist;
    bool includeAnchor;
    int numIter;

    double constIns;
    double constDel;
    double constMut;
    double F81param;
    double insLenAvg;
    double delLenAvg;
    double insLambda;
    double delLambda;
    double insrzeta;
    double delrzeta;
    double insProbSuccess;
    double delProbSuccess;

    bool useTrueIndel;
    bool diffLenDist;

public:
    Param();
    Param(int nseq, bool nre, int nshift, int ldist, string out1, string out2, string out3, bool iAnchor, int nIter);
    ~Param();

    int getNumSeq();
    int getNumShift();
    bool getNotRe();
    int getLenDist();
    string getOutFile1();
    string getOutFile2();
    string getOutFile3();
    bool getIncludeAnchor();
    int getNumIter();

    double getConstIns();
    double getConstDel();
    double getConstMut();
    double getF81param();
    double getInsLenAvg();
    double getDelLenAvg();
    double getInsLambda();
    double getDelLambda();
    double getInsRzeta();
    double getDelRzeta();
    double getInsProbSuccess();
    double getDelProbSuccess();

    void setConstIns(double cins);
    void setConstDel(double cdel);
    void setConstMut(double cmut);
    void setF81param(double f81param);
    void setInsLenAvg(double lenavg);
    void setDelLenAvg(double lenavg);
    void setInsLambda(double ilambda);
    void setDelLambda(double ilambda);
    void setInsRzeta(double zetavalue);
    void setDelRzeta(double zetavalue);
    void setInsProbSuccess(double prob);
    void setDelProbSuccess(double prob);

    bool getUseTrueIndel();
    void setUseTrueIndel(bool tIndel);
    bool getDiffLenDist();
    void setDiffLenDist(bool dlen);
};

#endif
